export const jwtConstants = {
  secret: '%vmr46rrx(0gz=*64!1%g&j)qb0##3@x@(0a9qs^a6tdigm_sz',
};

export const passKey = {
  secret: 'ampcusra1u9i(=94=3iz21*uj@h&-m%)d-y+ra@qxyxefw=g!cubk+00tech',
};
