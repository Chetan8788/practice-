import {
    Body,
    Controller,
    Get,
    HttpStatus,
    Req,
    Res,
    Post,
    Param,
  } from '@nestjs/common';
  import { Request, Response } from 'express';
import { ApiTags } from '@nestjs/swagger';
import { ContactService } from './contact.service';
import { ContactDetails } from './models/contact-entity';

@ApiTags('Contact')
  @Controller('contact')
  export class ContactController {
    constructor( private readonly contactService: ContactService ) {}
  
    @Get()
    async getAllContact(@Res() res: Response) {
      try {
        res.status(HttpStatus.OK).json();
      } catch (error) {
      }
      return;
    }

    @Get('/byid/:contactId')
    async getContactById(
      @Req() req: Request,
      @Res() res: Response,
      @Param() param) {
      try {
        res.status(HttpStatus.OK).json();
      } catch (error) {
        res.status(HttpStatus.BAD_REQUEST).json(error);
      }
      return;
    }

    @Post('/test')
    async test(
      @Req() req: Request,
      @Res() res: Response,
      @Body() inputData: any) {
      try {
        res.status(HttpStatus.OK).json("okay");
      } catch (error) {
        res.status(HttpStatus.BAD_REQUEST).json(error);
      }
      return;
    }
  
    @Post()
    async createContact(
      @Req() req: Request,
      @Res() res: Response,
      @Body() body: ContactDetails,
    ) {
      try {
        res.status(HttpStatus.OK).json();
      } catch (error) {
        res.status(HttpStatus.BAD_REQUEST).json(error);
      }
    }
  }