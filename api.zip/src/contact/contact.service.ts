import { Injectable, Inject, HttpStatus } from '@nestjs/common';
import { ContactDetails } from './models/contact-entity';
import { ContactDTO } from './dto/contact-dto';

@Injectable()
export class ContactService {
  constructor(
    @Inject('CONTACT_REPOSITORY')
    private contactRepository: typeof ContactDetails,
  ) {}
  async getAllContact() {
    const result = await this.contactRepository.findAll({
      where: { isActive: true },
    });
    return result;
  }

  async getContactByExamId(examContactId: number) {
    const result = await this.contactRepository.findOne({
      where: { examContactId: examContactId, 
        isActive: true },
    });
    return result;
  }

  async createContact(body: any) {
    const createBody: any = {
      ...body,
      email: body.email,
      contactNumber: body.contactNumber,
      faxNumber: body.faxNumber,
      addressId: body.addressId
    }
    const createdCamera =
      await this.contactRepository.create<ContactDetails>( createBody );
    return createdCamera;
  }

  async getContactById(id: number) {
    const examList = await this.contactRepository.findOne({
      where: { id: id }
    });
    return examList;
  }

  async createContactDto(body: ContactDTO) {
    let createBody: any = {};
    createBody = {
      ...body,
      email: body.email,
      contactNumber: body.contactNumber,
      faxNumber: body.faxNumber,
      addressId: body.addressId,
    }
      
    return createBody;
  }
}