module.exports = {
  development: {
    username: 'onboarding',
    password: 'root',
    database: 'onboarding',
    host: 'localhost',
    dialect: 'mysql',
    port: '3307',
  },
  test: {
    username: 'onboarding',
    password: 'root',
    database: 'onboarding',
    host: 'localhost',
    dialect: 'mysql',
    port: '3307',
  },
  production: {
    username: 'onboarding',
    password: 'root',
    database: 'onboarding',
    host: 'localhost',
    dialect: 'mysql',
    port: '3307',
  },
};
