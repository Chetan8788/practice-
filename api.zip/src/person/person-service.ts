import { Injectable, Inject, HttpStatus } from '@nestjs/common';
import { Person } from './models/person-entity';
import { NotNull, Sequelize } from 'sequelize-typescript';
import { Op } from 'sequelize';
import { Vendor } from 'src/vendor/models/vendor-entity';
import { Address } from 'src/address/models/address-entity';
import { Client } from 'src/client/models/client-entity';

@Injectable()
export class PersonService {
    constructor(
        @Inject('PERSON_REPOSITORY')
        private personRepository: typeof Person,
    ) { }

    async getAllPerson(includeArray: any[]) {
        try {
            // const result = await this.personRepository.findAll({
            //     include: includeArray
            // });

            const result = await this.personRepository.findAll({
                include: includeArray
            });
            // const result = await this.personRepository.findAll({
            //     include : [
            //         {
            //             model: Vendor,
            //             required: true,
            //             attributes: [],
            //             include: [
            //                 {
            //                     model: Address,
            //                     required: true,
            //                     attributes: [],
            //                 }
            //             ]
            //         }
            //     ],
            //     attributes: [
            //     ]

            // });  

            // const result = await this.personRepository.findAll({ include: [{ model: Vendor, as: "v" }, { model: Address },], });
            return result;
        } catch (error) {
            console.log('error: ', error);
            return null
        }
    }

    async createPerson() {
        const createBody: any = {
        }
        const createdPerson = await this.personRepository.create<Person>(createBody);
        return createdPerson;
    }

    async getPersonById(id: number) {
        const examList = await this.personRepository.findOne({
            where: { id: id }
        });
        return examList;
    }
}