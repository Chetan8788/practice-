import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsString
} from 'class-validator';
import { Address } from 'src/address/models/address-entity';
import { ContactDetails } from 'src/contact/models/contact-entity';
export class ReferralDTO {

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: Number, description: 'Referral ID' })
  id: number;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: Number, description: 'Company name' })
  companyName: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: Number, description: 'Federal id' })
  federalID: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: String, description: 'Point of contact' })
  contactPerson: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: String, description: 'Contact Details' })
  companyEmailID: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: Number, description: 'Contact Details' })
  contactNo: number;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: Number, description: 'Contact Details' })
  faxNo: number;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: Number, description: 'Name of sign authority' })
  signAuthority: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: Number, description: 'Designation of sign authority' })
  signAuthorityDesignation: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: Number, description: 'State of incorporation' })
  stateOfIncorporation: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: String, description: 'Line 1' })
  line1: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: String, description: 'Line 2' })
  line2: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: String, description: 'City' })
  city: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: String, description: 'State' })
  state: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: String, description: 'Zip code' })
  zipCode: string;
}
