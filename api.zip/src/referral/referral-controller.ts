import {
    Body,
    Controller,
    Get,
    HttpStatus,
    Req,
    Res,
    Post,
    Param,
  } from '@nestjs/common';
  import { Request, Response } from 'express';
import { Referral } from './models/referral-entity';
import { ReferralService } from './referral-service';

  @Controller('referral')
  export class ReferralController {
    constructor( private readonly referralService: ReferralService ) {}
  
    @Get()
    async getAllReferral(@Res() res: Response) {
      try {
        res.status(HttpStatus.OK).json();
      } catch (error) {
      }
      return;
    }

    @Get('/byid/:referralId')
    async getReferralById(
      @Req() req: Request,
      @Res() res: Response,
      @Param() param) {
      try {
        res.status(HttpStatus.OK).json();
      } catch (error) {
        res.status(HttpStatus.BAD_REQUEST).json(error);
      }
      return;
    }

    @Post('/test')
    async test(
      @Req() req: Request,
      @Res() res: Response,
      @Body() inputData: any) {
      try {
        res.status(HttpStatus.OK).json("okay");
      } catch (error) {
        res.status(HttpStatus.BAD_REQUEST).json(error);
      }
      return;
    }
  
    @Post()
    async createReferral(
      @Req() req: Request,
      @Res() res: Response,
      @Body() body: Referral,
    ) {
      try {
        res.status(HttpStatus.OK).json();
      } catch (error) {
        res.status(HttpStatus.BAD_REQUEST).json(error);
      }
    }
  }