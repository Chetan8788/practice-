import { Module } from '@nestjs/common';
import { DatabaseModule } from '../database/database.module';
import { ReferralController } from './referral-controller';
import { ReferralService } from './referral-service';
import { ReferralProviders } from './models/referral.provider';

@Module({
  imports: [DatabaseModule],
  controllers: [ReferralController],
  providers: [ReferralService, ...ReferralProviders],
  exports: [ReferralService],
})
export class ReferralModule {}
