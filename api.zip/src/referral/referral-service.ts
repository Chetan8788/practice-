import { Injectable, Inject, HttpStatus } from '@nestjs/common';
import { Referral } from './models/referral-entity';
import { ReferralDTO } from './dto/referral-dts';

@Injectable()
export class ReferralService {
    constructor(
        @Inject('REFERRAL_REPOSITORY')
        private referralRepository: typeof Referral,
    ) { }

    async getAllReferral() {
        const result = await this.referralRepository.findAll({
            where: { isActive: true },
        });
        return result;
    }

    async createReferral(body: ReferralDTO) {
        const createBody: any = {
            ...body,
            id: body.id,
            federalId: body.federalID,
            companyName: body.companyName,
            contactPerson: body.contactPerson,
            companyEmailID: body.companyEmailID,
            contactNo: body.contactNo,
            signAuthority: body.signAuthority,
            signAuthorityDesignation: body.signAuthorityDesignation,
            stateOfIncorporation: body.stateOfIncorporation
        }
        const createdCamera =
            await this.referralRepository.create<Referral>(createBody);
        return createdCamera;
    }

    async createAddressDto(body: ReferralDTO) {
        let createAddressDto: any = {};
        createAddressDto = {
          ...body,
          line1: body.line1,
          line2: body.line2,
          city: body.city,
          state: body.state,
          zipCode: body.zipCode
        }
        return createAddressDto;
      }

    async getReferralById(id: number) {
        const examList = await this.referralRepository.findOne({
            where: { id: id }
        });
        return examList;
    }
}