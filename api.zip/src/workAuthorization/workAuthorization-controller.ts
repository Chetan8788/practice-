import {
  Body,
  Controller,
  Get,
  HttpStatus,
  Req,
  Res,
  Post,
  Param,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { WorkAuthorization } from './models/workAuthorization-entity';
import { WorkAuthorizationService } from './workAuthorization-service';
import { WorkAuthorizationDTO } from './dto/workAuthorization-dts';

@Controller('workAuthorization')
export class WorkAuthorizationController {
  constructor(private readonly workAuthorizationService: WorkAuthorizationService) { }

  @Get('/get-all-workAuthorization')
  async getAllWorkAuthorization(@Res() res: Response) {
    try {
      const workAuthorizationResult = await this.workAuthorizationService.getAllWorkAuthorization();
      res.status(HttpStatus.OK).json(workAuthorizationResult);
    } catch (error) {
    }
    return;
  }

  @Get('/byid/:workAuthorizationId')
  async getWorkAuthorizationById(
    @Req() req: Request,
    @Res() res: Response,
    @Param() param) {
    try {
      res.status(HttpStatus.OK).json();
    } catch (error) {
      res.status(HttpStatus.BAD_REQUEST).json(error);
    }
    return;
  }

  @Post('/test')
  async test(
    @Req() req: Request,
    @Res() res: Response,
    @Body() inputData: any) {
    try {
      res.status(HttpStatus.OK).json("okay");
    } catch (error) {
      res.status(HttpStatus.BAD_REQUEST).json(error);
    }
    return;
  }

  @Post('add-workAuthorization')
  async createWorkAuthorization(
    @Req() req: Request,
    @Res() res: Response,
    @Body() body: WorkAuthorizationDTO,
  ) {
    try {
      const createdWorkAuthorization = await this.workAuthorizationService.createWorkAuthorization(body);
      res.status(HttpStatus.OK).json(createdWorkAuthorization);
    } catch (error) {
      res.status(HttpStatus.BAD_REQUEST).json(error);
    }
  }

  @Post('/edit-workAuthorization')
  async editJob(
    @Req() req: Request,
    @Res() res: Response,
    @Body() body: WorkAuthorizationDTO,
  ) {
    try {
      const workAuthorizationResult = await this.workAuthorizationService.updateWorkAuthorization(body);
      res.status(HttpStatus.OK).json(workAuthorizationResult);
    } catch (error) {
      console.log('error: ', error);
      res.status(HttpStatus.BAD_REQUEST).json(error);
    }
  }
  
  @Post('/delete-workAuthorization')
  async deleteWorkAuthorization(
    @Req() req: Request,
    @Res() res: Response,
    @Body() body: any,
    ) {
      try {
      console.log('body: ', body);
      const jobDataResult = await this.workAuthorizationService.deleteWorkAuthorization(body.id);
      res.status(HttpStatus.OK).json("okay");
    } catch (error) {
      console.log('error: ', error);
      res.status(HttpStatus.BAD_REQUEST).json(error);
    }
  }
}