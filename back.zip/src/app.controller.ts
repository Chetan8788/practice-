import { User } from './user.model';
import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
} from '@nestjs/common';
import { AppService } from './app.service';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  //Route to add employees
  @Post()
  async createUser(@Body() userDto: User) {
    return await this.appService.createEmployee(userDto);
  }
  //Route to fetch all employee
  @Get()
  async fetchAll() {
   return await this.appService.fetchAll();
  }
  //Route to fetch employee by id
  @Get(':id')
  async fetchEmployee(@Param('id') id: Object) {
    return await this.appService.fetchEmployee(id);
  }
  //Route to update employee by id
  @Put(':id')
  async updateEmployee(@Param('id') id: Object, @Body() userDto: User) {
    return await this.appService.updateEmployee(id, userDto);
  }
  //Route to delete employee by id
  @Delete(':id')
  async deleteEmployee(@Param('id') id: Object) {
    return await this.appService.deleteEmployee(id);
  }
}
