//Logic
import { User, UserDocument } from './user.model';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
@Injectable()
export class AppService {
  constructor(
    @InjectModel('user') private readonly userModel: Model<UserDocument>,
  ) {}
  //Controller function to add new employee into db
  async createEmployee(user: User): Promise<User> {
    const newUser = new this.userModel(user);
    return newUser.save();
  }
  //Controller function to fetch all employee
  async fetchAll(): Promise<User[]> {
    return this.userModel.find().exec();
  }
  //Controller function to fetch particular employee from db
  async fetchEmployee(id: Object) {
    return this.userModel.findById(id);
  }
  //Controller function to update employee
  async updateEmployee(id: Object, user: User): Promise<User> {
    return this.userModel.findByIdAndUpdate(id, user);
  }
  //Controller function to delete employee
  async deleteEmployee(id: Object) {
    return this.userModel.findByIdAndRemove(id);
  }
}
