module.exports = {
  development: {
    username: 'crud',
    password: 'root',
    database: 'crud',
    host: 'localhost',
    dialect: 'mysql',
    port: '3307',
  },
  test: {
    username: 'crud',
    password: 'root',
    database: 'crud',
    host: 'localhost',
    dialect: 'mysql',
    port: '3307',
  },
  production: {
    username: 'crud',
    password: 'root',
    database: 'crud',
    host: 'localhost',
    dialect: 'mysql',
    port: '3307',
  },
};
