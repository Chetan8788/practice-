//Defining Schema for User Model
import { Schema, Prop,SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type UserDocument = User & Document;
@Schema()
export class User {
  @Prop()
  name: string;
  @Prop()
  userName: string;
  @Prop()
  password: string;
  @Prop()
  gender: string;
  @Prop({ default: Date.now })
  joining_date: Date;
}
export const UserSchema = SchemaFactory.createForClass(User);