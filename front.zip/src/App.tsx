import React from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { AddEmployee } from './pages/AddEmployee/addEmployee';
import { AllEmployee } from './pages/AllEmployee/allEmployee';
import { UpdateEmployee } from './pages/AllEmployee/UpdateEmployee';
import { DetailsEmployee } from './pages/detailsEmployee/DetailsEmployee';

function App() {
  return (
    <>
      <BrowserRouter>

        <Routes>

          <Route path="/">

            <Route index element={<AddEmployee />} />

          </Route>
          <Route path="/view-employee" element={<AllEmployee />} />
          <Route path="/update-employee" element={<UpdateEmployee />} />
          <Route path="/details-employee" element={<DetailsEmployee />} />

        </Routes>

      </BrowserRouter>
    </>
  );
}

export default App;
