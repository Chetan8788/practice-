import axios from "axios";
import { AppDispatch, RootState } from "../redux/store";
import { API_URL } from "./serverConnection";
import {
  ADD_EMPLOYEE,
  ADD_EMPLOYEE_ERROR,
  ALL_EMPLOYEE,
  ALL_EMPLOYEE_ERROR,
  COMMON,
  DELETE_EMPLOYEE,
  DELETE_EMPLOYEE_ERROR,
  GET_EMPLOYEE,
  GET_EMPLOYEE_ERROR,
  UPDATE_EMPLOYEE,
  UPDATE_EMPLOYEE_ERROR,
} from "./types";
import Swal from "sweetalert2";

export const addEmployee =
  (name: string, userName: string, password: string, gender: string) =>
  async (dispatch: AppDispatch, getState: RootState) => {
    // const { userDetails } = getState().;
    try {
      //   dispatch({ type: ADD_EMPLOYEE });

      const result = await axios.post(`${API_URL}`, {
        name,
        userName,
        password,
        gender,
      });
      dispatch({
        type: ADD_EMPLOYEE,
        payload: result?.data,
      });
      console.log("add emp result :: ", result?.data);
      Swal.fire({
        icon: "success",
        title: "Success",
        timer: 1500,
      });

      //   dispatch({ type: STOP_LOADING });
    } catch (err) {
      dispatch({
        type: ADD_EMPLOYEE_ERROR,
        payload:
          (err as any)?.response?.data?.message ||
          "Unable to fetch records at the moment. Please Try Again.",
      });
      Swal.fire({
        icon: "error",
        title: "Error",
        text: (err as any).response?.data?.message,
      });
    }
  };

// export const displayEmployees = () => async (dispatch: AppDispatch, getState: RootState) => {
//   try {
//     const result = await axios.get(`${API_URL}`);
//     console.log("result", result)
//     dispatch({
//       type: ALL_EMPLOYEE,
//       payload: result?.data,
//     });
//   } catch (err) {
//     console.log("result", err)
//     dispatch({
//       type: ALL_EMPLOYEE_ERROR,
//       payload:
//         (err as any)?.response?.data?.message ||
//         "Unable to fetch records at the moment. Please Try Again.",
//     });
//   }
// };

export const displayEmployees =
  () => async (dispatch: AppDispatch, getState: RootState) => {
    try {
      const result = await axios.get(
        API_URL //   { //   headers: { "Content-Type": "application/json" }, // }
      );
      console.log("result", result);
      dispatch({
        type: ALL_EMPLOYEE,

        payload: result?.data,
      });
    } catch (err) {
      dispatch({
        type: ALL_EMPLOYEE_ERROR,
        payload:
          (err as any)?.response?.data?.message ||
          "Unable to fetch records at the moment. Please Try Again.",
      });
    }
  };

export const updateEmployee =
  (
    _id: any,
    name: string,
    userName: string,
    password: string,
    gender: string
  ) =>
  async (dispatch: AppDispatch, getState: RootState) => {
    try {
      //   dispatch({ type: ADD_EMPLOYEE });

      const result = await axios.put(`${API_URL}/${_id}`, {
        name,
        userName,
        password,
        gender,
      });
      dispatch({
        type: UPDATE_EMPLOYEE,
        payload: result?.data,
      });
      console.log("employees ::", result?.data);
      Swal.fire({
        icon: "success",
        title: "Success",
        timer: 1500,
      });

      //   dispatch({ type: STOP_LOADING });
    } catch (err) {
      dispatch({
        type: UPDATE_EMPLOYEE_ERROR,
        payload:
          (err as any)?.response?.data?.message ||
          "Unable to fetch records at the moment. Please Try Again.",
      });
      Swal.fire({
        icon: "error",
        title: "Error",
        text: (err as any).response?.data?.message,
      });
    }
  };

export const deleteEmployee =
  (_id: any) => async (dispatch: AppDispatch, getState: RootState) => {
    try {
      //   dispatch({ type: ADD_EMPLOYEE });

      const result = await axios.delete(`${API_URL}/${_id}`, {});
      console.log(result);
      dispatch({
        type: DELETE_EMPLOYEE,
        payload: result?.data?._id,
      });
      // displayEmployees();
      console.log("employees ::", result?.data);
      Swal.fire({
        icon: "success",
        title: "Success",
        timer: 1500,
      });

      //   dispatch({ type: STOP_LOADING });
    } catch (err) {
      dispatch({
        type: DELETE_EMPLOYEE_ERROR,
        payload:
          (err as any)?.response?.data?.message ||
          "Unable to fetch records at the moment. Please Try Again.",
      });
      Swal.fire({
        icon: "error",
        title: "Error",
        text: (err as any).response?.data?.message,
      });
    }
  };

export const getEmployee =
  (_id: any) => async (dispatch: AppDispatch, getState: RootState) => {
    try {
      //   dispatch({ type: ADD_EMPLOYEE });

      const result = await axios.get(`${API_URL}/${_id}`, {});
      dispatch({
        type: GET_EMPLOYEE,
        payload: result?.data,
      });

      console.log("employee ::", result?.data);
      Swal.fire({
        icon: "success",
        title: "Success",
        timer: 1500,
      });

      //   dispatch({ type: STOP_LOADING });
    } catch (err) {
      dispatch({
        type: GET_EMPLOYEE_ERROR,
        payload:
          (err as any)?.response?.data?.message ||
          "Unable to fetch records at the moment. Please Try Again.",
      });
      Swal.fire({
        icon: "error",
        title: "Error",
        text: (err as any).response?.data?.message,
      });
    }
  };
export const updateEmployeId = (id: any) => {
  return {
    type: COMMON.SELECTED_EMPID,
    payload: id,
  };
};
