import { History } from "history";
import { useEffect, useState } from "react";
import "./addEmployee.css";
import { Form, Button } from "react-bootstrap";
import { useAppDispatch } from "../../hooks/app";
import { addEmployee } from "../../actions/employee";
import { useDispatch } from "react-redux";


interface Props {
  onSubmit?: any;
}

export const AddEmployee: React.FC<Props> = () => {

  const [name, setName] = useState<string>("");
  const [userName, setUserName] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [gender, setGender] = useState<string>("");
  const [nameError, setNameError] = useState<string>("");
  const [usernameError, setUserameError] = useState<string>("");
  const [passwordError, setPasswordError] = useState<string>("");
  const [genderError, setGenderError] = useState<string>("");


  const dispatch = useDispatch<any>();

  const handleClick = async () => {

    dispatch(
      addEmployee(
        name,
        userName,
        password,
        gender,
      )
    );

    window.location.reload();

  }

  return (
    <div className="main-body">
      <img src="https://png.pngtree.com/thumb_back/fh260/back_pic/03/89/08/5457d7c12177f21.jpg"/>
    <div className="add-employee-container">
      <input placeholder="enter name" value={name} onChange={(e) => setName(e.target.value)} />
      <input placeholder="enter email"  value={userName} onChange={(e) => setUserName(e.target.value)} />
      <input placeholder="set password" value={password} onChange={(e) => setPassword(e.target.value)} />
      <input placeholder="enter gender" value={gender} onChange={(e) => setGender(e.target.value)} />
      <button onClick={handleClick}>Add Employee</button>
    </div>
    </div>
  )
}