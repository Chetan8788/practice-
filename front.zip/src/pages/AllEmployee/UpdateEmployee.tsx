import { History } from "history";
import { useEffect, useState } from "react";
import { Form, Button } from "react-bootstrap";
import { useAppDispatch } from "../../hooks/app";
import { addEmployee, updateEmployee } from "../../actions/employee";
import { useDispatch } from "react-redux";
import { useLocation } from "react-router-dom";


interface Props {
    onSubmit?: any;
}

export const UpdateEmployee: React.FC<Props> = () => {

    const state = useLocation();


    //   const[id,setId] = useState<any>();
    const id = state.state;
    console.log("id :: ",state.state);
    const [name, setName] = useState<string>("");
    const [userName, setUserName] = useState<string>("");
    const [password, setPassword] = useState<string>("");
    const [gender, setGender] = useState<string>("");

    useEffect(() => {

    }, []);

    const dispatch = useDispatch<any>();

    const handleClick = async (name: string, userName: string, password: string, gender: string) => {

        dispatch(
            updateEmployee(
                id,
                name,
                userName,
                password,
                gender,
            )
        );
        // onSubmit();
    }

    return (

        <div>
            {/* <input placeholder="enter id" value={id} onChange={(e) => setId(e.target.value)} /> */}
            <input placeholder="enter name" value={name} onChange={(e) => setName(e.target.value)} />
            <input placeholder="enter email" value={userName} onChange={(e) => setUserName(e.target.value)} />
            <input placeholder="set password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <input placeholder="enter gender" value={gender} onChange={(e) => setGender(e.target.value)} />
            <button onClick={() => {
                handleClick(name, userName, password, gender)
            }}
            >update</button>
        </div>

    )
}