import { useDispatch, useSelector } from "react-redux";
import { useAppDispatch, useAppSelector } from "../../hooks/app";
import { RootState } from "../../redux/store";
import { addEmployee, deleteEmployee, displayEmployees, updateEmployeId, updateEmployee } from "../../actions/employee";
import { useEffect, useState } from "react";
import "./AllEmployee.css"
import { Navigate, useNavigate } from "react-router-dom";


export const AllEmployee: React.FC = () => {
  const [id, setId] = useState<any>();
  const [name, setName] = useState<string>("");
  const [username, setUserame] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [gender, setGender] = useState<string>("");
  const [count, setCount] = useState<any>();


  const dispatch = useDispatch<any>();

  const empState: any = useSelector((state: RootState) => state);
  const all = empState.employees

  // useEffect(() => {

  // }, []);


  const navigate = useNavigate();



  useEffect(() => {

    displayAllEmployee();
    console.log("=============================")
  }, [all.deleteEmployee]);



  const displayAllEmployee = async () => {

    dispatch(displayEmployees());

  };


  const handleRemove = async (_id: any) => {
    dispatch(deleteEmployee(_id))
    window.location.reload();
  }

  // console.log(all);




  const viewDetails = (_id: any) => {
    dispatch(updateEmployeId(_id))
    // console.log(empState.selected_empid)
    // const all: any = useSelector((state: RootState) => state.employees);
    // if (empState.selected_empid) {
    navigate("/details-employee");
    // }
  }




  if (!all) {

    return <h4>Loading</h4>;

  }

  return (

    <div className="all-employee-container">

      <img src="https://webdesigndev.com/wp-content/uploads/2015/07/Freepik.jpg" alt="" />

      <div className="App">
        <table>
          <tr>
            <th>Name</th>
            <th>Username</th>
            <th>Gender</th>
            <th>Update</th>
            <th>Delete</th>
            <th>Details</th>
          </tr>
          {all.map((element: any, index: number) => {
            // console.log("employee ::", element)
            return (
              <tbody key={index}>
                <tr>
                  <td>{element.name}</td>
                  <td>{element.userName}</td>
                  <td>{element.gender}</td>
                  <td><button onClick={() => {
                    navigate("/update-employee", { state: element._id })
                  }} >update</button></td>
                  <td><button onClick={() => {
                    handleRemove(element._id)
                  }}>remove</button></td>
                  <td><button onClick={() => {
                    viewDetails(element._id);
                  }} >details</button></td>
                </tr>
              </tbody>
            )
          })}
        </table>
      </div>
    </div>
  )
}
