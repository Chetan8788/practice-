import { useSelector } from "react-redux";
import { RootState } from "../../redux/store";
import { useEffect } from "react";



interface Props {
    onSubmit?: any;
}

export const DetailsEmployee: React.FC<Props> = () => {

    // const data: any = useSelector((state: RootState) => state.getEmployee);
    const empState: any = useSelector((state: RootState) => state);
    useEffect(() => {
        console.log("id:: ", empState.selected_empid);
    }, [])

    // const data = empState.getEmployee(empState.selected_empid);
    // console.log("data:: ",data);



    return (
        <div className=""></div>
    )
}