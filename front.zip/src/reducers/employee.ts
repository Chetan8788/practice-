// import { ADD_EMPLOYEE, ADD_EMPLOYEE_ERROR, ALL_EMPLOYEE, ALL_EMPLOYEE_ERROR } from "../actions/types";

import {
  ADD_EMPLOYEE,
  ADD_EMPLOYEE_ERROR,
  ALL_EMPLOYEE,
  ALL_EMPLOYEE_ERROR,
  COMMON,
  DELETE_EMPLOYEE,
  DELETE_EMPLOYEE_ERROR,
  GET_EMPLOYEE,
  GET_EMPLOYEE_ERROR,
  UPDATE_EMPLOYEE,
  UPDATE_EMPLOYEE_ERROR,
} from "../actions/types";

interface Actions {
  payload: any;
  type: string;
}

interface EmployeeInterface {
  addEmployee: any;
  addEmployeeError: string;
  employees: any;
  allEmployeeError: string;
  updateEmployee: any;
  updateEmployeeError: string;
  deleteteEmployee: any;
  deleteteEmployeeError: string;
  getEmployee: any;
  getEmployeeError: string;
  selected_empid: string;
}

export type State = EmployeeInterface;

// //   export const initialState: State = {
// //     adminDetails: undefined,
// //     adminDetailsError: "",
// //     addAdmin: undefined,
// //     addAdminError: "",
// //   };

export const initialState: State = {
  addEmployee: undefined,

  addEmployeeError: "",

  employees: [],

  allEmployeeError: "",

  updateEmployee: undefined,

  updateEmployeeError: "",

  deleteteEmployee: undefined,

  deleteteEmployeeError: "",

  getEmployee: [],

  getEmployeeError: "",
  selected_empid: "",
};

export const EmployeeReducer = (
  state: State = initialState,
  action: Actions
) => {
  switch (action.type) {
    case ADD_EMPLOYEE:
      return {
        ...state,
        addEmployee: action.payload,
        addEmployeeError: "",
      };
    case ADD_EMPLOYEE_ERROR:
      return {
        ...state,
        addEmployee: [],
        addEmployeeError: action.payload,
      };
    case ALL_EMPLOYEE:
      return {
        ...state,
        employees: action.payload,
        allEmployeeError: "",
      };
    case ALL_EMPLOYEE_ERROR:
      return {
        ...state,
        allEmployee: [],
        allEmployeeError: action.payload,
      };

    case UPDATE_EMPLOYEE:
      return {
        ...state,
        updateEmployee: action.payload,
        updateEmployeeError: "",
      };
    case UPDATE_EMPLOYEE_ERROR:
      return {
        ...state,
        updateEmployee: [],
        updateEmployeeError: action.payload,
      };

    case DELETE_EMPLOYEE:
      return {
        ...state,
        deleteEmployee: action.payload,
        deleteEmployeeError: "",
      };
    case DELETE_EMPLOYEE_ERROR:
      return {
        ...state,
        deleteEmployee: [],
        deleteEmployeeError: action.payload,
      };

    case GET_EMPLOYEE:
      return {
        ...state,
        getEmployee: action.payload,
        getEmployeeError: "",
      };
    case GET_EMPLOYEE_ERROR:
      return {
        ...state,
        getEmployee: [],
        deleteEmployeeError: action.payload,
      };

    case COMMON.SELECTED_EMPID:
      return {
        ...state,
        selected_empid: action.payload,
      };

    default:
      return state;
  }
};

// const initialState = {
//   addEmployee: undefined,

//   addEmployeeError: "",

//   employees: [],

//   allEmployeeError: "",

//   updateEmployee: undefined,
// };

// export const  EmployeeReducer = (state = initialState, { type, payload }: Actions) => {
//   switch (type) {
//     case ALL_EMPLOYEE:
//       return { ...state, employees: payload };

//     case ADD_EMPLOYEE:
//       return { ...state, addEmployee: payload };

//     case UPDATE_EMPLOYEE:
//      return { ...state, updateEmployee: payload };

//     default:
//       return state;
//   }
// };
