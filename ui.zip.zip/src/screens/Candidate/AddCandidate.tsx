import React, { useEffect, useState } from "react";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import Fab from "@mui/material/Fab";
import EastIcon from "@mui/icons-material/East";
import WestIcon from "@mui/icons-material/West";
import "./AddCandidate.css";
import CandidateDetails from "./CandidateDetails";
import ClientDetails from "../Client/ClientDetails";
import { Box } from "@mui/material";
import VendorDetails from "../Vendor/VendorDetails";
import ReferralDetails from "../Referral/ReferralDetails";
import JobDetails from "../Job/JobDetails";
import BackgroundVerification from "../BackgroundCheck";
import { DocumentationScreen } from "../Documentation";
import StartEndOperationsScreen from "../StartEndOperations";
import RateRevisionScreen from "../RateRevision";
import { useAppDispatch } from "../../hooks/app";
import { allClientData } from "../../actions/client";
import { allJobData } from "../../actions/job";
import { allVendorData } from "../../actions/vendor";
import BasicDetails from "./BasicDetails";
import { useLocation } from "react-router";

const AddCandidate: React.FC = () => {
  const dispatch = useAppDispatch();
  const [stepCount, setStepCount] = useState(1);
  const location = useLocation();

  const steps = [
    "Basic Details",
    "Background Check",
    "Documentation",
    "Start/End Operations",
    "Rate Revision",
  ];
  const [referral, setReferral] = useState<Boolean>(false);
  const [nextButtonClick, setNextButtonClick] = useState<Boolean>(false);
  const [valid, setValid] = useState<Boolean>(false);

  useEffect(() => {
    dispatch(allClientData())
    dispatch(allJobData())
    dispatch(allVendorData())
  });

  const next = () => {
    // setNextButtonClick(true);
    // console.log('valid: ', valid);

    if (stepCount < steps.length) {
      setStepCount(stepCount + 1);
    }
  };

  const previous = () => {
    if (stepCount > 1) {
      setStepCount(stepCount - 1);
    }
  };

  console.log('stepCount: ', stepCount);
  const boxStyle = {
    alignItems: 'center',
    border: 'none', flexGrow: 1,
    marginTop: "3%",
    overflowY: "auto",
    overflowX: 'hidden',
    height: "60vh",
    paddingRight: "10px",
    paddingLeft: "10px"
  }

  function showReferral() {
    if (referral) {
      return <ReferralDetails />
    }
  }

  function showStepScreens(stepCount: any) {
    switch (stepCount) {
      case 1:
        return <Box sx={boxStyle}>
          <BasicDetails />
        </Box>
      case 2:
        return <Box sx={boxStyle}>
          <BackgroundVerification />
        </Box>
      case 3:
        return <Box sx={boxStyle}>
          <DocumentationScreen />
        </Box>
      case 4:
        return <Box sx={boxStyle}>
          <StartEndOperationsScreen />
        </Box>
      case 5:
        return <Box sx={boxStyle}>
          <RateRevisionScreen />
        </Box>
      default:
        return <Box sx={boxStyle}>
          <>Error</>
        </Box>;
    }
  }

  return (
    <>
      <Stepper activeStep={stepCount - 1} alternativeLabel>
        {steps.map((label, index) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

      {showStepScreens(stepCount)}

      <div className="add-footer">

        <span className="add-button">
          {stepCount > 1 &&
            <Fab size="small" color="primary" aria-label="add" onClick={previous}>
              <WestIcon />
            </Fab>
          }
        </span>

        <span style={{ marginRight: "1%", marginLeft: "1%" }}>
          {stepCount < 5 &&
            <Fab size="small" color="primary" aria-label="add" onClick={next}>
              <EastIcon />
            </Fab>
          }
        </span>
      </div>
    </>
  );
};

export default AddCandidate;
