import * as React from 'react';
import { useSpring, animated } from '@react-spring/web';
import { TextField } from "../../common/TextField/TextField";
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import Select from "react-select";
import { Button } from '../../common/Button/Button';
import { RootState } from '../../redux/store';
import { LocationName } from '../../constants/candidateclientconstants';
import ShowIndividualAddress from '../Address/ShowIndividualAddress';
import { editCandidateData } from '../../actions/candidate';
import moment from "moment";
import { TextField as TextField1 } from '@mui/material';

interface FadeProps {
  children: React.ReactElement;
  in?: boolean;
  onClick?: any;
  onEnter?: (node: HTMLElement, isAppearing: boolean) => void;
  onExited?: (node: HTMLElement, isAppearing: boolean) => void;
  ownerState?: any;
}

const Fade = React.forwardRef<HTMLDivElement, FadeProps>(function Fade(props, ref) {
  const {
    children,
    in: open,
    onClick,
    onEnter,
    onExited,
    ownerState,
    ...other
  } = props;
  const style = useSpring({
    from: { opacity: 0 },
    to: { opacity: open ? 1 : 0 },
    onStart: () => {
      if (open && onEnter) {
        onEnter(null as any, true);
      }
    },
    onRest: () => {
      if (!open && onExited) {
        onExited(null as any, true);
      }
    },
  });

  return (
    <animated.div ref={ref} style={style} {...other}>
      {React.cloneElement(children, { onClick })}
    </animated.div>
  );
});

const style = {
  position: 'absolute' as 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '1px #000',
  boxShadow: 24,
  p: 4,
  borderRadius: "10px",
};

interface Props {
  open: any,
  setOpen: any,
  data: any,
  showTableCount: any,
  int: any,
  setShowModal: any,
}

const ShowCandidate: React.FC<Props> = ({ open, setOpen,
  // data, 
  showTableCount, int, setShowModal }) => {
  const dispatch = useAppDispatch();
  let data = useAppSelector((state: RootState) => state?.candidate?.singleCandidateData);
  let workAuthorizationData = useAppSelector((state: RootState) => state.workAuthorization.allWorkAuthorizationData);
  var workAuthorizationResult: any = [];
  if (workAuthorizationData != undefined) {
    workAuthorizationData.forEach((element: { id: number, workAuthorization: any; }) => {
      workAuthorizationResult.push({
        label: element.workAuthorization,
        value: element.workAuthorization
      });
    });
  }
  const [disable, setDisable] = React.useState(true);
  const [firstName, setFirstName] = React.useState(data?.candidateId?.firstName);
  const [middleName, setMiddleName] = React.useState(data?.candidateId?.middleName);
  const [lastName, setLastName] = React.useState(data?.candidateId?.lastName);
  // const [line1, setLine1] = React.useState(data?.addressId[0].line1);
  // const [line2, setLine2] = React.useState(data?.addressId[0].line2);
  // const [city, setCity] = React.useState(data?.addressId[0].city);
  // const [state, setState] = React.useState({
  //   label: data?.addressId[0].state,
  //   value: data?.addressId[0].state,
  // });
  // const [zipCode, setZipCode] = React.useState(data?.addressId[0].zipCode);
  // const [country, setCountry] = React.useState(data?.addressId[0].country);
  // const [email, setEmail] = React.useState(data?.addressId[0].contactDetailId.email);
  // const [contactNumber, setContactNumber] = React.useState(data?.addressId[0].contactDetailId.contactNumber);
  const [workAuthorization, setWorkAuthorization] = React.useState({
    label: data?.candidateId?.workAuthorization,
    value: data?.candidateId?.workAuthorization,
  });
  const [workAuthorizationExpiryDate, setWorkAuthorizationExpiryDate] = React.useState(moment.utc(data?.candidateId?.workAuthorizationExpiryDate).format('YYYY-MM-DD'));

  const [count, setCount] = React.useState(0);
  const locationName = LocationName;

  React.useEffect(() => {
    setFirstName(data?.candidateId?.firstName);
    setMiddleName(data?.candidateId?.middleName);
    setLastName(data?.candidateId?.lastName);
    setWorkAuthorizationExpiryDate(moment.utc(data?.candidateId?.workAuthorizationExpiryDate).format('YYYY-MM-DD'));
    setWorkAuthorization({
      label: data?.candidateId?.workAuthorization,
      value: data?.candidateId?.workAuthorization,
    });
    console.log('workAuthorizationExpiryDate: ', workAuthorizationExpiryDate);
    setCount(1);
  }, [data])

  function updateCandidate() {
    dispatch(editCandidateData({
      id: data?.candidateId?.id,
      firstName: firstName,
      middleName: middleName,
      lastName: lastName,
      workAuthorizationExpiryDate: workAuthorizationExpiryDate
    }));
    setShowModal(false);
  }

  function renderAddress(data1: any) {
    // return <ShowIndividualAddress data={data1} setShowModal={true} />
  }

  return (
    <div>
      <div id="no-scroll-div" className="relative w-[100%] mt-2 shadow-2xl h-[75vh] overflow-auto">
        <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
          <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
            <tr>
              <th scope="col" className="px-6 py-3">
                {/* <span>Client name</span> */}
              </th>
              <th>

              </th>
            </tr>
          </thead>
          <tbody>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>Candidate first name</span>
              </td>
              <td className='px-6 py-0'>
                <TextField
                  value={firstName}
                  placeholder={""}
                  handleChange={(event) => {
                    setFirstName(event?.target?.value);
                  }}
                  className=""
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>Candidate middle name</span>
              </td>
              <td className='px-6 py-0'>
                <TextField
                  value={middleName}
                  placeholder={""}
                  handleChange={(event) => {
                    setMiddleName(event?.target?.value);
                  }}
                  className=""
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>Candidate last name</span>
              </td>
              <td className='px-6 py-0'>
                <TextField
                  value={lastName}
                  placeholder={""}
                  handleChange={(event) => {
                    setLastName(event?.target?.value);
                  }}
                  className=""
                />
              </td>
            </tr>
            {
              data?.addressId?.length &&
              data?.addressId?.map((data1: any, index: any) => (
                <>
                  <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                    <td className='px-6 py-4'>
                      <h1>Address {index + 1}</h1>
                    </td>
                  </tr>
                  {renderAddress(data1)}
                </>
              ))
            }
            {/* <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>Line 1</span>
              </td>
              <td className='px-6 py-0'>
                <TextField
                  value={line1}
                  placeholder={""}
                  handleChange={(event) => {
                    setLine1(event?.target?.value);
                  }}
                  className=""
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>Line 2</span>
              </td>
              <td className='px-6 py-0'>
                <TextField
                  value={line2}
                  placeholder={""}
                  handleChange={(event) => {
                    setLine2(event?.target?.value);
                  }}
                  className=""
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>City</span>
              </td>
              <td className='px-6 py-0'>
                <TextField
                  value={city}
                  placeholder={""}
                  handleChange={(event) => {
                    setCity(event?.target?.value);
                  }}
                  className=""
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>State</span>
              </td>
              <td className='px-6 py-0'>
                <Select
                  options={locationName}
                  value={state}
                  getOptionLabel={(option) => option.label}
                  getOptionValue={(option) => option.value}
                  onChange={(e: any) => {
                    setState(e);
                  }}
                  isSearchable={true}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>Zip code</span>
              </td>
              <td className='px-6 py-0'>
                <TextField
                  value={zipCode}
                  placeholder={""}
                  handleChange={(event) => {
                    setZipCode(event?.target?.value);
                  }}
                  className=""
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>Country</span>
              </td>
              <td className='px-6 py-0'>
                <TextField
                  value={country}
                  placeholder={""}
                  handleChange={(event) => {
                    setCountry(event?.target?.value);
                  }}
                  className=""
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>Candidate email address</span>
              </td>
              <td className='px-6 py-0'>
                <TextField
                  value={email}
                  placeholder={""}
                  handleChange={(event) => {
                    setEmail(event?.target?.value);
                  }}
                  className=""
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>Candidate contact no.</span>
              </td>
              <td className='px-6 py-0'>
                <TextField
                  value={contactNumber}
                  placeholder={""}
                  handleChange={(event) => {
                    setContactNumber(event?.target?.value);
                  }}
                  className=""
                />
              </td>
            </tr> */}
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>Work authorization</span>
              </td>
              <td className='px-6 py-0'>
                <Select
                  // options={workAuthorization}
                  options={workAuthorizationResult}
                  value={workAuthorization}
                  getOptionLabel={(option) => option.label}
                  getOptionValue={(option) => option.value}
                  onChange={(e: any) => {
                    setWorkAuthorization(e);
                  }}
                  isSearchable={true}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>Work authorization expiry date</span>
              </td>
              <td className='px-6 py-0'>
                {/* <TextField
                  value={workAuthorizationExpiryDate}
                  placeholder={""}
                  handleChange={(event) => {
                    setWorkAuthorizationExpiryDate(event?.target?.value);
                  }}
                  className=""
                /> */}
                <TextField1
                  // label="Secondary BGC Initiated On"
                  value={workAuthorizationExpiryDate}
                  type="date"
                  placeholder={""}
                  onChange={(event) =>
                    setWorkAuthorizationExpiryDate(event?.target?.value)
                  }
                />
              </td>
            </tr>
          </tbody>
        </table>
        <div className='m-auto w-[50%]'>
          <Button
            className='w-[50px] text-white'
            value="Update"
            handleClick={() => {
              updateCandidate()
            }}
          />
        </div>
      </div>
    </div>
  );
}

export default ShowCandidate;