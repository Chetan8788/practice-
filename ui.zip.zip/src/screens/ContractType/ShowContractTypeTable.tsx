import React, { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { RootState } from '../../redux/store';
import Button from '@mui/material/Button';
import { Link } from "react-router-dom";
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import ShowContractType from './ShowIndividualContractType';
import { deleteContractTypeData } from '../../actions/contractType';

const ShowContractTypeTable: React.FC = () => {
    const dispatch = useAppDispatch();
    let contractTypeData = useAppSelector((state: RootState) => state.contractType.allContractTypeData);
    let contractTypeDataRow = contractTypeData;
    const [open, setOpen] = useState(false);
    const [singleContractTypeData, setSingleContractTypeData] = useState({});
    const [filteredData, setFilteredData] = useState(contractTypeData);
    const [count, setCount] = useState(true);

    useEffect(() => {
        if (count) {
            if (contractTypeData.length !== 0) {
                setFilteredData(contractTypeData.filter((cd: { contractType: string }) =>
                    cd.contractType.toLowerCase().includes("")
                ));
                setCount(false);
            }
        }
    }, [contractTypeData])

    const filterResult = (event: any) => {
        setFilteredData(contractTypeDataRow);
        let value: string = event.target.value;

        if (contractTypeData.length !== 0) {
            setFilteredData(contractTypeData.filter((cd: { contractType: string }) =>
                cd.contractType.toLowerCase().includes(value.toLowerCase())
            ))
        }
    }

    const showContractType = (data: any) => {
        setSingleContractTypeData(data);
        setOpen(true);
    }

    function deleteContractType(id: any): void {
        dispatch(deleteContractTypeData(id));
        setCount(true);
    }

    function onSubmitClick() {
        throw new Error('Function not implemented.');
    }

    return (
        <>
            <div style={{ display: "flex" }}>
                <div style={{ borderRadius: "15px", marginBottom: "10px", width: "90%" }} className="py-3 px-4">
                    <div className="relative max-w">
                        <label htmlFor="hs-table-search" className="sr-only">Search</label>
                        <input style={{ border: '0.5px solid gray' }} type="text" name="hs-table-search" id="hs-table-search" className="ml-[-13px] p-2 pl-10 block w-[35%] border-gray-200 rounded-md text-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400" placeholder="Search for contract types" onChange={(event) => filterResult(event)} />
                        <div className="absolute inset-y-0 left-0 flex items-center pointer-events-none pl-2">
                            <svg className="h-3.5 w-3.5 text-gray-400" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                            </svg>
                        </div>
                    </div>
                </div>
                <div style={{ width: "10%", maxHeight: "100%", justifyContent: "center", alignContent: "center" }}>
                    <Button variant="contained" component={Link} to={"/add-contract-type"}>Add contract type</Button>
                </div>
            </div>
            <div className="flex flex-col" style={{ height: "70vh" }}>
                <div className="-m-1.5 overflow-x-auto">
                    <div className="p-1.5 min-w-full inline-block align-middle">
                        <div className="border rounded-lg divide-y divide-gray-200 dark:border-gray-700 dark:divide-gray-700">

                            <div className="overflow-hidden">
                                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                    <thead className="bg-gray-50 dark:bg-gray-700">
                                        <tr>
                                            <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Contract type</th>
                                            <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                                        {
                                            (() => {
                                                if (contractTypeDataRow?.length !== 0 && filteredData?.length !== 0) {
                                                    return (
                                                        filteredData.map((data: any, index: any) => (
                                                            <tr key={index} onClick={() => showContractType({
                                                                id: data.id,
                                                                contractType: data.contractType,
                                                            })}>
                                                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{data.contractType}</td>
                                                                <td className="px-6 py-4 whitespace-nowrap text-center text-sm font-medium" onClick={(e) => e.stopPropagation()}>
                                                                    <button className="text-blue-500 hover:text-blue-700" onClick={() => deleteContractType(data.id)}>
                                                                        <DeleteForeverIcon></DeleteForeverIcon>
                                                                    </button>
                                                                </td>
                                                            </tr>
                                                        ))
                                                    )
                                                }
                                            })()
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div >
            </div >
            <ShowContractType open={open} setOpen={setOpen} data={singleContractTypeData} showTableCount={setCount} />
        </>
    )
}

export default ShowContractTypeTable;