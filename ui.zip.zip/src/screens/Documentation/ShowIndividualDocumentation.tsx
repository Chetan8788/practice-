import * as React from 'react';
import Backdrop from '@mui/material/Backdrop';
import Box from '@mui/material/Box';
// import Modal from '@mui/material/Modal';
// import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { useSpring, animated } from '@react-spring/web';
import CloseIcon from '@mui/icons-material/Close';
import EditIcon from '@mui/icons-material/Edit';
import DoneIcon from '@mui/icons-material/Done';
import { TextField } from "../../common/TextField/TextField";
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { ArticlesOfIncorporationList, CertificateOfInsuranceList, CipcicaCipcicuList, ClientTaskOrderOrSOWList, ClientTaskOrderOrSOWStepList, ClientTaskOrderSigningList, DirectDepositeAgreementList, DocumentationStatusList, EVerifyList, EemergencyFormList, GoodStandingDocumentationList, I9FormList, ListADocumentsList, ListBDocumentsList, ListCDocumentsList, MSAList, SOWList, VaccinationStatusList, VoidCheckEmailList, W9W4List, WorkAuthorizeDocumentationList } from '../../constants/constants';
import Select from "react-select";
import { Modal } from '../../common/Modal/Modal';
import { DropDown } from '../../common/DropDown/DropDown';
import { DatePicker } from '../../common/DatePicker/DatePicker';
import moment from "moment";
import { Button } from '../../common/Button/Button';
import { editCandidateDocumentationData } from '../../actions/documentation';
import { RootState } from '../../redux/store';

interface FadeProps {
  children: React.ReactElement;
  in?: boolean;
  onClick?: any;
  onEnter?: (node: HTMLElement, isAppearing: boolean) => void;
  onExited?: (node: HTMLElement, isAppearing: boolean) => void;
  ownerState?: any;
}

const Fade = React.forwardRef<HTMLDivElement, FadeProps>(function Fade(props, ref) {
  const {
    children,
    in: open,
    onClick,
    onEnter,
    onExited,
    ownerState,
    ...other
  } = props;
  const style = useSpring({
    from: { opacity: 0 },
    to: { opacity: open ? 1 : 0 },
    onStart: () => {
      if (open && onEnter) {
        onEnter(null as any, true);
      }
    },
    onRest: () => {
      if (!open && onExited) {
        onExited(null as any, true);
      }
    },
  });

  return (
    <animated.div ref={ref} style={style} {...other}>
      {React.cloneElement(children, { onClick })}
    </animated.div>
  );
});

const style = {
  position: 'absolute' as 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '1px #000',
  boxShadow: 24,
  p: 4,
  borderRadius: "10px",
};

interface Props {
  open: any,
  setOpen: any,
  data: any,
  showTableCount: any,
  int: any,
  setShowModal: any,
}

const ShowDocumentation: React.FC<Props> = ({ open, setOpen, 
  // data, 
  showTableCount, int, setShowModal }) => {
  const dispatch = useAppDispatch();
  let data = useAppSelector((state: RootState) => state?.documentation?.singleDocumentationData);
  const [disable, setDisable] = React.useState(true);

  const [articlesOrCertificateOFIncorporation, setArticlesOrCertificateOFIncorporation] = React.useState({
    value: data?.articlesOrCertificateOFIncorporation,
    label: data?.articlesOrCertificateOFIncorporation
  });

  const [w9Orw4, setW9Orw4] = React.useState({
    value: data?.w9Orw4,
    label: data?.w9Orw4
  });
  const [directDepositAgreement, setDirectDepositAgreement] = React.useState({
    value: data?.directDepositAgreement,
    label: data?.directDepositAgreement
  });
  const [voidCheckOrEmailContent, setVoidCheckOrEmailContent] = React.useState({
    value: data?.voidCheckOrEmailContent,
    label: data?.voidCheckOrEmailContent
  });
  const [CIPCICICAOrCIPCICU, setCIPCICICAOrCIPCICU] = React.useState({
    value: data?.CIPCICICAOrCIPCICU,
    label: data?.CIPCICICAOrCIPCICU
  });
  const [goodStandingDocument, setGoodStandingDocument] = React.useState({
    value: data?.goodStandingDocument,
    label: data?.goodStandingDocument
  });
  const [workAuthorizationDocument, setWorkAuthorizationDocument] = React.useState({
    value: data?.workAuthorizationDocument,
    label: data?.workAuthorizationDocument
  });
  const [I9Form, setI9Form] = React.useState({
    value: data?.I9Form,
    label: data?.I9Form
  });
  const [listADocument, setListADocument] = React.useState({
    value: data?.listADocument,
    label: data?.listADocument
  });
  const [listBDocument, setListBDocument] = React.useState({
    value: data?.listBDocument,
    label: data?.listBDocument
  });
  const [listCDocument, setListCDocument] = React.useState({
    value: data?.listCDocument,
    label: data?.listCDocument
  });
  const [E_verify, setE_verify] = React.useState({
    value: data?.E_verify,
    label: data?.E_verify
  });
  const [E_verificationDate, setE_verificationDate] = React.useState(moment.utc(data?.E_verificationDate).format('YYYY-MM-DD'));
  const [emergencyForm, setEmergencyForm] = React.useState({
    value: data?.emergencyForm,
    label: data?.emergencyForm
  });
  const [vaccinationStatus, setVaccinationStatus] = React.useState({
    value: data?.vaccinationStatus,
    label: data?.vaccinationStatus
  });
  const [clientTaskOrderOrSOWst, setClientTaskOrderOrSOWst] = React.useState({
    value: data?.clientTaskOrderOrSOWst,
    label: data?.clientTaskOrderOrSOWst
  });
  const [MSA, setMSA] = React.useState({
    value: data?.MSA,
    label: data?.MSA
  });
  const [SOW, setSOW] = React.useState({
    value: data?.SOW,
    label: data?.SOW
  });
  const [SOWValidity, setSOWValidity] = React.useState(moment.utc(data?.SOWValidity).format('YYYY-MM-DD'));
  const [certificateOFInsuranceOrCOI, setCertificateOFInsuranceOrCOI] = React.useState({
    value: data?.certificateOFInsuranceOrCOI,
    label: data?.certificateOFInsuranceOrCOI
  });
  const [clientTaskOrderSigning, setClientTaskOrderSigning] = React.useState({
    value: data?.certificateOFInsuranceOrCOI,
    label: data?.certificateOFInsuranceOrCOI
  });
  const [TaskOrderExpiryDate, setTaskOrderExpiryDate] = React.useState(moment.utc(data?.TaskOrderExpiryDate).format('YYYY-MM-DD'));
  const [certificationOfInsurance, setCertificationOfInsurance] = React.useState(moment.utc(data?.certificationOfInsurance).format('YYYY-MM-DD'));
  const [clientTaskOrderOrSOW, setClientTaskOrderOrSOW] = React.useState({
    value: data?.clientTaskOrderOrSOW,
    label: data?.clientTaskOrderOrSOW
  });
  const [documentationStatus, setDocumentationStatus] = React.useState({
    value: data?.documentationStatus,
    label: data?.documentationStatus
  });
  const [documentationCompletionDate, setDocumentationCompletionDate] = React.useState(moment.utc(data?.documentationCompletionDate).format('YYYY-MM-DD'));
  const [documentationRemark, setDocumentationRemark] = React.useState(data?.documentationRemark);
  const [count, setCount] = React.useState(0);

  React.useEffect(() => {
    setArticlesOrCertificateOFIncorporation({
      value: data?.articlesOrCertificateOFIncorporation,
      label: data?.articlesOrCertificateOFIncorporation
    });
    setW9Orw4({
      value: data?.w9Orw4,
      label: data?.w9Orw4
    });
    setDirectDepositAgreement({
      value: data?.directDepositAgreement,
      label: data?.directDepositAgreement
    });
    setVoidCheckOrEmailContent({
      value: data?.voidCheckOrEmailContent,
      label: data?.voidCheckOrEmailContent
    });
    setCIPCICICAOrCIPCICU({
      value: data?.CIPCICICAOrCIPCICU,
      label: data?.CIPCICICAOrCIPCICU
    });
    setGoodStandingDocument({
      value: data?.goodStandingDocument,
      label: data?.goodStandingDocument
    });
    setWorkAuthorizationDocument({
      value: data?.workAuthorizationDocument,
      label: data?.workAuthorizationDocument
    });
    setI9Form({
      value: data?.I9Form,
      label: data?.I9Form
    });
    setListADocument({
      value: data?.listADocument,
      label: data?.listADocument
    });
    setListBDocument({
      value: data?.listBDocument,
      label: data?.listBDocument
    });
    setListCDocument({
      value: data?.listCDocument,
      label: data?.listCDocument
    });
    setE_verify({
      value: data?.E_verify,
      label: data?.E_verify
    });
    setE_verificationDate(moment.utc(data?.E_verificationDate).format('YYYY-MM-DD'));  
    setEmergencyForm({
      value: data?.emergencyForm,
      label: data?.emergencyForm
    });
    setVaccinationStatus({
      value: data?.vaccinationStatus,
      label: data?.vaccinationStatus
    });
    setClientTaskOrderOrSOWst({
      value: data?.clientTaskOrderOrSOWst,
      label: data?.clientTaskOrderOrSOWst
    });
    setMSA({
      value: data?.MSA,
      label: data?.MSA
    });
    setSOW({
      value: data?.SOW,
      label: data?.SOW
    });
    setSOWValidity(moment.utc(data?.SOWValidity).format('YYYY-MM-DD'));
    setCertificateOFInsuranceOrCOI({
      value: data?.certificateOFInsuranceOrCOI,
      label: data?.certificateOFInsuranceOrCOI
    });
    setClientTaskOrderSigning({
      value: data?.certificateOFInsuranceOrCOI,
      label: data?.certificateOFInsuranceOrCOI
    });
    setTaskOrderExpiryDate(moment.utc(data?.TaskOrderExpiryDate).format('YYYY-MM-DD'));
    setCertificationOfInsurance(moment.utc(data?.certificationOfInsurance).format('YYYY-MM-DD'));
    setClientTaskOrderOrSOW({
      value: data?.clientTaskOrderOrSOW,
      label: data?.clientTaskOrderOrSOW
    });
    setDocumentationStatus({
      value: data?.documentationStatus,
      label: data?.documentationStatus
    });
    setDocumentationCompletionDate(moment.utc(data?.documentationCompletionDate).format('YYYY-MM-DD'));
    setDocumentationRemark(data?.documentationRemark);
    setCount(1);
  }, [data])

  function updateCandidateDocumentation() {
    dispatch(editCandidateDocumentationData(
      articlesOrCertificateOFIncorporation,
      w9Orw4,
      directDepositAgreement,
      voidCheckOrEmailContent,
      CIPCICICAOrCIPCICU,
      goodStandingDocument,
      workAuthorizationDocument,
      I9Form,
      listADocument,
      listBDocument,
      listCDocument,
      E_verify,
      E_verificationDate,
      emergencyForm,
      vaccinationStatus,
      clientTaskOrderOrSOWst,
      MSA,
      SOW,
      SOWValidity,
      certificateOFInsuranceOrCOI,
      clientTaskOrderSigning,
      TaskOrderExpiryDate,
      certificationOfInsurance,
      clientTaskOrderOrSOW,
      documentationStatus,
      documentationCompletionDate,
      documentationRemark,
      data?.candidateId,));
      setShowModal(false);
  }

  return (
    <div>
      <div id="no-scroll-div" className="relative w-[100%] mt-2 shadow-2xl h-[75vh] overflow-auto">
        <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
          <tbody>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>CIPCICICA or CIPCICU</span>
              </td>
              <td className='px-6 py-0'>
                <Select
                  value={CIPCICICAOrCIPCICU}
                  options={CipcicaCipcicuList}
                  onChange={(e: any) => (
                    setCIPCICICAOrCIPCICU(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>E-verification Date</td>
              <td className='px-6 py-4'>
                <TextField
                  value={E_verificationDate}
                  type="date"
                  handleChange={(e: any) => {
                    setE_verificationDate(e.target.value);
                  }}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>E-verify</td>
              <td className='px-6 py-4'>
                <Select
                  value={E_verify}
                  options={EVerifyList}
                  onChange={(e: any) => (
                    setE_verify(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>I9 form</td>
              <td className='px-6 py-4'>
                <Select
                  value={I9Form}
                  options={I9FormList}
                  onChange={(e: any) => (
                    setI9Form(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>MSA</td>
              <td className='px-6 py-4'>
                <Select
                  value={MSA}
                  options={MSAList}
                  onChange={(e: any) => (
                    setMSA(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>SOW</td>
              <td className='px-6 py-4'>
                <Select
                  value={SOW}
                  options={SOWList}
                  onChange={(e: any) => (
                    setSOW(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>SOW validity</td>
              <td className='px-6 py-4'>
                <TextField
                  value={SOWValidity}
                  type="date"
                  handleChange={(e: any) => {
                    setSOWValidity(e.target.value);
                  }}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>Task order expiry date</td>
              <td className='px-6 py-4'>
                <TextField
                  value={TaskOrderExpiryDate}
                  type="date"
                  handleChange={(e: any) => {
                    setTaskOrderExpiryDate(e.target.value);
                  }}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>Articles or certificate of incorporation</td>
              <td className='px-6 py-4'>
                <Select
                  value={articlesOrCertificateOFIncorporation}
                  options={ArticlesOfIncorporationList}
                  onChange={(e: any) => (
                    setArticlesOrCertificateOFIncorporation(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>Certificate of insurance or COI</td>
              <td className='px-6 py-4'>
                <Select
                  value={certificateOFInsuranceOrCOI}
                  options={CertificateOfInsuranceList}
                  onChange={(e: any) => (
                    setCertificateOFInsuranceOrCOI(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>Certificate of insurance Date</td>
              <td className='px-6 py-4'>
                <TextField
                  value={certificationOfInsurance}
                  type="date"
                  handleChange={(e: any) => {
                    setCertificationOfInsurance(e.target.value);
                  }}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>Client task order or sow</td>
              <td className='px-6 py-4'>
                <Select
                  value={clientTaskOrderOrSOW}
                  options={ClientTaskOrderOrSOWList}
                  onChange={(e: any) => (
                    setClientTaskOrderOrSOW(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>Client task order or sow st</td>
              <td className='px-6 py-4'>
                <Select
                  value={clientTaskOrderOrSOWst}
                  options={ClientTaskOrderOrSOWStepList}
                  onChange={(e: any) => (
                    setClientTaskOrderOrSOWst(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>Client task order signing</td>
              <td className='px-6 py-4'>{data?.docData?.clientTaskOrderSigning}
                <Select
                  value={clientTaskOrderSigning}
                  options={ClientTaskOrderSigningList}
                  onChange={(e: any) => (
                    setClientTaskOrderSigning(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>Direct deposit agreement</td>
              <td className='px-6 py-4'>
                <Select
                  value={directDepositAgreement}
                  options={DirectDepositeAgreementList}
                  onChange={(e: any) => (
                    setDirectDepositAgreement(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>Documentation completion date</td>
              <td className='px-6 py-4'>
                <TextField
                  value={documentationCompletionDate}
                  type="date"
                  handleChange={(e: any) => {
                    setDocumentationCompletionDate(e.target.value);
                  }}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>Documentation status</td>
              <td className='px-6 py-4'>{data?.docData?.documentationStatus}
                <Select
                  value={documentationStatus}
                  options={DocumentationStatusList}
                  onChange={(e: any) => (
                    setDocumentationStatus(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>Emergency form</td>
              <td className='px-6 py-4'>
                <Select
                  value={emergencyForm}
                  options={EemergencyFormList}
                  onChange={(e: any) => (
                    setEmergencyForm(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>Good standing document</td>
              <td className='px-6 py-4'>{data?.docData?.goodStandingDocument}
                <Select
                  value={goodStandingDocument}
                  options={GoodStandingDocumentationList}
                  onChange={(e: any) => (
                    setGoodStandingDocument(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>List A document</td>
              <td className='px-6 py-4'>
                <Select
                  value={listADocument}
                  options={ListADocumentsList}
                  onChange={(e: any) => (
                    setListADocument(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>List B document</td>
              <td className='px-6 py-4'>
                <Select
                  value={listBDocument}
                  options={ListBDocumentsList}
                  onChange={(e: any) => (
                    setListBDocument(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>List C document</td>
              <td className='px-6 py-4'>
                <Select
                  value={listCDocument}
                  options={ListCDocumentsList}
                  onChange={(e: any) => (
                    setListCDocument(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>Vaccination status</td>
              <td className='px-6 py-4'>
                <Select
                  value={vaccinationStatus}
                  options={VaccinationStatusList}
                  onChange={(e: any) => (
                    setVaccinationStatus(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>Void check or email content</td>
              <td className='px-6 py-4'>
                <Select
                  value={voidCheckOrEmailContent}
                  options={VoidCheckEmailList}
                  onChange={(e: any) => (
                    setVoidCheckOrEmailContent(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>W9 or W4</td>
              <td className='px-6 py-4'>{data?.docData?.w9Orw4}
                <Select
                  value={w9Orw4}
                  options={W9W4List}
                  onChange={(e: any) => (
                    setW9Orw4(e)
                  )}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>Work authorization document</td>
              <td className='px-6 py-4'>{data?.docData?.workAuthorizationDocument}
                <Select
                  value={workAuthorizationDocument}
                  options={WorkAuthorizeDocumentationList}
                  onChange={(e: any) => (
                    setWorkAuthorizationDocument(e)
                  )}
                />
              </td>
            </tr>
          </tbody>
          
        </table>
        <div className='m-auto w-[50%]'>
          <Button
            className='w-[50px] text-white'
            value="Update"
            handleClick={() => {
              updateCandidateDocumentation()
            }}
          />
        </div>
      </div>
    </div>
  );
}

export default ShowDocumentation;