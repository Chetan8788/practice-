import { Documentation } from "./Documentation"


export const DocumentationScreen: React.FC = () => {

    return (
        <Documentation />
    )

}