import React, { ChangeEvent, useState } from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { TextField } from '../../common/TextField/TextField';
import { TextArea } from '../../common/TextArea/TextArea';
import { saveJobData, setJobInputBoxValue } from '../../actions/job';
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { RootState } from '../../redux/store';
import { DropDown } from '../../common/DropDown/DropDown';
import { Button } from '../../common/Button/Button';
import Select from 'react-select';
import { isTextValid } from '../../helpers/validate';
import { JobTypeList, LineOfBusinessList, ResumeSourceList, WorkTypeList } from '../../constants/jobconstants';

const AddJobDetails: React.FC = () => {
    const dispatch = useAppDispatch();
    const currentJobData = useAppSelector((state: RootState) => state.job.jobData);
    const workType = WorkTypeList;
    const jobType = JobTypeList;
    const resumeSource = ResumeSourceList;
    const lineOfBusiness = LineOfBusinessList;

    const [requestIDError, setRequestIDError] = useState<any>();
    const [jobDivaIDError, setJobDivaIDError] = useState<any>();
    const [jobTitleError, setJobTitleError] = useState<any>();
    const [workingFromError, setWorkingFromError] = useState<any>();
    const [workTypeError, setWorkTypeError] = useState<any>();
    const [jobTypeError, setJobTypeError] = useState<any>();
    const [resumeSourceError, setResumeSourceError] = useState<any>();
    const [lineOfBusinessError, setLineOfBusinessError] = useState<any>();
    const [skillSetError, setSkillSetError] = useState<any>();
    const [jobDescriptiontError, setJobDescriptionError] = useState<any>();

    const onValueChange = (key: any, value: any) => {
        dispatch(setJobInputBoxValue(key, value));
    };

    const [requestIDValid, setRequestIDValid] = useState<boolean>();
    const [jobDivaIDValid, setJobDivaIDValid] = useState<any>();
    const [jobTitleValid, setJobTitleValid] = useState<any>();
    const [jobTypeValid, setJobTypeValid] = useState<any>();
    const [lineOfBusinessValid, setLineOfBusinessValid] = useState<any>();
    const [jobDescriptiontValid, setJobDescriptionValid] = useState<any>();

    function onSubmitClick() {
        setRequestIDValid(isTextValid(currentJobData?.requestID));
        setJobDivaIDValid(isTextValid(currentJobData?.jobDivaID));
        setJobTitleValid(isTextValid(currentJobData?.jobTitle));
        setJobTypeValid(isTextValid(currentJobData?.jobType.value));
        setLineOfBusinessValid(isTextValid(currentJobData?.lineOfBusiness.value));
        setJobDescriptionValid(isTextValid(currentJobData?.jobDescription));

        if (requestIDValid && jobDivaIDValid && jobTitleValid
            && jobTypeValid
            && lineOfBusinessValid
            && jobDescriptiontValid) {
            dispatch(saveJobData(
                currentJobData?.requestID,
                currentJobData?.jobDivaID,
                currentJobData?.jobTitle,
                currentJobData?.jobType.value,
                currentJobData?.lineOfBusiness.value,
                currentJobData?.jobDescription,
            ));

        }
        else {
            if (!requestIDValid) {
                setRequestIDError("Request id is Invalid")
            }
            if (!jobDivaIDValid) {
                setJobDivaIDError("Job diva id is Invalid")
            }
            if (!jobTitleValid) {
                setJobTitleError("Job title is Invalid")
            }
            if (!jobTypeValid) {
                setJobTypeError("Job type is Invalid")
            }
            if (!lineOfBusinessValid) {
                setLineOfBusinessError("Line of business is Invalid");
            }
            if (!jobDescriptiontValid) {
                setJobDescriptionError("Job description is Invalid");
            }
        }
    }

    return (
        <>
            <h2>Job details</h2>
            {/* <Grid container spacing={4}> */}
            {/* <Grid xs={6} md={3}>
                <span>Request ID</span>
                <TextField
                    value={currentJobData?.requestID}
                    placeholder={""}
                    handleChange={(event) => {
                        onValueChange("requestID", event.target.value.replace(/[^0-9]/gi, ""));
                    }}
                    className="" />
                {!requestIDValid ? (
                    <p className="" style={{ fontSize: "12px", color: "red" }}>{requestIDError}</p>
                ) : null}
            </Grid>
            <Grid xs={6} md={3}>
                <span>Job diva ID</span>
                <TextField
                    value={currentJobData?.jobDivaID}
                    placeholder={""}
                    handleChange={(event) => {
                        onValueChange("jobDivaID", event.target.value.replace(/[^0-9]/gi, ""));
                    }}
                    className="" />
                {!jobDivaIDValid ? (
                    <p className="" style={{ fontSize: "12px", color: "red" }}>{jobDivaIDError}</p>
                ) : null}
            </Grid>
            <Grid xs={6} md={6}>
                <span>Job title/Position name</span>
                <TextField
                    value={currentJobData?.jobTitle}
                    placeholder={""}
                    handleChange={(event) => {
                        onValueChange("jobTitle", event.target.value.replace(/[0-9]/gi, ""));
                    }}
                    className="" />
                {!jobTitleValid ? (
                    <p className="" style={{ fontSize: "12px", color: "red" }}>{jobTitleError}</p>
                ) : null}
            </Grid>
            <Grid xs={6} md={3}>
                <span>Job type</span>
                <Select
                    options={jobType}
                    value={currentJobData?.jobType}
                    getOptionLabel={(option) => option.label}
                    getOptionValue={(option) => option.value}
                    onChange={(e: any) => {
                        onValueChange("jobType", e);
                    }}
                // showLabel={false}
                />
                {!jobTypeValid ? (
                    <p className="" style={{ fontSize: "12px", color: "red" }}>{jobTypeError}</p>
                ) : null}
            </Grid>
            <Grid xs={6} md={3}>
                <span>Line of Business</span>
                <Select
                    options={lineOfBusiness}
                    value={currentJobData?.lineOfBusiness}
                    getOptionLabel={(option) => option.label}
                    getOptionValue={(option) => option.value}
                    onChange={(e: any) => {
                        onValueChange("lineOfBusiness", e);
                    }}
                    isSearchable={true}
                />
                {!lineOfBusinessValid ? (
                    <p className="" style={{ fontSize: "12px", color: "red" }}>{lineOfBusinessError}</p>
                ) : null}
            </Grid>
            <Grid xs={12} md={12}>
                <span>Job Description</span>
                <TextArea
                    value={currentJobData?.jobDescription}
                    placeholder={""}
                    handleChange={(event) => {
                        onValueChange("jobDescription", event?.target?.value);
                    }}
                    className="jobDescription" />
                {!jobDescriptiontValid ? (
                    <p className="" style={{ fontSize: "12px", color: "red" }}>{jobDescriptiontError}</p>
                ) : null}
            </Grid> */}
            <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                <tbody>
                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                        <td className='px-6 py-4'>
                            <span>Request ID</span>
                        </td>
                        <td className='px-6 py-4'>
                            {!requestIDValid ? (
                                <p className="" style={{ fontSize: "12px", color: "red" }}>{requestIDError}</p>
                            ) : null}
                            <TextField
                                value={currentJobData?.requestID}
                                placeholder={""}
                                handleChange={(event) => {
                                    onValueChange("requestID", event.target.value.replace(/[^0-9]/gi, ""));
                                }}
                                className="" />

                        </td>
                    </tr>
                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                        <td className='px-6 py-4'>
                            Job diva ID
                        </td>
                        <td className='px-6 py-4'>
                            {!jobDivaIDValid ? (
                                <p className="" style={{ fontSize: "12px", color: "red" }}>{jobDivaIDError}</p>
                            ) : null}
                            <TextField
                                value={currentJobData?.jobDivaID}
                                placeholder={""}
                                handleChange={(event) => {
                                    onValueChange("jobDivaID", event.target.value.replace(/[^0-9]/gi, ""));
                                }}
                                className="" />

                        </td>
                    </tr>
                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                        <td className='px-6 py-4'>
                            Job title/Position name
                        </td>
                        <td className='px-6 py-4'>
                            {!jobTitleValid ? (
                                <p className="" style={{ fontSize: "12px", color: "red" }}>{jobTitleError}</p>
                            ) : null}
                            <TextField
                                value={currentJobData?.jobTitle}
                                placeholder={""}
                                handleChange={(event) => {
                                    onValueChange("jobTitle", event.target.value.replace(/[0-9]/gi, ""));
                                }}
                                className="" />

                        </td>
                    </tr>
                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                        <td className='px-6 py-4'>
                            Job type
                        </td>
                        <td className='px-6 py-4'>
                            {!jobTypeValid ? (
                                <p className="" style={{ fontSize: "12px", color: "red" }}>{jobTypeError}</p>
                            ) : null}
                            <Select
                                options={jobType}
                                value={currentJobData?.jobType}
                                getOptionLabel={(option) => option.label}
                                getOptionValue={(option) => option.value}
                                onChange={(e: any) => {
                                    onValueChange("jobType", e);
                                }}
                            // showLabel={false}
                            />

                        </td>
                    </tr>
                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                        <td className='px-6 py-4'>
                            Line of business
                        </td>
                        <td className='px-6 py-4'>
                            {!lineOfBusinessValid ? (
                                <p className="" style={{ fontSize: "12px", color: "red" }}>{lineOfBusinessError}</p>
                            ) : null}
                            <Select
                                options={lineOfBusiness}
                                value={currentJobData?.lineOfBusiness}
                                getOptionLabel={(option) => option.label}
                                getOptionValue={(option) => option.value}
                                onChange={(e: any) => {
                                    onValueChange("lineOfBusiness", e);
                                }}
                                isSearchable={true}
                            />

                        </td>
                    </tr>
                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                        <td className='px-6 py-4'>
                            Job Description
                        </td>
                        <td className='px-6 py-4'>
                            {!jobDescriptiontValid ? (
                                <p className="" style={{ fontSize: "12px", color: "red" }}>{jobDescriptiontError}</p>
                            ) : null}
                            <TextArea
                                value={currentJobData?.jobDescription}
                                placeholder={""}
                                handleChange={(event) => {
                                    onValueChange("jobDescription", event?.target?.value);
                                }}
                                className="jobDescription" />

                        </td>
                    </tr>
                </tbody>
            </table>

            <Grid xs={12} md={12}>
                <div className="rate-revision-btn-div">
                    <Button
                        className="submit-btn"
                        value="Save & Submit"
                        handleClick={() => onSubmitClick()}
                    />
                </div>
            </Grid>
            {/* </Grid> */}
        </>
    )
}

export default AddJobDetails;