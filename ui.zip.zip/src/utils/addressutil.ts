export const EMPTY_ADDRESS_DATA = {
    line1: "",
    line2: "",
    city: "",
    state: "",
    zipCode: "",
    country: ""
}