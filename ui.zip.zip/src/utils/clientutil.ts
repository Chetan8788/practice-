export const EMPTY_CLIENT_DATA = {
    id: "",
    clientName: "",
    contractType: "",
    endClientName: "",
    mspName: "",
    email: "",
    contactNumber: "",
    faxNumber: "",
    addressId: "",
    line1: "",
    line2: "",
    city: "",
    state: "",
    zipCode: "",
    country: ""
}