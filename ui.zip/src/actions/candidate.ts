import axios from "axios";
import { AppDispatch, RootState } from "../redux/store";
import {
  ALL_CANDIDATES_DATA,
  ALL_CANDIDATES_DATA_ERROR,
  CANDIDATE_DATA,
  EDIT_RATEREVISION_DATA,
  EDIT_RATEREVISION_DATA_ERROR,
  IMPORTANT_CANDIDATE_DATA,
  IMPORTANT_CANDIDATE_DATA_ERROR,
  LOCAL_CANDIDATE_DATA,
} from "./type";
import { EMPTY_CANDIDATE_DATA } from "../utils/candidateutil";

export const candidateData = () => async (dispatch: any) => {
  dispatch({ type: CANDIDATE_DATA, payload: EMPTY_CANDIDATE_DATA });
};

export const setCandidateInputBoxValue =
  (key: any, value: any) => async (dispatch: any) => {
    dispatch({ type: LOCAL_CANDIDATE_DATA, payload: { key, value } });
  };

export const allCandidateData = () => async (dispatch: any) => {
  try {
    const result = await axios.get(
      "http://localhost:3001/candidate/get-all-candidate"
    );
    dispatch({
      type: ALL_CANDIDATES_DATA,
      payload: result.data,
    });
  } catch (err) {
    dispatch({
      type: ALL_CANDIDATES_DATA_ERROR,
      payload: (err as any).response?.data?.message,
    });
  }
};

export const getImportantCandidateData =
  (candidateId: any) => async (dispatch: any) => {
    try {
      const result = await axios.get(
        `http://localhost:3001/candidate/importantData/${candidateId}`
      );
      dispatch({
        type: IMPORTANT_CANDIDATE_DATA,
        payload: result.data,
      });
    } catch (err) {
      dispatch({
        type: IMPORTANT_CANDIDATE_DATA_ERROR,
        payload: (err as any).response?.data?.message,
      });
    }
  };


