import axios from "axios";
import { AppDispatch, RootState } from "../redux/store";
import { REFERRAL_DATA, LOCAL_REFERRAL_DATA } from "./type";
import { EMPTY_REFERRAL_DATA } from "../utils/referral";

export const referralData = () => async (dispatch: any) => {
    dispatch({ type: REFERRAL_DATA, payload: EMPTY_REFERRAL_DATA });
};

export const setReferralInputBoxValue = (key: any, value: any) => async (dispatch: any) => {
    dispatch({ type: LOCAL_REFERRAL_DATA, payload: { key, value } });
};