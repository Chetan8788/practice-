
//Ajay Bagul - [20-07-23] - Model common component made for reusability

import React from "react";
import "../../styles/modal.css";
import CloseIcon from "@mui/icons-material/Close";
//Props interface. Defines all the required props by the component
interface Props {
  modalStyle?:  React.CSSProperties; //Style object for modal
  modalClass?: string; //Class props for the main modal container
  showModal: boolean; //toggle modal props(mandatory)
  isFlexible?: boolean; // if true then makes the modal full device size in smaller devices else small with backdrop
  showHeader?: boolean; // if true then adds header at the top of the modal
  headerTitle?: string; // shows the title of the modal and only when showHeader is true
  showBackButton?: boolean; // shows back button on the header if true else not
  showBBPSLogo?: boolean; // shows BBPS logo on the header if true else not
  handleBackClick?: any; // handle the action when back button is clicked
  showModalHeader?: boolean;
  modalHeader?: string;
  topRightCloseButtonID?: string;
  children: React.ReactNode;
}

//Common Modal Component
export const Modal: React.FC<Props> = ({
  modalStyle,
  modalClass,
  children,
  showModal,
  isFlexible,
  showHeader,
  handleBackClick,
  modalHeader,
  showModalHeader,
  topRightCloseButtonID,
}) => {
  return (
    // Modal container parent
    <div
      id="modal"
      className="modal-background"
      // based on props toggle the display of the modal
      style={showModal ? {} : { display: "none" }}
    >
      {/* <div
        className="background-modal"
        id="click-blur"
        onClick={handleBackClick}
      ></div> */}
      <div
        id="modal-children"
        // based on props for style and class assign style and class to the container
        // adds flexible class when isFlexible is true which takes full screen on mobile and viewed as normal on desktop
        className={`modal-layout ${modalClass ? modalClass : ""} ${
          isFlexible ? "flexible" : ""
        } ${showHeader ? "modal-header" : ""}`}
        style={modalStyle ? modalStyle : {}}
      >
        {showModalHeader && (
          <div className="modal-header">
            <div className="header">{modalHeader}</div>
            <div
              id={topRightCloseButtonID ? topRightCloseButtonID : "x-button"}
              className="x-button"
              onClick={handleBackClick}
            >
              <CloseIcon />
            </div>
          </div>
        )}

        <div className="modal-child-container" id="modal-child-container">
          {/* Mapping the children being passed as props */}
          {children}
        </div>
      </div>
    </div>
  );
};
