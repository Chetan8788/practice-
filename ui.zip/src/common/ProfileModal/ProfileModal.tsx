// import { Popover } from "@headlessui/react";
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import { useState } from "react";
import PopoverComponent from '../Popover';
import { Button } from '@material-tailwind/react';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';
const profIcon = <AccountCircleIcon sx={{ fontSize: 30 }} />
interface Props {
    userInfo: any;
}
const ProfileModal: React.FC<Props> = ({
    userInfo
}) => {
    const [show, setShow] = useState<boolean>(false);

    const navigate = useNavigate();

    let user: any = localStorage.getItem("user");
    user = JSON.parse(user);
    console.log('user: nav ', user);

    return (
        <PopoverComponent button={profIcon} className='ml-[-24px] border border-solid'>
            <div className='p-2'>
                <div className='flex flex-col justify-center space-y-4'>
                    <div className="flex flex-col justify-center items-center">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRsmfBDCVvtjGb-4V1QGHn-ikuY1-D5t2Ub1cT6UT1YLg&s" className='w-20 h-20 rounded-full border-2' alt="ProfilePicture" />
                    </div>
                    <h1>{user?.firstName + " " + user?.lastName}</h1>
                    <h1>{user?.email}</h1>
                    <p>{user?.role}</p>
                    <div className='w-full flex justify-center items-center gap-2'>

                        <Button variant='filled' className='h-8 py-2 px-3' onClick={() => {
                            Swal.fire({
                                title: 'Do you really want to log out ?',
                                showDenyButton: true,
                                // showCancelButton: true,
                                confirmButtonText: 'Yes',
                                denyButtonText: 'No',
                                customClass: {
                                    actions: 'my-actions',
                                    cancelButton: 'order-1 right-gap',
                                    confirmButton: 'order-2',
                                    denyButton: 'order-3',
                                }
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    localStorage.removeItem("token");
                                    localStorage.removeItem("user");
                                    navigate("/sign-in");
                                } else if (result.isDenied) {
                                    // Swal.fire('Changes are not saved', '', 'info')
                                }
                            })
                        }}>Log Out</Button>
                    </div>
                </div>
            </div>
        </PopoverComponent>
    );
};
export default ProfileModal;