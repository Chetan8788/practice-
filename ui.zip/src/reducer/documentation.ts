import { cloneDeep } from "lodash";
import { DOCUMENTATION_DATA, DOCUMENTATION_DATA_ERROR, LOCAL_DOCUMENTATION_DATA, SINGLE_DOCUMENTATION, SINGLE_DOCUMENTATION_ERROR } from "../actions/type";

interface Actions {
  payload: any;
  type: string;
}

interface Interface {
  documentationData: any;
  documentationDataError: any;
  singleDocumentationData: any;
  singleDocumentationDataError: any;
}

export const initialState: State = {
  documentationData: undefined,
  documentationDataError: {},
  singleDocumentationData: undefined,
  singleDocumentationDataError: {},
};
export type State = Interface;
export const documentationReducer = (
  state: State = initialState,
  action: Actions
) => {
  switch (action.type) {
    case DOCUMENTATION_DATA:
      return {
        ...state,
        documentationData: action.payload,
        documentationDataError: "",
      }
    case DOCUMENTATION_DATA_ERROR:
      return {
        ...state,
        documentationData: "",
        documentationDataError: action.payload,
      };
    case SINGLE_DOCUMENTATION:
      return {
        ...state,
        singleDocumentationData: action.payload,
        singleDocumentationDataError: "",
      };
    case SINGLE_DOCUMENTATION_ERROR:
      return {
        ...state,
        singleDocumentationData: "",
        singleDocumentationDataError: action.payload,
      };
    case LOCAL_DOCUMENTATION_DATA: {
      const tempCurrentValue = cloneDeep(state.documentationData);
      tempCurrentValue[action.payload.key] = action.payload.value;
      return {
        ...state,
        documentationData: tempCurrentValue,
      };
    }
    default:
      return state;
  }
}