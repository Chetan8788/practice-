import {
    REFERRAL_DATA,
    REFERRAL_DATA_ERROR,
    LOCAL_REFERRAL_DATA,
    ALL_REFERRAL_DATA,
    ALL_REFERRAL_DATA_ERROR
} from "../actions/type";
import { cloneDeep, remove, findIndex } from "lodash";

//State type for defining the state of the reducer
interface Actions {
    payload: any;
    type: string;
}

//Referral Interface to define the State type for the state of the reducer
interface ReferralInterface {
    referralData: any;
    referralDataError: any;
    allReferralData: any;
    allReferralDataError: any;
}

//State type for defining the state of the reducer
export type State = ReferralInterface;

//Initial state of the reducer of type State
export const initialState: State = {
    referralData: undefined,
    referralDataError: {},
    allReferralData: [],
    allReferralDataError: null,
};

export const ReferralReducer = (state: State = initialState, action: Actions) => {
    switch (action.type) {
        case REFERRAL_DATA:
            return {
                ...state,
                referralData: action.payload,
                referralDataError: "",
            };
        case LOCAL_REFERRAL_DATA: {
            const tempCurrentValue = cloneDeep(state.referralData);
            tempCurrentValue[action.payload.key] = action.payload.value;

            return {
                ...state,
                referralData: tempCurrentValue,
            };
        }
        case ALL_REFERRAL_DATA:
            return {
                ...state,
                allVendorData: action.payload,
                allVendorDataError: "",
            };
        case ALL_REFERRAL_DATA_ERROR:
            return {
                ...state,
                allVendorData: "",
                allVendorDataError: action.payload,
            };
        //return state as it is if action is not of any of the aforementioned types
        default:
            return state;
    }
};