import {
    VENDOR_DATA,
    VENDOR_DATA_ERROR,
    LOCAL_VENDOR_DATA,
    ALL_VENDOR_DATA,
    ALL_VENDOR_DATA_ERROR,
    SAVED_VENDOR_DATA,
    SAVED_VENDOR_DATA_ERROR
} from "../actions/type";
import { cloneDeep, remove, findIndex } from "lodash";

//State type for defining the state of the reducer
interface Actions {
    payload: any;
    type: string;
}

//Vendor Interface to define the State type for the state of the reducer
interface VendorInterface {
    vendorData: any;
    vendorDataError: any;
    allVendorData: any;
    allVendorDataError: any;
    savedVendorData: any;
    savedVendorDataError: any;
}

//State type for defining the state of the reducer
export type State = VendorInterface;

//Initial state of the reducer of type State
export const initialState: State = {
    vendorData: undefined,
    vendorDataError: {},
    allVendorData: [],
    allVendorDataError: null,
    savedVendorData: {},
    savedVendorDataError: {}
};

export const VendorReducer = (state: State = initialState, action: Actions) => {
    switch (action.type) {
        case VENDOR_DATA:
            return {
                ...state,
                vendorData: action.payload,
                vendorDataError: "",
            };
        case LOCAL_VENDOR_DATA: {
            const tempCurrentValue = cloneDeep(state.vendorData);
            tempCurrentValue[action.payload.key] = action.payload.value;

            return {
                ...state,
                vendorData: tempCurrentValue,
            };
        }
        case ALL_VENDOR_DATA:
            return {
                ...state,
                allVendorData: action.payload,
                allVendorDataError: "",
            };
        case ALL_VENDOR_DATA_ERROR:
            return {
                ...state,
                allVendorData: "",
                allVendorDataError: action.payload,
            };
        case SAVED_VENDOR_DATA:
            return {
                ...state,
                savedVendorData: action.payload,
                savedVendorDataError: "",
            };
        case SAVED_VENDOR_DATA_ERROR:
            return {
                ...state,
                savedVendorData: "",
                savedVendorDataError: action.payload,
            };
        //return state as it is if action is not of any of the aforementioned types
        default:
            return state;
    }
};