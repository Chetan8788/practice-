import React from "react";
import { Route, Routes } from "react-router-dom"
import { styled } from '@mui/material/styles';
import { Box, CssBaseline } from "@mui/material";
import HomepageScreen from "../screens/Homepage";
import { ProtectedRoute } from "./ProtectedRoute";
import { SignIn } from "../screens/Login/signin";
import NavBarScreen from "../screens/Navbar";
import SideBarScreen from "../screens/Sidebar";
import AddCandidateScreen from "../screens/Candidate";
import ShowClientDetails from "../screens/Client/ShowClientDetails";
import AddClientDetails from "../screens/Client/AddClient";
import ShowJobDetails from "../screens/Job/ShowJobDetails";
import AddJobDetails from "../screens/Job/AddJob";
import ShowVendorDetails from "../screens/Vendor/ShowVendorDetails";
import AddVendor from "../screens/Vendor/AddVendor";
import MiscellaneousScreen from "../screens/Miscellaneous";
import ShowWorkAuthorization from "../screens/WorkAuthorization";
import AddWorkAuthorization from "../screens/WorkAuthorization/AddWorkAuthorization";
import WorkAuthorization from "../screens/WorkAuthorization";
import ContractType from "../screens/ContractType";
import AddContractType from "../screens/ContractType/AddContractType";
import { AllData } from "../screens/Homepage/AllData";

function Routers() {
    const logged = true;
    const [open, setOpen] = React.useState(false);

    const DrawerHeader = styled('div')(({ theme }) => ({
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: theme.spacing(0, 1),
        // necessary for content to be below app bar
        ...theme.mixins.toolbar,
    }));

    if (logged) {
        return (
            <Box sx={{ display: 'flex' }}>
                <CssBaseline />
                <NavBarScreen open={open} setOpen={setOpen} />
                <SideBarScreen open={open} setOpen={setOpen} />
                <Box component="main" sx={{ flexGrow: 1, p: 3, height: "100vh" }}>
                    <DrawerHeader />
                    <Routes>
                        <Route path="/" element={<HomepageScreen />} />
                        <Route path="/all-data" element={<AllData />} />
                        <Route path="/add-candidate" element={<AddCandidateScreen />} />
                        <Route path="/show-clients" element={<ShowClientDetails />} />
                        <Route path="/show-jobs" element={<ShowJobDetails />} />
                        <Route path="/show-vendors" element={<ShowVendorDetails />} />
                        <Route path="/add-vendor" element={<AddVendor />} />
                        <Route path="/add-client" element={<AddClientDetails />} />
                        <Route path="/add-job" element={<AddJobDetails />} />
                        <Route path="/show-work-authorization" element={<WorkAuthorization />} />
                        <Route path="/add-work-authorization" element={<AddWorkAuthorization />} />
                        <Route path="/contract-type" element={<ContractType />} />
                        <Route path="/add-contract-type" element={<AddContractType />} />
                        <Route path="/miscellaneous" element={<MiscellaneousScreen />} />
                        <Route path="/sign-in" element={<SignIn />} />
                    </Routes>
                </Box>
            </Box>
        );
    } else {
        return (
            <Routes>
                <Route path="/" element={<SignIn />} />
            </Routes>
        )
    }

    return (

        <Routes>
            <Route path="/" element={<HomepageScreen />} />
            <Route path="/sign-in" element={<SignIn />} />


        </Routes>
    );
}

export default Routers;