//Ajay Bagul - [25-07-23] - Created Background check page
import React, { useEffect, useState } from "react";
import { TextField } from "../../common/TextField/TextField";
import "./backgroundCheck.css";
import { Button } from "../../common/Button/Button";
import { TextArea } from "../../common/TextArea/TextArea";
import {
  BGCAdjuStatusOptions,
  BGCAffidavitOptions,
  BGCInvoiceMonthOptions,
  BGCPackageOptions,
  BGCReportStatusOptions,
  BGCStatusOptions,
  PrimBGCInitiatedThruOptions,
  finalBGCReportOptions,
} from "../../constants/backgroundconstants";
import { setBackgroundCheckInputBoxValue, setSecondaryButton, setTertiaryButton } from "../../actions/backgroundCheck";
import { useAppDispatch, useAppSelector } from "../../hooks/app";
import { RootState } from "../../redux/store";
import Select from "react-select";

export default function BackgroundCheck() {
  const dispatch = useAppDispatch();
  const currentBGCData = useAppSelector((state: RootState) => state?.backgroundCheck?.backgroundCheckData);

  const [showSecondary, setShowSecondary] = useState<boolean>(false);
  const showSecondaryRedux = useAppSelector((state: RootState) => state?.backgroundCheck?.secondaryButton);
  const [showTertiary, setShowTertiary] = useState<boolean>(false);
  const showTertiaryRedux = useAppSelector((state: RootState) => state?.backgroundCheck?.tertiaryButton);

  const onValueChange = (key: any, value: any) => {
    if (key && value) {
      dispatch(setBackgroundCheckInputBoxValue(key, value));
    }
  };

  useEffect(() => {
    setShowSecondary(showSecondaryRedux.secondaryButtonFlag);
    onValueChange("secondary", showSecondary);
    setShowTertiary(showTertiaryRedux.tertiaryButtonFlag);
    onValueChange("tertiary", showTertiary);
  }, [showSecondary, showTertiary])

  return (
    <>
      Background Check details
      <div className="" style={{ margin: "auto", width: "100%" }}>
        <div className="flex gap-5 " style={{ margin: "auto", width: "100%" }}>
          <div className="relative w-[100%] mt-10 ">
            <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
              <thead className='text-xs text-gray-700 uppercase bg-gray-200 dark:bg-gray-700 dark:text-gray-400'>
                <tr>
                  <th scope="col" className="px-6 py-4">
                    <span>initial details</span>
                  </th>
                  <th>
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>case ID-1</span>
                  </td>
                  <td className='px-6 py-0'>

                    <TextField
                      // label="adju supporting document"
                      value={currentBGCData?.caseID1}
                      placeholder={""}
                      handleChange={(e: any) =>
                        onValueChange("caseID1", e.target.value)
                      }
                      styles={{ border: "1px solid hsl(0, 0%, 80%)" }}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>BGC initiated On</span>
                  </td>
                  <td className='px-6 py-0'>

                    <TextField
                      // label="BGC Initiated On"
                      value={currentBGCData?.BGCInitiatedOn}
                      type="date"
                      // placeholder={""}
                      handleChange={(e) =>
                        onValueChange("BGCInitiatedOn", e.target.value)
                      }
                      styles={{ border: "1px solid hsl(0, 0%, 80%)" }}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>Primary BGC initiated thru</span>
                  </td>
                  <td className='px-6 py-0'>

                    <Select
                      options={PrimBGCInitiatedThruOptions}
                      value={currentBGCData?.primaryBGCInitiatedThru}
                      getOptionLabel={(option) => option.label}
                      getOptionValue={(option) => option.value}
                      onChange={(e: any) => {
                        onValueChange("primaryBGCInitiatedThru", e);
                      }}
                      isSearchable={true}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>BGC package 1</span>
                  </td>
                  <td className='px-6 py-0'>

                    <Select
                      options={BGCPackageOptions}
                      value={currentBGCData?.BGCPackage1}
                      getOptionLabel={(option) => option.label}
                      getOptionValue={(option) => option.value}
                      onChange={(e: any) => {
                        onValueChange("BGCPackage1", e);
                      }}
                      isSearchable={true}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>BGC package 2</span>
                  </td>
                  <td className='px-6 py-0'>

                    <Select
                      options={BGCPackageOptions}
                      value={currentBGCData?.BGCPackage2}
                      getOptionLabel={(option) => option.label}
                      getOptionValue={(option) => option.value}
                      onChange={(e: any) => {
                        onValueChange("BGCPackage2", e);
                      }}
                      isSearchable={true}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>BGC invoice month</span>
                  </td>
                  <td className='px-6 py-0'>

                    <Select
                      options={BGCInvoiceMonthOptions}
                      value={currentBGCData?.BGCInvoiceMonth}
                      getOptionLabel={(option) => option.label}
                      getOptionValue={(option) => option.value}
                      onChange={(e: any) => {
                        onValueChange("BGCInvoiceMonth", e);
                      }}
                      isSearchable={true}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>BGC charges primary</span>
                  </td>
                  <td className='px-6 py-0'>

                    <TextField
                      // label={"BGC charges primary"}
                      value={currentBGCData?.BGCChargesPrimary}
                      handleChange={(e: any) =>
                        onValueChange("BGCChargesPrimary", e.target.value)
                      }
                      styles={{ border: "1px solid hsl(0, 0%, 80%)" }}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>BGC Status Options</span>
                  </td>
                  <td className='px-6 py-0'>
                    <Select
                      options={BGCStatusOptions}
                      value={currentBGCData?.BGCStatus}
                      getOptionLabel={(option) => option.label}
                      getOptionValue={(option) => option.value}
                      onChange={(e: any) => {
                        onValueChange("BGCStatus", e);
                      }}
                      isSearchable={true}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>BGC completed on</span>
                  </td>
                  <td className='px-6 py-0'>
                    <TextField
                      value={currentBGCData?.BGCCompletedOn}
                      handleChange={(e) =>
                        onValueChange("BGCCompletedOn", e.target.value)
                      }
                      placeholder={""}
                    />
                  </td>
                </tr>

              </tbody>
              {!showSecondary ? (
                <div className="border border-solid mt-5 w-[20%] h-[10px] ml-[200%] ">
                  <Button
                    className="text-white"
                    value="+"
                    handleClick={() => {
                      dispatch(setSecondaryButton(true));
                      setShowSecondary(true)
                    }}
                  />
                </div>
              ) : null}
            </table>
          </div>

          <div className="relative w-[100%] mt-10 ">
            <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
              <thead className='text-xs text-gray-700 uppercase bg-gray-200 dark:bg-gray-700 dark:text-gray-400'>
                <tr>
                  <th scope="col" className="px-6 py-4">
                    <span>other details</span>
                  </th>
                  <th>
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>BGC completed on</span>
                  </td>
                  <td className='px-6 py-0'>
                    <TextField
                      value={currentBGCData?.BGCCompletedOn}
                      handleChange={(e) =>
                        onValueChange("BGCCompletedOn", e.target.value)
                      }
                      styles={{ border: "1px solid hsl(0, 0%, 80%)" }}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>BGC affidavit status</span>
                  </td>
                  <td className='px-6 py-0'>
                    <Select
                      options={BGCAffidavitOptions}
                      value={currentBGCData?.BGCAffidavitStatus}
                      getOptionLabel={(option) => option.label}
                      getOptionValue={(option) => option.value}
                      onChange={(e: any) => {
                        onValueChange("BGCAffidavitStatus", e);
                      }}
                      isSearchable={true}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>BGC affidavit on</span>
                  </td>
                  <td className='px-6 py-0'>
                    <TextField
                      value={currentBGCData?.BGCAffidavitOn}
                      handleChange={(e) =>
                        onValueChange("BGCAffidavitOn", e.target.value)
                      }
                      styles={{ border: "1px solid hsl(0, 0%, 80%)" }}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>BGC report status</span>
                  </td>
                  <td className='px-6 py-0'>
                    <Select
                      options={BGCReportStatusOptions}
                      value={currentBGCData?.BGCReportStatus}
                      getOptionLabel={(option) => option.label}
                      getOptionValue={(option) => option.value}
                      onChange={(e: any) => {
                        onValueChange("BGCReportStatus", e);
                      }}
                      isSearchable={true}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>BGC adjudication Status</span>
                  </td>
                  <td className='px-6 py-0'>
                    <Select
                      options={BGCAdjuStatusOptions}
                      value={currentBGCData?.BGCAdjuStatus}
                      getOptionLabel={(option) => option.label}
                      getOptionValue={(option) => option.value}
                      onChange={(e: any) => {
                        onValueChange("BGCAdjuStatus", e);
                      }}
                      isSearchable={true}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>Adjudication supporting document</span>
                  </td>
                  <td className='px-6 py-0'>
                    <TextField
                      value={currentBGCData?.adjuSupportingDocs}
                      handleChange={(e) =>
                        onValueChange("adjuSupportingDocs", e.target.value)
                      }
                      styles={{ border: "1px solid hsl(0, 0%, 80%)" }}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>Date of adjudication</span>
                  </td>
                  <td className='px-6 py-0'>
                    <TextField
                      value={currentBGCData?.dateOfAdjudication}
                      handleChange={(e) =>
                        onValueChange("dateOfAdjudication", e.target.value)
                      }
                      styles={{ border: "1px solid hsl(0, 0%, 80%)" }}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>Final BGC report status</span>
                  </td>
                  <td className='px-6 py-0'>
                    <Select
                      options={finalBGCReportOptions}
                      value={currentBGCData?.finalBGCReport}
                      getOptionLabel={(option) => option.label}
                      getOptionValue={(option) => option.value}
                      onChange={(e: any) => {
                        onValueChange("finalBGCReport", e);
                      }}
                      isSearchable={true}
                    />
                  </td>
                </tr>
                <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                  <td className='px-6 py-4 font-semibold'>
                    <span>BGC remark</span>
                  </td>
                  <td className='px-6 py-0'>
                    <TextArea
                      value={currentBGCData?.BGCRemark}
                      placeholder={""}
                      handleChange={(e) => {
                        onValueChange("BGCRemark", e.target.value)
                      }}
                      styles={{ border: "1px solid hsl(0, 0%, 80%)" }}
                    />
                  </td>
                </tr>
              </tbody>
              {/* {!showSecondary ? (
                <div className="add-cancel-1">
                  <Button
                    className="btn-size"
                    value="+"
                    handleClick={() => {
                      dispatch(setSecondaryButton(true));
                      setShowSecondary(true)
                    }}
                  />
                </div>
              ) : null} */}
            </table>
          </div>
        </div>
        {showSecondary ? (
          <div className="flex gap-5 mt-20" style={{ margin: "auto", width: "100%" }}>
            <div className="relative w-[100%] mt-10 ">
              <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                <tbody>
                  <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                    <td className='px-6 py-4 font-semibold'>
                      <span>case ID-2</span>
                    </td>
                    <td className='px-6 py-0'>
                      <TextField
                        // label="case ID-2"
                        value={currentBGCData?.caseID2}
                        placeholder={""}
                        handleChange={(e) => onValueChange("caseID2", e.target.value)}
                        styles={{ border: "1px solid hsl(0, 0%, 80%)" }}
                      />
                    </td>
                  </tr>
                  <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                    <td className='px-6 py-4 font-semibold'>
                      <span>Secondary BGC initiated on</span>
                    </td>
                    <td className='px-6 py-0'>
                      <TextField
                        // label="Secondary BGC Initiated On"
                        value={currentBGCData?.secondaryBGCInitiatedOn}
                        type="date"
                        placeholder={""}
                        handleChange={(e) =>
                          onValueChange("secondaryBGCInitiatedOn", e.target.value)
                        }
                        styles={{ border: "1px solid hsl(0, 0%, 80%)" }}
                      />
                    </td>
                  </tr>
                  <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                    <td className='px-6 py-4 font-semibold'>
                      <span>Secondary BGC initiated thru</span>
                    </td>
                    <td className='px-6 py-0'>
                      <Select
                        options={PrimBGCInitiatedThruOptions}
                        value={currentBGCData?.secondaryBGCInitiatedThru}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                          onValueChange("secondaryBGCInitiatedThru", e);
                        }}
                        isSearchable={true}
                      />
                    </td>
                  </tr>
                  <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                    <td className='px-6 py-4 font-semibold'>
                      <span>Secondary BGC check-1</span>
                    </td>
                    <td className='px-6 py-0'>
                      <Select
                        options={BGCPackageOptions}
                        value={currentBGCData?.secondaryBGCPackage1}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                          onValueChange("secondaryBGCPackage1", e);
                        }}
                        isSearchable={true}
                      />
                    </td>
                  </tr>
                </tbody>

                {showSecondary && !showTertiary ? (
                  <div className="flex gap-3 mt-5 ml-[180%]">
                    <Button
                      className="text-white"
                      styles={{ width: "50px" }}
                      value="-"
                      handleClick={() => {
                        dispatch(setSecondaryButton(false));
                        setShowSecondary(false)
                      }}
                    />
                    <Button
                      className="text-white"
                      styles={{ width: "50px" }}
                      value="+"
                      handleClick={() => {
                        console.log('showTertiary: ', showTertiary);
                        dispatch(setTertiaryButton(true));
                        setShowTertiary(true)
                        // showTertiary
                      }}
                    />
                  </div>
                ) : null}
              </table>
            </div>
            <div className="relative w-[100%] mt-10 ">
              <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                <tbody>
                  <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                    <td className='px-6 py-4 font-semibold'>
                      <span>Secondary BGC check-2</span>
                    </td>
                    <td className='px-6 py-0'>
                      <Select
                        options={BGCPackageOptions}
                        value={currentBGCData?.secondaryBGCPackage2}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                          onValueChange("secondaryBGCPackage2", e);
                        }}
                        isSearchable={true}
                      />
                    </td>
                  </tr>
                  <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                    <td className='px-6 py-4 font-semibold'>
                      <span>Secondary BGC invoice month</span>
                    </td>
                    <td className='px-6 py-0'>
                      <Select
                        options={BGCInvoiceMonthOptions}
                        value={currentBGCData?.secondaryBGCInvoiceMonth}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                          onValueChange("secondaryBGCInvoiceMonth", e);
                        }}
                        isSearchable={true}
                      />
                    </td>
                  </tr>
                  <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                    <td className='px-6 py-4 font-semibold'>
                      <span>BGC charges secondary</span>
                    </td>
                    <td className='px-6 py-0'>
                      <TextField
                        // label={"BGC charges Secondary"}
                        value={currentBGCData?.secondaryBGCCharges}
                        handleChange={(e) =>
                          onValueChange("secondaryBGCCharges", e.target.value)
                        }
                        styles={{ border: "1px solid hsl(0, 0%, 80%)" }}
                      />
                    </td>
                  </tr>
                </tbody>
                {/* {showSecondary && !showTertiary ? (
                  <div className="add-cancel-2">
                    <Button
                      className="btn-size"
                      value="-"
                      handleClick={() => {
                        dispatch(setSecondaryButton(false));
                        setShowSecondary(false)
                      }}
                    />
                    <Button
                      className="btn-size"
                      value="+"
                      handleClick={() => {
                        dispatch(setTertiaryButton(true));
                        setShowTertiary(true)
                      }}
                    />
                  </div>
                ) : null} */}
              </table>
            </div>
          </div>
        ) : null}
        {showTertiary ? (
          <div className="flex gap-5 mt-20" style={{ margin: "auto", width: "100%" }}>
            <div className="relative w-[100%] mt-10 ">
              <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                <tbody>
                  <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                    <td className='px-6 py-4 font-semibold'>
                      <span>case ID-3</span>
                    </td>
                    <td className='px-6 py-0'>
                      <TextField
                        // label="case ID-2"
                        value={currentBGCData?.caseID3}
                        placeholder={""}
                        handleChange={(e) => onValueChange("caseID3", e.target.value)}
                        styles={{ border: "1px solid hsl(0, 0%, 80%)" }}
                      />
                    </td>
                  </tr>
                  <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                    <td className='px-6 py-4 font-semibold'>
                      <span>Tertiary BGC initiated on</span>
                    </td>
                    <td className='px-6 py-0'>
                      <TextField
                        // label="Secondary BGC Initiated On"
                        value={currentBGCData?.tertiaryBGCInitiatedOn}
                        type="date"
                        placeholder={""}
                        handleChange={(e) =>
                          onValueChange("tertiaryBGCInitiatedOn", e.target.value)
                        }
                        styles={{ border: "1px solid hsl(0, 0%, 80%)" }}
                      />
                    </td>
                  </tr>
                  <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                    <td className='px-6 py-4 font-semibold'>
                      <span>Tertiary BGC initiated thru</span>
                    </td>
                    <td className='px-6 py-0'>
                      <Select
                        options={PrimBGCInitiatedThruOptions}
                        value={currentBGCData?.tertiaryBGCInitiatedThru}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                          onValueChange("tertiaryBGCInitiatedThru", e);
                        }}
                        isSearchable={true}
                      />
                    </td>
                  </tr>
                  <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                    <td className='px-6 py-4 font-semibold'>
                      <span>Tertiary BGC check-1</span>
                    </td>
                    <td className='px-6 py-0'>
                      <Select
                        options={BGCPackageOptions}
                        value={currentBGCData?.tertiaryBGCPackage1}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                          onValueChange("tertiaryBGCPackage1", e);
                        }}
                        isSearchable={true}
                      />
                    </td>
                  </tr>
                </tbody>
          
                {showTertiary ? (
                  <div className="mt-5 w-[15%] h-[20px] ml-[200%]">
                    <Button
                      className="text-white"
                      value="-"
                      handleClick={() => {
                        dispatch(setTertiaryButton(false));
                        setShowTertiary(false)
                      }}
                    />
                  </div>
                ) : null}
              </table>
            </div>
            <div className="relative w-[100%] mt-10 ">
              <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                <tbody>
                  <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                    <td className='px-6 py-4 font-semibold'>
                      <span>Tertiary BGC check-2</span>
                    </td>
                    <td className='px-6 py-0'>
                      <Select
                        options={BGCPackageOptions}
                        value={currentBGCData?.tertiaryBGCPackage2}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                          onValueChange("tertiaryBGCPackage2", e);
                        }}
                        isSearchable={true}
                      />
                    </td>
                  </tr>
                  <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                    <td className='px-6 py-4 font-semibold'>
                      <span>Tertiary BGC invoice month</span>
                    </td>
                    <td className='px-6 py-0'>
                      <Select
                        options={BGCInvoiceMonthOptions}
                        value={currentBGCData?.tertiaryBGCInvoiceMonth}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                          onValueChange("tertiaryBGCInvoiceMonth", e);
                        }}
                        isSearchable={true}
                      />
                    </td>
                  </tr>
                  <tr className='bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700'>
                    <td className='px-6 py-4 font-semibold'>
                      <span>BGC charges Tertiary</span>
                    </td>
                    <td className='px-6 py-0'>
                      <TextField
                        // label={"BGC charges Secondary"}
                        value={currentBGCData?.tertiaryBGCCharges}
                        handleChange={(e) =>
                          onValueChange("tertiaryBGCCharges", e.target.value)
                        }
                        styles={{ border: "1px solid hsl(0, 0%, 80%)" }}
                      />
                    </td>
                  </tr>
                </tbody>
                {/* {showTertiary ? (
                  <div className="add-cancel-2">
                    <Button
                      className="btn-size"
                      value="-"
                      handleClick={() => {
                        dispatch(setTertiaryButton(false));
                        setShowTertiary(false)
                      }}
                    />
                  </div>
                ) : null} */}
              </table>
            </div>
          </div>
        ) : null}
      </div>
    </>
  );
}
