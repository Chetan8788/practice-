import React, { useState } from 'react';
import { useSpring, animated } from '@react-spring/web';
import { TextField } from '@mui/material';
import { TextField as TextField1 } from '../../common/TextField/TextField';
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import Select from "react-select";
import { BGCAdjuStatusOptions, BGCAffidavitOptions, BGCInvoiceMonthOptions, BGCPackageOptions, BGCReportStatusOptions, BGCStatusOptions, PrimBGCInitiatedThruOptions, finalBGCReportOptions } from '../../constants/backgroundconstants';
import { Button, Button as Button1 } from "../../common/Button/Button";
import { TextArea } from '../../common/TextArea/TextArea';
import { editCandidateBackgroundCheckData } from '../../actions/backgroundCheck';
import { RootState } from '../../redux/store';

interface FadeProps {
  children: React.ReactElement;
  in?: boolean;
  onClick?: any;
  onEnter?: (node: HTMLElement, isAppearing: boolean) => void;
  onExited?: (node: HTMLElement, isAppearing: boolean) => void;
  ownerState?: any;
}

const Fade = React.forwardRef<HTMLDivElement, FadeProps>(function Fade(props, ref) {
  const {
    children,
    in: open,
    onClick,
    onEnter,
    onExited,
    ownerState,
    ...other
  } = props;
  const style = useSpring({
    from: { opacity: 0 },
    to: { opacity: open ? 1 : 0 },
    onStart: () => {
      if (open && onEnter) {
        onEnter(null as any, true);
      }
    },
    onRest: () => {
      if (!open && onExited) {
        onExited(null as any, true);
      }
    },
  });

  return (
    <animated.div ref={ref} style={style} {...other}>
      {React.cloneElement(children, { onClick })}
    </animated.div>
  );
});

const style = {
  position: 'absolute' as 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '1px #000',
  boxShadow: 24,
  p: 4,
  borderRadius: "10px",
};

interface Props {
  open: any,
  setOpen: any,
  // data: any,
  showTableCount: any,
  int: any,
  setShowModal: any,
  showModal: any,
}

const ShowBackgroundCheck: React.FC<Props> = ({ open, setOpen,
  // data,
  showTableCount, int, setShowModal, showModal }) => {
  const dispatch = useAppDispatch();
  let data = useAppSelector((state: RootState) => state?.backgroundCheck?.singleBackgroundCheckData);
  const [disable, setDisable] = useState(true);
  const [caseID1, setCaseID1] = useState(data?.caseID1);
  const [BGCInitiatedOn, setBGCInitiatedOn] = useState(data?.BGCInitiatedOn);
  const [primaryBGCInitiatedThru, setPrimaryBGCInitiatedThru] = useState({
    value: data?.primaryBGCInitiatedThru,
    label: data?.primaryBGCInitiatedThru,
  });
  const [BGCPackage1, setBGCPackage1] = useState({
    value: data?.BGCPackage1,
    label: data?.BGCPackage1,
  });
  const [BGCPackage2, setBGCPackage2] = useState({
    value: data?.BGCPackage2,
    label: data?.BGCPackage2,
  });
  const [BGCInvoiceMonth, setBGCInvoiceMonth] = useState({
    value: data?.BGCInvoiceMonth,
    label: data?.BGCInvoiceMonth,
  });
  const [BGCChargesPrimary, setBGCChargesPrimary] = useState(data?.BGCChargesPrimary);
  const [secondary, setSecondary] = useState(data?.secondary);
  const [caseID2, setCaseID2] = useState(data?.caseID2);
  const [secondaryBGCInitiatedOn, setSecondaryBGCInitiatedOn] = useState(data?.secondaryBGCInitiatedOn);
  const [secondaryBGCInitiatedThru, setSecondaryBGCInitiatedThru] = useState({
    value: data?.secondaryBGCInitiatedThru,
    label: data?.secondaryBGCInitiatedThru,
  });
  const [secondaryBGCPackage1, setSecondaryBGCPackage1] = useState({
    value: data?.secondaryBGCPackage1,
    label: data?.secondaryBGCPackage1,
  });
  const [secondaryBGCPackage2, setSecondaryBGCPackage2] = useState({
    value: data?.secondaryBGCPackage2,
    label: data?.secondaryBGCPackage2,
  });
  const [secondaryBGCInvoiceMonth, setSecondaryBGCInvoiceMonth] = useState({
    value: data?.secondaryBGCInvoiceMonth,
    label: data?.secondaryBGCInvoiceMonth,
  });
  const [secondaryBGCCharges, setSecondaryBGCCharges] = useState(data?.secondaryBGCCharges);
  const [tertiary, setTertiary] = useState(data?.tertiary);
  const [caseID3, setCaseID3] = useState(data?.caseID3);
  const [tertiaryBGCInitiatedOn, setTertiaryBGCInitiatedOn] = useState(data?.tertiaryBGCInitiatedOn);
  const [tertiaryBGCInitiatedThru, setTertiaryBGCInitiatedThru] = useState({
    value: data?.tertiaryBGCInitiatedThru,
    label: data?.tertiaryBGCInitiatedThru,
  });
  const [tertiaryBGCPackage1, setTertiaryBGCPackage1] = useState({
    value: data?.tertiaryBGCPackage1,
    label: data?.tertiaryBGCPackage1,
  });
  const [tertiaryBGCPackage2, setTertiaryBGCPackage2] = useState({
    value: data?.tertiaryBGCPackage2,
    label: data?.tertiaryBGCPackage2,
  });
  const [tertiaryBGCInvoiceMonth, setTertiaryBGCInvoiceMonth] = useState({
    value: data?.tertiaryBGCInvoiceMonth,
    label: data?.tertiaryBGCInvoiceMonth,
  });
  const [tertiaryBGCCharges, setTertiaryBGCCharges] = useState(data?.tertiaryBGCCharges);
  const [BGCStatus, setBGCStatus] = useState({
    value: data?.BGCStatus,
    label: data?.BGCStatus,
  });
  const [BGCCompletedOn, setBGCCompletedOn] = useState(data?.BGCCompletedOn);
  const [BGCAffidavitStatus, setBGCAffidavitStatus] = useState({
    value: data?.BGCAffidavitStatus,
    label: data?.BGCAffidavitStatus,
  });
  const [BGCAffidavitOn, setBGCAffidavitOn] = useState(data?.BGCAffidavitOn);
  const [BGCReportStatus, setBGCReportStatus] = useState({
    value: data?.BGCReportStatus,
    label: data?.BGCReportStatus,
  });
  const [BGCAdjuStatus, setBGCAdjuStatus] = useState({
    value: data?.BGCAdjuStatus,
    label: data?.BGCAdjuStatus,
  });
  const [adjuSupportingDocs, setAdjuSupportingDocs] = useState(data?.adjuSupportingDocs);
  const [dateOfAdjudication, setDateOfAdjudication] = useState(data?.dateOfAdjudication);
  const [finalBGCReport, setFinalBGCReport] = useState({
    value: data?.finalBGCReport,
    label: data?.finalBGCReport,
  });
  const [BGCRemark, setBGCRemark] = useState(data?.BGCRemark);

  const [showSecondary, setShowSecondary] = useState<boolean>(false);
  const [showTertiary, setShowTertiary] = useState<boolean>(false);
  const [candidateId, setCandidateId] = useState(data?.candidateId);
  const [count, setCount] = React.useState(0);

  React.useEffect(() => {
    if (!showModal) {
      setShowSecondary(secondary);
      setShowTertiary(tertiary);
    }
  })

  React.useEffect(() => {
    setCaseID1(data?.caseID1);
    setBGCInitiatedOn(data?.BGCInitiatedOn);
    setPrimaryBGCInitiatedThru({
      value: data?.primaryBGCInitiatedThru,
      label: data?.primaryBGCInitiatedThru,
    });
    setBGCPackage1({
      value: data?.BGCPackage1,
      label: data?.BGCPackage1,
    });
    setBGCPackage2({
      value: data?.BGCPackage2,
      label: data?.BGCPackage2,
    });
    setBGCInvoiceMonth({
      value: data?.BGCInvoiceMonth,
      label: data?.BGCInvoiceMonth,
    });
    setBGCChargesPrimary(data?.BGCChargesPrimary);
    setSecondary(data?.secondary);
    setCaseID2(data?.caseID2);
    setSecondaryBGCInitiatedOn(data?.secondaryBGCInitiatedOn);
    setSecondaryBGCInitiatedThru({
      value: data?.secondaryBGCInitiatedThru,
      label: data?.secondaryBGCInitiatedThru,
    });
    setSecondaryBGCPackage1({
      value: data?.secondaryBGCPackage1,
      label: data?.secondaryBGCPackage1,
    });
    setSecondaryBGCPackage2({
      value: data?.secondaryBGCPackage2,
      label: data?.secondaryBGCPackage2,
    });
    setSecondaryBGCInvoiceMonth({
      value: data?.secondaryBGCInvoiceMonth,
      label: data?.secondaryBGCInvoiceMonth,
    });
    setSecondaryBGCCharges(data?.secondaryBGCCharges);
    setTertiary(data?.tertiary);
    setCaseID3(data?.caseID3);
    setTertiaryBGCInitiatedOn(data?.tertiaryBGCInitiatedOn);
    setTertiaryBGCInitiatedThru({
      value: data?.tertiaryBGCInitiatedThru,
      label: data?.tertiaryBGCInitiatedThru,
    });
    setTertiaryBGCPackage1({
      value: data?.tertiaryBGCPackage1,
      label: data?.tertiaryBGCPackage1,
    });
    setTertiaryBGCPackage2({
      value: data?.tertiaryBGCPackage2,
      label: data?.tertiaryBGCPackage2,
    });
    setTertiaryBGCInvoiceMonth({
      value: data?.tertiaryBGCInvoiceMonth,
      label: data?.tertiaryBGCInvoiceMonth,
    });
    setTertiaryBGCCharges(data?.tertiaryBGCCharges);
    setBGCStatus({
      value: data?.BGCStatus,
      label: data?.BGCStatus,
    });
    setBGCCompletedOn(data?.BGCCompletedOn);
    setBGCAffidavitStatus({
      value: data?.BGCAffidavitStatus,
      label: data?.BGCAffidavitStatus,
    });
    setBGCAffidavitOn(data?.BGCAffidavitOn);
    setBGCReportStatus({
      value: data?.BGCReportStatus,
      label: data?.BGCReportStatus,
    });
    setBGCAdjuStatus({
      value: data?.BGCAdjuStatus,
      label: data?.BGCAdjuStatus,
    });
    setAdjuSupportingDocs(data?.adjuSupportingDocs);
    setDateOfAdjudication(data?.dateOfAdjudication);
    setFinalBGCReport({
      value: data?.finalBGCReport,
      label: data?.finalBGCReport,
    });
    setBGCRemark(data?.BGCRemark);
    setCandidateId(data?.candidateId);

    setSecondary(data?.secondary);
    setShowSecondary(secondary);
    setTertiary(data?.tertiary);
    setShowTertiary(tertiary);
  }, [data])

  function updateCandidateBackground() {
    dispatch(editCandidateBackgroundCheckData(
      caseID1,
      BGCInitiatedOn,
      primaryBGCInitiatedThru,
      BGCPackage1,
      BGCPackage2,
      BGCInvoiceMonth,
      BGCChargesPrimary,
      secondary,
      caseID2,
      secondaryBGCInitiatedOn,
      secondaryBGCInitiatedThru,
      secondaryBGCPackage1,
      secondaryBGCPackage2,
      secondaryBGCInvoiceMonth,
      secondaryBGCCharges,
      tertiary,
      caseID3,
      tertiaryBGCInitiatedOn,
      tertiaryBGCInitiatedThru,
      tertiaryBGCPackage1,
      tertiaryBGCPackage2,
      tertiaryBGCInvoiceMonth,
      tertiaryBGCCharges,
      BGCStatus,
      BGCCompletedOn,
      BGCAffidavitStatus,
      BGCAffidavitOn,
      BGCReportStatus,
      BGCAdjuStatus,
      adjuSupportingDocs,
      dateOfAdjudication,
      finalBGCReport,
      BGCRemark,
      candidateId
    ));
    setShowModal(false);
  }

  return (
    <div>
      <div id="no-scroll-div" className="relative w-[100%] mt-2 shadow-2xl h-[75vh] overflow-auto">
        <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
          <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
            <tr>
              <th scope="col" className="px-6 py-3">
                <span>Background Check</span>
              </th>
              <th>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>case ID-1</span>
              </td>
              <td className='px-6 py-0'>
                <TextField1
                  // label="adju supporting document"
                  value={caseID1}
                  placeholder={""}
                  handleChange={(e: any) =>
                    setCaseID1(e.target.value)
                  }
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>BGC initiated On</span>
              </td>
              <td className='px-6 py-0'>
                <TextField1
                  // label="BGC Initiated On"
                  value={BGCInitiatedOn}
                  type="date"
                  // placeholder={""}
                  handleChange={(e) =>
                    setBGCInitiatedOn(e.target.value)
                  }
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>Primary BGC initiated thru</span>
              </td>
              <td className='px-6 py-0'>
                <Select
                  options={PrimBGCInitiatedThruOptions}
                  value={primaryBGCInitiatedThru}
                  getOptionLabel={(option) => option.label}
                  getOptionValue={(option) => option.value}
                  onChange={(e: any) => {
                    setPrimaryBGCInitiatedThru(e);
                  }}
                  isSearchable={true}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>BGC package 1</span>
              </td>
              <td className='px-6 py-0'>
                <Select
                  options={BGCPackageOptions}
                  value={BGCPackage1}
                  getOptionLabel={(option) => option.label}
                  getOptionValue={(option) => option.value}
                  onChange={(e: any) => {
                    setBGCPackage1(e);
                  }}
                  isSearchable={true}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>BGC package 2</span>
              </td>
              <td className='px-6 py-0'>
                <Select
                  options={BGCPackageOptions}
                  value={BGCPackage2}
                  getOptionLabel={(option) => option.label}
                  getOptionValue={(option) => option.value}
                  onChange={(e: any) => {
                    setBGCPackage2(e);
                  }}
                  isSearchable={true}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>BGC invoice month</span>
              </td>
              <td className='px-6 py-0'>
                <Select
                  options={BGCInvoiceMonthOptions}
                  value={BGCInvoiceMonth}
                  getOptionLabel={(option) => option.label}
                  getOptionValue={(option) => option.value}
                  onChange={(e: any) => {
                    setBGCInvoiceMonth(e);
                  }}
                  isSearchable={true}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>BGC charges primary</span>
              </td>
              <td className='px-6 py-0'>
                <TextField1
                  // label={"BGC charges primary"}
                  value={BGCChargesPrimary}
                  handleChange={(e: any) =>
                    setBGCChargesPrimary(e.target.value)
                  }
                  placeholder={""}
                />
              </td>
            </tr>
          </tbody>
          {!showSecondary ? (
            <div className="add-cancel-1">
              <Button1
                className="btn-size"
                value="+"
                handleClick={() => {
                  // dispatch(setSecondaryButton(true));
                  setShowSecondary(true);
                  setSecondary(true);
                }}
              />
            </div>
          ) : null}
        </table>
        {showSecondary && data?.caseID2 ? (
          <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
            <tbody>
              <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                <td className='px-6 py-4'>
                  <span>case ID-2</span>
                </td>
                <td className='px-6 py-0'>
                  <TextField
                    // label="case ID-2"
                    value={caseID2}
                    placeholder={""}
                    onChange={(e) =>
                      setCaseID2(e.target.value)
                    }
                  />
                </td>
              </tr>
              <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                <td className='px-6 py-4'>
                  <span>Secondary BGC initiated on</span>
                </td>
                <td className='px-6 py-0'>
                  <TextField
                    // label="Secondary BGC Initiated On"
                    value={secondaryBGCInitiatedOn}
                    type="date"
                    placeholder={""}
                    onChange={(e) =>
                      setSecondaryBGCInitiatedOn(e.target.value)
                    }
                  />
                </td>
              </tr>
              <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                <td className='px-6 py-4'>
                  <span>Secondary BGC initiated thru</span>
                </td>
                <td className='px-6 py-0'>
                  <Select
                    options={PrimBGCInitiatedThruOptions}
                    value={secondaryBGCInitiatedThru}
                    getOptionLabel={(option) => option.label}
                    getOptionValue={(option) => option.value}
                    onChange={(e: any) => {
                      setSecondaryBGCInitiatedThru(e);
                    }}
                    isSearchable={true}
                  />
                </td>
              </tr>
              <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                <td className='px-6 py-4'>
                  <span>Secondary BGC check-1</span>
                </td>
                <td className='px-6 py-0'>
                  <Select
                    options={BGCPackageOptions}
                    value={secondaryBGCPackage1}
                    getOptionLabel={(option) => option.label}
                    getOptionValue={(option) => option.value}
                    onChange={(e: any) => {
                      setSecondaryBGCPackage1(e);
                    }}
                    isSearchable={true}
                  />
                </td>
              </tr>
              <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                <td className='px-6 py-4'>
                  <span>Secondary BGC check-2</span>
                </td>
                <td className='px-6 py-0'>
                  <Select
                    options={BGCPackageOptions}
                    value={secondaryBGCPackage2}
                    getOptionLabel={(option) => option.label}
                    getOptionValue={(option) => option.value}
                    onChange={(e: any) => {
                      setSecondaryBGCPackage2(e);
                    }}
                    isSearchable={true}
                  />
                </td>
              </tr>
              <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                <td className='px-6 py-4'>
                  <span>Secondary BGC invoice month</span>
                </td>
                <td className='px-6 py-0'>
                  <Select
                    options={BGCInvoiceMonthOptions}
                    value={secondaryBGCInvoiceMonth}
                    getOptionLabel={(option) => option.label}
                    getOptionValue={(option) => option.value}
                    onChange={(e: any) => {
                      setSecondaryBGCInvoiceMonth(e);
                    }}
                    isSearchable={true}
                  />
                </td>
              </tr>
              <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                <td className='px-6 py-4'>
                  <span>BGC charges secondary</span>
                </td>
                <td className='px-6 py-0'>
                  <TextField
                    // label={"BGC charges Secondary"}
                    value={secondaryBGCCharges}
                    onChange={(e) =>
                      setSecondaryBGCCharges(e.target.value)
                    }
                    placeholder={""}
                  />
                </td>
              </tr>
            </tbody>
            {showSecondary && !showTertiary ? (
              <div className="add-cancel-2">
                <Button1
                  className="btn-size"
                  value="-"
                  handleClick={() => {
                    // dispatch(setSecondaryButton(false));
                    setSecondary(false);
                    setShowSecondary(false);
                  }}
                />
                <Button1
                  className="btn-size"
                  value="+"
                  handleClick={() => {
                    // dispatch(setTertiaryButton(true));
                    setTertiary(true);
                    setShowTertiary(true);
                  }}
                />
              </div>
            ) : null}
          </table>
        ) : null}
        {showTertiary ? (
          <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
            <tbody>
              <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                <td className='px-6 py-4'>
                  <span>case ID-3</span>
                </td>
                <td className='px-6 py-0'>
                  <TextField
                    // label="case ID-2"
                    value={caseID3}
                    placeholder={""}
                    onChange={(e) =>
                      setCaseID3(e.target.value)
                    }
                  />
                </td>
              </tr>
              <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                <td className='px-6 py-4'>
                  <span>Tertiary BGC initiated on</span>
                </td>
                <td className='px-6 py-0'>
                  <TextField
                    // label="Secondary BGC Initiated On"
                    value={tertiaryBGCInitiatedOn}
                    type="date"
                    placeholder={""}
                    onChange={(e) =>
                      setTertiaryBGCInitiatedOn(e.target.value)
                    }
                  />
                </td>
              </tr>
              <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                <td className='px-6 py-4'>
                  <span>Tertiary BGC initiated thru</span>
                </td>
                <td className='px-6 py-0'>
                  <Select
                    options={PrimBGCInitiatedThruOptions}
                    value={tertiaryBGCInitiatedThru}
                    getOptionLabel={(option) => option.label}
                    getOptionValue={(option) => option.value}
                    onChange={(e: any) => {
                      setTertiaryBGCInitiatedThru(e);
                    }}
                    isSearchable={true}
                  />
                </td>
              </tr>
              <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                <td className='px-6 py-4'>
                  <span>Tertiary BGC check-1</span>
                </td>
                <td className='px-6 py-0'>
                  <Select
                    options={BGCPackageOptions}
                    value={tertiaryBGCPackage1}
                    getOptionLabel={(option) => option.label}
                    getOptionValue={(option) => option.value}
                    onChange={(e: any) => {
                      setTertiaryBGCPackage1(e);
                    }}
                    isSearchable={true}
                  />
                </td>
              </tr>
              <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                <td className='px-6 py-4'>
                  <span>Tertiary BGC check-2</span>
                </td>
                <td className='px-6 py-0'>
                  <Select
                    options={BGCPackageOptions}
                    value={tertiaryBGCPackage2}
                    getOptionLabel={(option) => option.label}
                    getOptionValue={(option) => option.value}
                    onChange={(e: any) => {
                      setTertiaryBGCPackage2(e);
                    }}
                    isSearchable={true}
                  />
                </td>
              </tr>
              <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                <td className='px-6 py-4'>
                  <span>Tertiary BGC invoice month</span>
                </td>
                <td className='px-6 py-0'>
                  <Select
                    options={BGCInvoiceMonthOptions}
                    value={tertiaryBGCInvoiceMonth}
                    getOptionLabel={(option) => option.label}
                    getOptionValue={(option) => option.value}
                    onChange={(e: any) => {
                      setTertiaryBGCInvoiceMonth(e);
                    }}
                    isSearchable={true}
                  />
                </td>
              </tr>
              <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                <td className='px-6 py-4'>
                  <span>BGC charges Tertiary</span>
                </td>
                <td className='px-6 py-0'>
                  <TextField
                    value={tertiaryBGCCharges}
                    onChange={(e) =>
                      setTertiaryBGCCharges(e.target.value)
                    }
                    placeholder={""}
                  />
                </td>
              </tr>
            </tbody>
            {showTertiary ? (
              <div className="add-cancel-2">
                <Button1
                  className="btn-size"
                  value="-"
                  handleClick={() => {
                    // dispatch(setTertiaryButton(false));
                    setShowTertiary(false)
                    setTertiary(false);
                  }}
                />
              </div>
            ) : null}
          </table>
        ) : null}
        <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
          <tbody>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>BGC Status Options</span>
              </td>
              <td className='px-6 py-0'>
                <Select
                  options={BGCStatusOptions}
                  value={BGCStatus}
                  getOptionLabel={(option) => option.label}
                  getOptionValue={(option) => option.value}
                  onChange={(e: any) => {
                    setBGCStatus(e);
                  }}
                  isSearchable={true}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>BGC completed on</span>
              </td>
              <td className='px-6 py-0'>
                <TextField1
                  value={BGCCompletedOn}
                  type="date"
                  handleChange={(e) =>
                    setBGCCompletedOn(e.target.value)
                  }
                  placeholder={""}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>BGC affidavit status</span>
              </td>
              <td className='px-6 py-0'>
                <Select
                  options={BGCAffidavitOptions}
                  value={BGCAffidavitStatus}
                  getOptionLabel={(option) => option.label}
                  getOptionValue={(option) => option.value}
                  onChange={(e: any) => {
                    setBGCAffidavitStatus(e);
                  }}
                  isSearchable={true}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>BGC affidavit on</span>
              </td>
              <td className='px-6 py-0'>
                <TextField1
                  value={BGCAffidavitOn}
                  handleChange={(e) =>
                    setBGCAffidavitOn(e.target.value)
                  }
                  placeholder={""}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>BGC report status</span>
              </td>
              <td className='px-6 py-0'>
                <Select
                  options={BGCReportStatusOptions}
                  value={BGCReportStatus}
                  getOptionLabel={(option) => option.label}
                  getOptionValue={(option) => option.value}
                  onChange={(e: any) => {
                    setBGCReportStatus(e);
                  }}
                  isSearchable={true}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>BGC adjudication Status</span>
              </td>
              <td className='px-6 py-0'>
                <Select
                  options={BGCAdjuStatusOptions}
                  value={BGCAdjuStatus}
                  getOptionLabel={(option) => option.label}
                  getOptionValue={(option) => option.value}
                  onChange={(e: any) => {
                    setBGCAdjuStatus(e);
                  }}
                  isSearchable={true}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>Adjudication supporting document</span>
              </td>
              <td className='px-6 py-0'>
                <TextField1
                  value={adjuSupportingDocs}
                  handleChange={(e) =>
                    setAdjuSupportingDocs(e.target.value)
                  }
                  placeholder={""}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>Date of adjudication</span>
              </td>
              <td className='px-6 py-0'>
                <TextField1
                  value={dateOfAdjudication}
                  type="date"
                  handleChange={(e) =>
                    setDateOfAdjudication(e.target.value)
                  }
                  placeholder={""}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>Final BGC report status</span>
              </td>
              <td className='px-6 py-0'>
                <Select
                  options={finalBGCReportOptions}
                  value={finalBGCReport}
                  getOptionLabel={(option) => option.label}
                  getOptionValue={(option) => option.value}
                  onChange={(e: any) => {
                    setFinalBGCReport(e);
                  }}
                  isSearchable={true}
                />
              </td>
            </tr>
            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
              <td className='px-6 py-4'>
                <span>BGC remark</span>
              </td>
              <td className='px-6 py-0'>
                <TextField1
                  value={BGCRemark}
                  placeholder={""}
                  handleChange={(e) => {
                    setBGCRemark(e.target.value)
                  }}
                />
              </td>
            </tr>
          </tbody>
        </table>
        <div className="m-auto w-[20%] ml-[35%] text-white ">
          <Button
            className=''
            value="Update"
            handleClick={() => {
              updateCandidateBackground()
            }}
            styles={{ fontSize: "16px" }}
          />
        </div>
      </div>
    </div>
  );
}

export default ShowBackgroundCheck;