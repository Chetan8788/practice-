import React from "react";
import BackgroundCheck from "./BackgroundCheck";

export default function BackgroundVerification() {
  return (
    <div>
      <BackgroundCheck />
    </div>
  );
}
