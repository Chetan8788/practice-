import React from "react";
import BackgroundCheck from "./BackgroundCheck";
import { Step, StepLabel, Stepper } from "@mui/material";

export default function BackgroundVerification() {
  const steps = [
    "Basic Details",
    "Background Check",
    "Documentation",
    "Start/End Operations",
    "Rate Revision",
  ];
  return (
    <div>
      <Stepper activeStep={1} alternativeLabel>
        {steps.map((label, index) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
      <BackgroundCheck />
    </div>
  );
}
