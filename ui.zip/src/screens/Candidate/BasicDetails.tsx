import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { TextField } from '../../common/TextField/TextField';
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { RootState } from '../../redux/store';
import { setVendorInputBoxValue } from '../../actions/vendor';
import { ContractType, LocationName, WorkAuthorization } from '../../constants/candidateclientconstants';
import Select from 'react-select';
import { Typography } from '@mui/material';
import { EMPTY_ADDRESS_DATA } from '../../utils/addressutil';
import { setClientInputBoxValue } from '../../actions/client';
import { setJobInputBoxValue } from '../../actions/job';
import { JobType, LineOfBusiness, ResumeSource, WorkType } from '../../constants/jobconstants';
import { setCandidateInputBoxValue } from '../../actions/candidate';
import ClientDetails from '../Client/ClientDetails';
import CandidateDetails from './CandidateDetails';
import VendorDetails from '../Vendor/VendorDetails';
import JobDetails from '../Job/JobDetails';

const BasicDetails: React.FC = () => {
    // const dispatch = useAppDispatch();
    // const currentCandidateData = useAppSelector((state: RootState) => state.candidate.candidateData);
    // const currentClientData = useAppSelector((state: RootState) => state.client.clientData);
    // const allClientData = useAppSelector((state: RootState) => state.client.allClientData);
    // let allClientName: object[] = [];
    // if (allClientData.length !== 0) {
    //     allClientData[0].map((a: any) => {
    //         let data = {
    //             label: a?.clientName + " (" + a.city + "/" + a.state + ")",
    //             value: {
    //                 clientId: a?.clientId,
    //                 clientName: a?.clientName,
    //                 endClientName: a?.endClientName,
    //                 MSPName: a?.mspName,
    //                 line1: a?.line1,
    //                 line2: a?.line2,
    //                 city: a?.city,
    //                 state: a?.state,
    //                 zipCode: a?.zipCode,
    //                 country: a?.country
    //             }
    //         }
    //         allClientName.push(data);
    //     });
    // }
    // const currentVendorData = useAppSelector((state: RootState) => state.vendor.vendorData);
    // const allVendorData = useAppSelector((state: RootState) => state.vendor.allVendorData);
    // let allVendorName: object[] = [];
    // if (allVendorData.length !== 0) {
    //     allVendorData[0].map((
    //         a: {
    //             vendorId: number, companyName: string, federalId: string, contactPerson: string, companyEmailID: string,
    //             contactNo: string, faxNo: string, signAuthority: string, signAuthorityDesignation: string,
    //             stateOfIncorporation: string, line1: string, line2: string, city: string, zipCode: string,
    //             state: string, country: string,
    //         }
    //     ) => {
    //         let data = {
    //             label: a.companyName,
    //             value: {
    //                 id: a.vendorId,
    //                 companyName: a.companyName,
    //                 federalId: a.federalId,
    //                 contactPerson: a.contactPerson,
    //                 companyEmailID: a.companyEmailID,
    //                 contactNo: a.contactNo,
    //                 faxNo: a.faxNo,
    //                 signAuthority: a.signAuthority,
    //                 signAuthorityDesignation: a.signAuthorityDesignation,
    //                 stateOfIncorporation: a.stateOfIncorporation,
    //                 line1: a.line1,
    //                 line2: a.line2,
    //                 city: a.city,
    //                 zipCode: a.zipCode,
    //                 state: a.state,
    //                 country: a.country,
    //             }
    //         }
    //         allVendorName.push(data);
    //     });
    // }
    // const currentJobData = useAppSelector((state: RootState) => state.job.jobData);
    // const allJobData = useAppSelector((state: RootState) => state.job.allJobData);
    // let allJobName: object[] = [];
    // if (allJobData.length !== 0) {
    //     allJobData.map((
    //         a: { id: number, requestID: number, jobDivaID: number, jobTitle: string, jobType: string, lineOfBusiness: string, jobDescription: string }
    //     ) => {
    //         let data = {
    //             label: a.jobTitle,
    //             value: {
    //                 id: a.id,
    //                 requestID: a.requestID,
    //                 jobDivaID: a.jobDivaID,
    //                 jobTitle: a.jobTitle,
    //                 jobType: a.jobType,
    //                 lineOfBusiness: a.lineOfBusiness,
    //                 jobDescription: a.jobDescription,
    //             }
    //         }
    //         allJobName.push(data);
    //     });
    // }
    // const locationName = LocationName;
    // const workAuthorization = WorkAuthorization;
    // const contractType = ContractType;
    // const workType = WorkType;
    // const jobType = JobType;
    // const resumeSource = ResumeSource;
    // const lineOfBusiness = LineOfBusiness;

    // const onValueChange = (key: any, value: any) => {
    //     dispatch(setCandidateInputBoxValue(key, value));
    // };

    // const onClientValueChange = (key: any, value: any) => {
    //     dispatch(setClientInputBoxValue(key, value));
    // };

    // const onVendorValueChange = (key: any, value: any) => {
    //     dispatch(setVendorInputBoxValue(key, value));
    // };

    // const onJobValueChange = (key: any, value: any) => {
    //     dispatch(setJobInputBoxValue(key, value));
    // };

    // function displayClientData(value: any) {
    //     onClientValueChange("id", value.clientId);
    //     onClientValueChange("endClientName", value.endClientName);
    //     onClientValueChange("mspName", value.MSPName);
    //     onClientValueChange("line1", value.line1);
    //     onClientValueChange("line2", value.line2);
    //     onClientValueChange("city", value.city);
    //     onClientValueChange("state", { label: value.state, value: value.state });
    //     onClientValueChange("zipCode", value.zipCode);
    //     onClientValueChange("country", value.country);
    // }

    // function displayVendorData(value: any) {
    //     onVendorValueChange("id", value.id);
    //     onVendorValueChange("federalID", value.federalId);
    //     onVendorValueChange("contactPerson", value.contactPerson);
    //     onVendorValueChange("companyEmailID", value.companyEmailID);
    //     onVendorValueChange("contactNo", value.contactNo);
    //     onVendorValueChange("faxNo", value.faxNo);
    //     onVendorValueChange("signAuthority", value.signAuthority);
    //     onVendorValueChange("signAuthorityDesignation", value.signAuthorityDesignation);
    //     onVendorValueChange("stateOfIncorporation", value.stateOfIncorporation);
    //     onVendorValueChange("line1", value.line1);
    //     onVendorValueChange("line2", value.line2);
    //     onVendorValueChange("city", value.city);
    //     onVendorValueChange("zipCode", value.zipCode);
    //     onVendorValueChange("state", { label: value.state, value: value.state });
    //     onVendorValueChange("country", value.country);
    // }

    // function displayJobData(value: any) {
    //     onJobValueChange("id", value.id);
    //     onJobValueChange("requestID", value.requestID);
    //     onJobValueChange("jobDivaID", value.jobDivaID);
    //     // onJobValueChange("jobTitle", value.jobTitle);
    //     onJobValueChange("jobType", { label: value.jobType, value: value.jobType });
    //     onJobValueChange("lineOfBusiness", { label: value.lineOfBusiness, value: value.lineOfBusiness });
    //     onJobValueChange("jobDescription", value.jobDescription);
    //     onJobValueChange("zipCode", value.zipCode);
    //     onJobValueChange("country", value.country);
    // }

    return (
        <>
            <CandidateDetails />
            {/* <Grid container spacing={4}>
                <Grid xs={12} md={12}>
                    Candidate details
                </Grid>
                <Grid xs={12} md={3}>
                    <span>Candidate first name</span>
                    <TextField
                        value={currentCandidateData?.firstName}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("firstName", event?.target?.value);
                        }}
                        className=""
                        styles={{ width: "" }}
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Candidate middle name</span>
                    <TextField
                        value={currentCandidateData?.middleName}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("middleName", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Candidate last name</span>
                    <TextField
                        value={currentCandidateData?.lastName}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("lastName", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Line 1</span>
                    <TextField
                        value={currentCandidateData?.line1}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("line1", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Line 2</span>
                    <TextField
                        value={currentCandidateData?.line2}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("line2", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>City</span>
                    <TextField
                        value={currentCandidateData?.city}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("city", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>State</span>
                    <Select
                        options={locationName}
                        value={currentCandidateData?.state}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                            onValueChange("state", e);
                        }}
                        isSearchable={true}
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Zip code</span>
                    <TextField
                        value={currentCandidateData?.zipCode}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("zipCode", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Country</span>
                    <TextField
                        value={currentCandidateData?.country}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("country", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Candidate email address</span>
                    <TextField
                        value={currentCandidateData?.email}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("email", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Candidate contact no.</span>
                    <TextField
                        value={currentCandidateData?.contactNumber}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("contactNumber", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Work authorization</span>
                    <Select
                        options={workAuthorization}
                        value={currentCandidateData?.workAuthorization}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                            onValueChange("workAuthorization", e);
                        }}
                        isSearchable={true}
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Work authorization expiry date</span>
                    <TextField
                        value={currentCandidateData?.workAuthorizationExpiryDate}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("workAuthorizationExpiryDate", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
            </Grid> */}
            <ClientDetails />
            {/* <Grid xs={12} md={12}>
                <h2>Client details</h2>
            </Grid>
            <Grid container spacing={4}>
                <Grid xs={9} md={9}>
                    <span>Client name</span>
                    <Select
                        options={allClientName}
                        value={currentClientData?.clientName}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                            displayClientData(e.value);
                            onClientValueChange("clientName", e);
                        }}
                        isSearchable={true}
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Contract type</span>
                    <Select
                        options={contractType}
                        value={currentClientData?.contractType}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                            onClientValueChange("contractType", e);
                        }}
                        isSearchable={true}
                    />
                </Grid>
            </Grid>
            <div className="flex gap-16 " style={{ margin: "auto", width: "100%" }}>
                <div className="relative overflow-x-auto w-[100%] mt-10">
                    <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                        <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
                            <tr>
                                <th scope="col" className="px-6 py-3">...</th>
                                <th scope="col" className="px-6 py-3">Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Contract type</span>
                                </td>
                                <td className='px-6 py-0'>
                                    <Select
                                        options={contractType}
                                        value={currentClientData?.contractType}
                                        getOptionLabel={(option) => option.label}
                                        getOptionValue={(option) => option.value}
                                        onChange={(e: any) => {
                                            onClientValueChange("contractType", e);
                                        }}
                                        isSearchable={true}
                                        styles={{
                                            control: (baseStyles, state) => ({
                                              ...baseStyles,
                                              maxHeight: "10px",
                                            }),
                                          }}
                                    />
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>End client name</td>
                                <td className='px-6 py-4'>{currentClientData?.endClientName}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>MSP name</td>
                                <td className='px-6 py-4'>{currentClientData?.mspName}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Address</td>
                                <td className='px-6 py-4'>{currentClientData?.line1} {currentClientData?.line2}, {currentClientData?.city}, {currentClientData?.state.label}, {currentClientData?.zipCode}, {currentClientData?.country}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div> */}
            <VendorDetails />
            {/* <Grid xs={12} md={12}>
                <h2>Vendor details</h2>
            </Grid>
            <Grid container spacing={4}>
                <Grid xs={6} md={6}>
                    <span>Vendor name</span>
                    <Select
                        options={allVendorName}
                        value={currentVendorData?.companyName}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                            displayVendorData(e.value);
                            onVendorValueChange("companyName", e);
                        }}
                        isSearchable={true}
                    />
                </Grid>
            </Grid >

            <div className="flex gap-16 " style={{ margin: "auto", width: "100%" }}>
                <div className="relative overflow-x-auto w-[100%] mt-10">
                    <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                        <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
                            <tr>
                                <th scope="col" className="px-6 py-3">...</th>
                                <th scope="col" className="px-6 py-3">Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Vendor federal ID</td>
                                <td className='px-6 py-4'>{currentVendorData?.federalID}</td>

                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Name of contact person</td>
                                <td className='px-6 py-4'>{currentVendorData?.contactPerson}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Vendor company contact no</td>
                                <td className='px-6 py-4'>{currentVendorData?.contactNo}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Vendor fax no.</td>
                                <td className='px-6 py-4'>{currentVendorData?.faxNo}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Name of sign authority</td>
                                <td className='px-6 py-4'>{currentVendorData?.signAuthority}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Designation of sign authority</td>
                                <td className='px-6 py-4'>{currentVendorData?.signAuthorityDesignation}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Vendor state of incorporation</td>
                                <td className='px-6 py-4'>{currentVendorData?.stateOfIncorporation}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Line 1</td>
                                <td className='px-6 py-4'>{currentVendorData?.line1}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Line 2</td>
                                <td className='px-6 py-4'>{currentVendorData?.line2}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>City</td>
                                <td className='px-6 py-4'>{currentVendorData?.city}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Zipcode</td>
                                <td className='px-6 py-4'>{currentVendorData?.zipCode}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>State</td>
                                <td className='px-6 py-4'>{currentVendorData?.state.value}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Country</td>
                                <td className='px-6 py-4'>{currentVendorData?.country}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div> */}
            <JobDetails />
            {/* <Grid xs={12} md={12}>
                <h2>Job details</h2>
            </Grid>
            <Grid container spacing={4}>
                <Grid xs={6} md={6}>
                    <span>Job title/Position name</span>
                    <Select
                        options={allJobName}
                        value={currentJobData?.jobTitle}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                            displayJobData(e.value);
                            onJobValueChange("jobTitle", e);
                        }}
                        isSearchable={true}
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Candidate working from</span>
                    <TextField
                        value={currentJobData?.workingFrom}
                        placeholder={""}
                        handleChange={(event) => {
                            onJobValueChange("workingFrom", event?.target?.value);
                        }}
                        className="" />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Work type</span>
                    <Select
                        options={workType}
                        value={currentJobData?.workType}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                            onJobValueChange("workType", e);
                        }}
                        isSearchable={true}
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Resume Source</span>
                    <Select
                        options={resumeSource}
                        value={currentJobData?.resumeSource}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                            onJobValueChange("resumeSource", e);
                        }}
                        isSearchable={true}
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Skill set</span>
                    <TextField
                        value={currentJobData?.skillSet}
                        placeholder={""}
                        handleChange={(event) => {
                            onJobValueChange("skillSet", event?.target?.value);
                        }}
                        className="" />
                </Grid>
            </Grid>
            <div className="flex gap-16 " style={{ margin: "auto", width: "100%" }}>
                <div className="relative overflow-x-auto w-[100%] mt-10">
                    <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                        <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
                            <tr>
                                <th scope="col" className="px-6 py-3">...</th>
                                <th scope="col" className="px-6 py-3">Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Request ID</td>
                                <td className='px-6 py-4'>{currentJobData?.requestID}</td>

                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Job diva ID</td>
                                <td className='px-6 py-4'>{currentJobData?.jobDivaID}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Job type</td>
                                <td className='px-6 py-4'>{currentJobData?.jobType.value}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Line of business</td>
                                <td className='px-6 py-4'>{currentJobData?.lineOfBusiness.value}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Job description</td>
                                <td className='px-6 py-4'>{currentJobData?.jobDescription}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div> */}
        </>
    )
}

export default BasicDetails; 
