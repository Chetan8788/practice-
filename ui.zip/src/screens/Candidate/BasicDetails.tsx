import React, { useEffect, useState } from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { TextField } from '../../common/TextField/TextField';
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { RootState } from '../../redux/store';
import { setVendorInputBoxValue } from '../../actions/vendor';
import { ContractType, LocationName, WorkAuthorization } from '../../constants/candidateclientconstants';
import Select from 'react-select';
import { Typography } from '@mui/material';
import { EMPTY_ADDRESS_DATA } from '../../utils/addressutil';
import { setClientInputBoxValue } from '../../actions/client';
import { setJobInputBoxValue } from '../../actions/job';
import { ResumeSourceList, WorkTypeList } from '../../constants/jobconstants';
import { setCandidateInputBoxValue } from '../../actions/candidate';
import ClientDetails from '../Client/ClientDetails';
import CandidateDetails from './CandidateDetails';
import VendorDetails from '../Vendor/VendorDetails';
import JobDetails from '../Job/JobDetails';
import ReferralDetails from '../Referral/ReferralDetails';
import { yesNoList } from '../../constants/constants';
import Fab from "@mui/material/Fab";
import EastIcon from "@mui/icons-material/East";
import { isNumberValid, isTextValid } from '../../helpers/validate';
import BackgroundVerification from '../BackgroundCheck';
import { useNavigate } from 'react-router-dom';


const BasicDetails: React.FC = () => {

    // setValid(false);
    // const dispatch = useAppDispatch();
    // const currentCandidateData = useAppSelector((state: RootState) => state.candidate.candidateData);
    // const currentClientData = useAppSelector((state: RootState) => state.client.clientData);
    // const allClientData = useAppSelector((state: RootState) => state.client.allClientData);
    // let allClientName: object[] = [];
    // if (allClientData.length !== 0) {
    //     allClientData[0].map((a: any) => {
    //         let data = {
    //             label: a?.clientName + " (" + a.city + "/" + a.state + ")",
    //             value: {
    //                 clientId: a?.clientId,
    //                 clientName: a?.clientName,
    //                 endClientName: a?.endClientName,
    //                 MSPName: a?.mspName,
    //                 line1: a?.line1,
    //                 line2: a?.line2,
    //                 city: a?.city,
    //                 state: a?.state,
    //                 zipCode: a?.zipCode,
    //                 country: a?.country
    //             }
    //         }
    //         allClientName.push(data);
    //     });
    // }
    // const currentVendorData = useAppSelector((state: RootState) => state.vendor.vendorData);
    // const allVendorData = useAppSelector((state: RootState) => state.vendor.allVendorData);
    // let allVendorName: object[] = [];
    // if (allVendorData.length !== 0) {
    //     allVendorData[0].map((
    //         a: {
    //             vendorId: number, companyName: string, federalId: string, contactPerson: string, companyEmailID: string,
    //             contactNo: string, faxNo: string, signAuthority: string, signAuthorityDesignation: string,
    //             stateOfIncorporation: string, line1: string, line2: string, city: string, zipCode: string,
    //             state: string, country: string,
    //         }
    //     ) => {
    //         let data = {
    //             label: a.companyName,
    //             value: {
    //                 id: a.vendorId,
    //                 companyName: a.companyName,
    //                 federalId: a.federalId,
    //                 contactPerson: a.contactPerson,
    //                 companyEmailID: a.companyEmailID,
    //                 contactNo: a.contactNo,
    //                 faxNo: a.faxNo,
    //                 signAuthority: a.signAuthority,
    //                 signAuthorityDesignation: a.signAuthorityDesignation,
    //                 stateOfIncorporation: a.stateOfIncorporation,
    //                 line1: a.line1,
    //                 line2: a.line2,
    //                 city: a.city,
    //                 zipCode: a.zipCode,
    //                 state: a.state,
    //                 country: a.country,
    //             }
    //         }
    //         allVendorName.push(data);
    //     });
    // }
    // const currentJobData = useAppSelector((state: RootState) => state.job.jobData);
    // const allJobData = useAppSelector((state: RootState) => state.job.allJobData);
    // let allJobName: object[] = [];
    // if (allJobData.length !== 0) {
    //     allJobData.map((
    //         a: { id: number, requestID: number, jobDivaID: number, jobTitle: string, jobType: string, lineOfBusiness: string, jobDescription: string }
    //     ) => {
    //         let data = {
    //             label: a.jobTitle,
    //             value: {
    //                 id: a.id,
    //                 requestID: a.requestID,
    //                 jobDivaID: a.jobDivaID,
    //                 jobTitle: a.jobTitle,
    //                 jobType: a.jobType,
    //                 lineOfBusiness: a.lineOfBusiness,
    //                 jobDescription: a.jobDescription,
    //             }
    //         }
    //         allJobName.push(data);
    //     });
    // }
    // const locationName = LocationName;
    // const workAuthorization = WorkAuthorization;
    // const contractType = ContractType;
    // const workType = WorkType;
    // const jobType = JobType;
    // const resumeSource = ResumeSource;
    // const lineOfBusiness = LineOfBusiness;

    // const onValueChange = (key: any, value: any) => {
    //     dispatch(setCandidateInputBoxValue(key, value));
    // };

    // const onClientValueChange = (key: any, value: any) => {
    //     dispatch(setClientInputBoxValue(key, value));
    // };

    // const onVendorValueChange = (key: any, value: any) => {
    //     dispatch(setVendorInputBoxValue(key, value));
    // };

    // const onJobValueChange = (key: any, value: any) => {
    //     dispatch(setJobInputBoxValue(key, value));
    // };

    // function displayClientData(value: any) {
    //     onClientValueChange("id", value.clientId);
    //     onClientValueChange("endClientName", value.endClientName);
    //     onClientValueChange("mspName", value.MSPName);
    //     onClientValueChange("line1", value.line1);
    //     onClientValueChange("line2", value.line2);
    //     onClientValueChange("city", value.city);
    //     onClientValueChange("state", { label: value.state, value: value.state });
    //     onClientValueChange("zipCode", value.zipCode);
    //     onClientValueChange("country", value.country);
    // }

    // function displayVendorData(value: any) {
    //     onVendorValueChange("id", value.id);
    //     onVendorValueChange("federalID", value.federalId);
    //     onVendorValueChange("contactPerson", value.contactPerson);
    //     onVendorValueChange("companyEmailID", value.companyEmailID);
    //     onVendorValueChange("contactNo", value.contactNo);
    //     onVendorValueChange("faxNo", value.faxNo);
    //     onVendorValueChange("signAuthority", value.signAuthority);
    //     onVendorValueChange("signAuthorityDesignation", value.signAuthorityDesignation);
    //     onVendorValueChange("stateOfIncorporation", value.stateOfIncorporation);
    //     onVendorValueChange("line1", value.line1);
    //     onVendorValueChange("line2", value.line2);
    //     onVendorValueChange("city", value.city);
    //     onVendorValueChange("zipCode", value.zipCode);
    //     onVendorValueChange("state", { label: value.state, value: value.state });
    //     onVendorValueChange("country", value.country);
    // }

    // function displayJobData(value: any) {
    //     onJobValueChange("id", value.id);
    //     onJobValueChange("requestID", value.requestID);
    //     onJobValueChange("jobDivaID", value.jobDivaID);
    //     // onJobValueChange("jobTitle", value.jobTitle);
    //     onJobValueChange("jobType", { label: value.jobType, value: value.jobType });
    //     onJobValueChange("lineOfBusiness", { label: value.lineOfBusiness, value: value.lineOfBusiness });
    //     onJobValueChange("jobDescription", value.jobDescription);
    //     onJobValueChange("zipCode", value.zipCode);
    //     onJobValueChange("country", value.country);
    // }

    const dispatch = useAppDispatch();
    const currentCandidateData = useAppSelector((state: RootState) => state.candidate.candidateData);
    let workAuthorizationData = useAppSelector((state: RootState) => state.workAuthorization.allWorkAuthorizationData);
    var result: any = [];
    if (workAuthorizationData != undefined) {
        workAuthorizationData.forEach((element: { workAuthorization: any; }) => {
            result.push({
                label: element.workAuthorization,
                value: element.workAuthorization
            });
        });
    }
    const locationName = LocationName;


    const onValueChange = (key: any, value: any) => {
        dispatch(setCandidateInputBoxValue(key, value));
    };

    // candidate  errors and validation

    const [firstName, setFirstName] = useState<any>();
    const [middleName, setMiddleName] = useState<any>();
    const [lastName, setLastName] = useState<any>();
    const [line1, setLine1] = useState<any>();
    const [line2, setLine2] = useState<any>();
    const [city, setCity] = useState<any>();
    const [state, setState] = useState<any>();
    const [zipCode, setZipCode] = useState<any>();
    const [country, setCountry] = useState<any>();
    const [email, setEmail] = useState<any>();
    const [contactNumber, setContactNumber] = useState<any>();
    const [workAuthorization, setWorkAuthorization] = useState<any>();
    const [workAuthorizationExpiryDate, setWorkAuthorizationExpiryDate] = useState<any>();

    const [firstNameError, setFirstNameError] = useState<any>();
    const [middleNameError, setMiddleNameError] = useState<any>();
    const [lastNameError, setLastNameError] = useState<any>();
    const [line1Error, setLine1Error] = useState<any>();
    const [line2Error, setLine2Error] = useState<any>();
    const [cityError, setCityError] = useState<any>();
    const [stateError, setStateError] = useState<any>();
    const [zipCodeError, setZipCodeError] = useState<any>();
    const [countryError, setCountryError] = useState<any>();
    const [emailError, setEmailError] = useState<any>();
    const [contactNumberError, setContactNumberError] = useState<any>();
    const [workAuthorizationError, setWorkAuthorizationError] = useState<any>();
    const [workAuthorizationExpiryDateError, setWorkAuthorizationExpiryDateError] = useState<any>();


    const [firstNameValid, setFirstNameValid] = useState<boolean>();
    const [middleNameValid, setMiddleNameValid] = useState<boolean>();
    const [lastNameValid, setLastNameValid] = useState<boolean>();
    const [line1Valid, setLine1Valid] = useState<boolean>();
    const [line2Valid, setLine2Valid] = useState<boolean>();
    const [cityValid, setCityValid] = useState<boolean>();
    const [stateValid, setStateValid] = useState<boolean>();
    const [zipCodeValid, setZipCodeValid] = useState<boolean>();
    const [countryValid, setCountryValid] = useState<boolean>();
    const [emailValid, setEmailValid] = useState<boolean>();
    const [contactNumberValid, setContactNumberValid] = useState<boolean>();
    const [workAuthorizationValid, setWorkAuthorizationValid] = useState<boolean>();
    const [workAuthorizationExpiryDateValid, setWorkAuthorizationExpiryDateValid] = useState<boolean>();

    // client errors and validation
    const [clientName, setClientName] = useState<any>();
    const [contractType, setContractType] = useState<any>();

    const [clientNameError, setClientNameError] = useState<any>();
    const [contractTypeError, setContractTypeError] = useState<any>();

    const [clientNameValid, setClientNameValid] = useState<boolean>();
    const [contractTypeValid, setContractTypeValid] = useState<boolean>();

    // vendor errors and validation

    const [companyName, setCompanyName] = useState<any>();

    const [companyNameError, setCompanyNameError] = useState<any>();

    const [companyNameValid, setCompanyNameValid] = useState<boolean>();

    // Job errors and validation

    const [jobTitle, setJobTitle] = useState<any>();
    const [workingFrom, setWorkingFrom] = useState<any>();
    const [workType, setWorkType] = useState<any>();
    const [resumeSource, setResumeSource] = useState<any>();
    const [skillSet, setSkillSet] = useState<any>();

    const [jobTitleError, setJobTitleError] = useState<any>();
    const [workingFromError, setWorkingFromError] = useState<any>();
    const [workTypeError, setWorkTypeError] = useState<any>();
    const [resumeSourceError, setResumeSourceError] = useState<any>();
    const [skillSetError, setSkillSetError] = useState<any>();


    const [jobTitleValid, setJobTitleValid] = useState<boolean>();
    const [workingFromValid, setWorkingFromValid] = useState<boolean>();
    const [workTypeValid, setWorkTypeValid] = useState<boolean>();
    const [resumeSourceValid, setResumeSourceValid] = useState<boolean>();
    const [skillSetValid, setSkillSetValid] = useState<boolean>();

    // function validateFields() {

    //     if (!firstNameValid) {
    //         setFirstNameError("First name is invalid")
    //     }
    //     if (!middleNameValid) {
    //         setMiddleNameError("Middle name is invalid")
    //     }
    //     if (!lastNameValid) {
    //         setLastNameError("Last name is invalid");
    //     }
    //     if (!line1Valid) {
    //         setLine1Error("Line 1 is invalid");
    //     }
    //     if (!line2Valid) {
    //         setLine2Error("Line 2 is invalid");
    //     }
    //     if (!cityValid) {
    //         setCityError("City is invalid");
    //     }
    //     if (!stateValid) {
    //         setStateError("State is invalid");
    //     }
    //     if (!zipCodeValid) {
    //         setZipCodeError("Zip code is invalid");
    //     }
    //     if (!countryValid) {
    //         setCountryError("Country is invalid");
    //     }
    //     if (!emailValid) {
    //         setEmailError("Email is invalid");
    //     }
    //     if (!contactNumberValid) {
    //         setContactNumberError("Contact number is invalid");
    //     }
    //     if (!workAuthorizationValid) {
    //         setWorkAuthorizationError("Work authorization is invalid");
    //     }
    //     if (!workAuthorizationExpiryDateValid) {
    //         setWorkAuthorizationError("Work authorization is invalid");
    //     }
    // }

    const currentClientData = useAppSelector((state: RootState) => state.client.clientData);
    let contractTypeData = useAppSelector((state: RootState) => state.contractType.allContractTypeData);
    var result: any = [];
    if (contractTypeData != undefined) {
        contractTypeData.forEach((element: { contractType: any; }) => {
            result.push({
                label: element.contractType,
                value: element.contractType
            });
        });
    }
    const allClientData = useAppSelector((state: RootState) => state.client.allClientData);
    let allClientName: object[] = [];
    if (allClientData.length !== 0) {
        allClientData.map((a: any) => {
            a?.addressId.map((b: any) => {
                let data = {
                    label: a?.clientId.clientName + " (" + b.city + "/" + b.state + ")",
                    value: {
                        clientId: a?.clientId.id,
                        clientName: a?.clientId.clientName,
                        endClientName: a?.clientId.endClientName,
                        MSPName: a?.clientId.mspName,
                        contactNumber: b.contactDetailId.contactNumber,
                        email: b.contactDetailId.email,
                        faxNumber: b.contactDetailId.faxNumber,
                        line1: b?.line1,
                        line2: b?.line2,
                        city: b?.city,
                        state: b?.state,
                        zipCode: b?.zipCode,
                        country: b?.country
                    }
                }
                allClientName.push(data);
            })
        });
    }
    // const contractType = ContractType;

    const onClientValueChange = (key: any, value: any) => {
        dispatch(setClientInputBoxValue(key, value));
    };

    function displayClientData(value: any) {
        onClientValueChange("id", value.clientId);
        onClientValueChange("endClientName", value.endClientName);
        onClientValueChange("mspName", value.MSPName);
        onClientValueChange("contactNumber", value.contactNumber);
        onClientValueChange("email", value.email);
        onClientValueChange("faxNumber", value.faxNumber);
        onClientValueChange("line1", value.line1);
        onClientValueChange("line2", value.line2);
        onClientValueChange("city", value.city);
        onClientValueChange("state", { label: value.state, value: value.state });
        onClientValueChange("zipCode", value.zipCode);
        onClientValueChange("country", value.country);
    }

    const currentVendorData = useAppSelector((state: RootState) => state.vendor.vendorData);
    const allVendorData = useAppSelector((state: RootState) => state.vendor.allVendorData);
    let allVendorName: object[] = [];
    if (allVendorData.length !== 0) {
        allVendorData.map((
            a: any
        ) => {
            a?.addressId.map((b: any) => {
                let data = {
                    label: a.vendorId.companyName,
                    value: {
                        id: a.vendorId.id,
                        companyName: a.vendorId.companyName,
                        federalId: a.vendorId.federalId,
                        contactPerson: a.vendorId.contactPerson,
                        email: b.contactDetailId.email,
                        contactNumber: b.contactDetailId.contactNumber,
                        faxNumber: b.contactDetailId.faxNumber,
                        signAuthority: a.vendorId.signAuthority,
                        signAuthorityDesignation: a.vendorId.signAuthorityDesignation,
                        stateOfIncorporation: a.vendorId.stateOfIncorporation,
                        line1: b.line1,
                        line2: b.line2,
                        city: b.city,
                        zipCode: b.zipCode,
                        state: b.state,
                        country: b.country,
                    }
                }
                allVendorName.push(data);
            })
        });
    }

    const onVendorValueChange = (key: any, value: any) => {
        dispatch(setVendorInputBoxValue(key, value));
    };

    function displayVendorData(value: any) {
        onVendorValueChange("id", value.id);
        onVendorValueChange("federalID", value.federalId);
        onVendorValueChange("contactPerson", value.contactPerson);
        onVendorValueChange("email", value.email);
        onVendorValueChange("contactNumber", value.contactNumber);
        onVendorValueChange("faxNumber", value.contactNumber);
        onVendorValueChange("signAuthority", value.signAuthority);
        onVendorValueChange("signAuthorityDesignation", value.signAuthorityDesignation);
        onVendorValueChange("stateOfIncorporation", value.stateOfIncorporation);
        onVendorValueChange("line1", value.line1);
        onVendorValueChange("line2", value.line2);
        onVendorValueChange("city", value.city);
        onVendorValueChange("zipCode", value.zipCode);
        onVendorValueChange("state", { label: value.state, value: value.state });
        onVendorValueChange("country", value.country);
    }

    const currentJobData = useAppSelector((state: RootState) => state.job.jobData);
    const allJobData = useAppSelector((state: RootState) => state.job.allJobData);
    let allJobName: object[] = [];
    if (allJobData.length !== 0) {
        allJobData.map((
            a: { id: number, requestID: number, jobDivaID: number, jobTitle: string, jobType: string, lineOfBusiness: string, jobDescription: string }
        ) => {
            let data = {
                label: a.jobTitle,
                value: {
                    id: a.id,
                    requestID: a.requestID,
                    jobDivaID: a.jobDivaID,
                    jobTitle: a.jobTitle,
                    jobType: a.jobType,
                    lineOfBusiness: a.lineOfBusiness,
                    jobDescription: a.jobDescription,
                }
            }
            allJobName.push(data);
        });
    }
    // const workType = WorkType;
    // const jobType = JobType;
    // const resumeSource = ResumeSource;
    // const lineOfBusiness = LineOfBusiness;

    const onJobValueChange = (key: any, value: any) => {
        dispatch(setJobInputBoxValue(key, value));
    };

    function displayJobData(value: any) {
        onJobValueChange("id", value.id);
        onJobValueChange("requestID", value.requestID);
        onJobValueChange("jobDivaID", value.jobDivaID);
        // onJobValueChange("jobTitle", value.jobTitle);
        onJobValueChange("jobType", { label: value.jobType, value: value.jobType });
        onJobValueChange("lineOfBusiness", { label: value.lineOfBusiness, value: value.lineOfBusiness });
        onJobValueChange("jobDescription", value.jobDescription);
        onJobValueChange("zipCode", value.zipCode);
        onJobValueChange("country", value.country);
    }

    const [flag, setFlag] = useState<boolean>(false);

    const navigate = useNavigate();

    useEffect(() => {
        setFirstNameValid(isTextValid(firstName))
        setMiddleNameValid(isTextValid(middleName))
        setLastNameValid(isTextValid(lastName))
        setLine1Valid(isTextValid(line1))
        setLine2Valid(isTextValid(line2))
        setCityValid(isTextValid(city))
        setStateValid(isTextValid(state))
        setZipCodeValid(isNumberValid(zipCode))
        setCountryValid(isTextValid(country))
        setEmailValid(isTextValid(email))
        setContactNumberValid(isNumberValid(contactNumber))
        setWorkAuthorizationValid(isTextValid(workAuthorization))
        setWorkAuthorizationExpiryDateValid(isTextValid(workAuthorizationExpiryDate))

        setClientNameValid(isTextValid(clientName))
        setContractTypeValid(isTextValid(contractType))

        setCompanyNameValid(isTextValid(companyName))

        setJobTitleValid(isTextValid(jobTitle))
        setWorkingFromValid(isTextValid(workingFrom))
        setWorkTypeValid(isTextValid(workType))
        setResumeSourceValid(isTextValid(resumeSource))
        setSkillSetValid(isTextValid(skillSet))
    }, [firstName, middleName, lastName, line1, line2, city, state, zipCode, country, email, contactNumber
        , workAuthorization, workAuthorizationExpiryDate, clientName, contractType, companyName, jobTitle
        , workingFrom, workType, resumeSource, skillSet])

    function onSubmitClick() {
        setFirstNameValid(isTextValid(firstName))
        setMiddleNameValid(isTextValid(middleName))
        setLastNameValid(isTextValid(lastName))
        setLine1Valid(isTextValid(line1))
        setLine2Valid(isTextValid(line2))
        setCityValid(isTextValid(city))
        setStateValid(isTextValid(state))
        setZipCodeValid(isNumberValid(zipCode))
        setCountryValid(isTextValid(country))
        setEmailValid(isTextValid(email))
        setContactNumberValid(isNumberValid(contactNumber))
        setWorkAuthorizationValid(isTextValid(workAuthorization))
        setWorkAuthorizationExpiryDateValid(isTextValid(workAuthorizationExpiryDate))

        setClientNameValid(isTextValid(clientName))
        setContractTypeValid(isTextValid(contractType))

        setCompanyNameValid(isTextValid(companyName))

        setJobTitleValid(isTextValid(jobTitle))
        setWorkingFromValid(isTextValid(workingFrom))
        setWorkTypeValid(isTextValid(workType))
        setResumeSourceValid(isTextValid(resumeSource))
        setSkillSetValid(isTextValid(skillSet))
        console.log('setSkillSetValid: ', setSkillSetValid);

        if (firstNameValid
            // && middleNameValid && lastNameValid && line1Valid && line2Valid && cityValid
            // && stateValid && zipCodeValid && countryValid && emailValid && contactNumberValid &&
            // workAuthorizationValid && workAuthorizationExpiryDateValid && clientNameValid && contractTypeValid
            // && companyNameValid && jobTitleValid && workingFromValid && workTypeValid && resumeSourceValid
            // && skillSetValid
        ) {

            console.log('add-candidate-backgroundCheck: ');
            navigate("/add-candidate-backgroundCheck")

        }
        else {
            if (!firstNameValid) {
                setFirstNameError("First name is invalid")
            }
            if (!middleNameValid) {
                setMiddleNameError("Middle name is invalid")
            }
            if (!lastNameValid) {
                setLastNameError("Last name is invalid");
            }
            if (!line1Valid) {
                setLine1Error("Line 1 is invalid");
            }
            if (!line2Valid) {
                setLine2Error("Line 2 is invalid");
            }
            if (!cityValid) {
                setCityError("City is invalid");
            }
            if (!stateValid) {
                setStateError("State is invalid");
            }
            if (!zipCodeValid) {
                setZipCodeError("Zip code is invalid");
            }
            if (!countryValid) {
                setCountryError("Country is invalid");
            }
            if (!emailValid) {
                setEmailError("Email is invalid");
            }
            if (!contactNumberValid) {
                setContactNumberError("Contact number is invalid");
            }
            if (!workAuthorizationValid) {
                setWorkAuthorizationError("Work authorization is invalid");
            }
            if (!workAuthorizationExpiryDateValid) {
                setWorkAuthorizationError("Work authorization is invalid");
            }
        }

    }

    return (
        <>
            <>
                <>
                    Candidate details
                    <div className="flex gap-16 " style={{ margin: "auto", width: "100%" }}>
                        <div className="relative w-[100%] mt-10">
                            <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                                <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
                                    <tr>
                                        <th scope="col" className="px-6 py-3">
                                            {/* <span>Client name</span> */}
                                        </th>
                                        <th>

                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>
                                            <span>Candidate first name</span>
                                        </td>
                                        <td className='px-6 py-0'>
                                            {!firstNameValid ? (
                                                <p className="" style={{ fontSize: "12px", color: "red" }}>{firstNameError}</p>
                                            ) : null}
                                            <TextField
                                                value={currentCandidateData?.firstName}
                                                placeholder={""}
                                                handleChange={(event) => {
                                                    onValueChange("firstName", event?.target?.value);
                                                    setFirstName(currentCandidateData?.firstName)
                                                    // validateFirstName();
                                                }}
                                                className=""
                                            // handleBlur={validateFirstName}
                                            />
                                            {/* {!firstNameValid ? (
                                        <p className="" style={{ fontSize: "12px", color: "red" }}>{firstNameError}</p>
                                    ) : null} */}
                                        </td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>
                                            <span>Candidate middle name</span>
                                        </td>
                                        <td className='px-6 py-0'>
                                            <TextField
                                                value={currentCandidateData?.middleName}
                                                placeholder={""}
                                                handleChange={(event) => {
                                                    onValueChange("middleName", event?.target?.value);
                                                }}
                                                className=""
                                            />
                                        </td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>
                                            <span>Candidate last name</span>
                                        </td>
                                        <td className='px-6 py-0'>
                                            <TextField
                                                value={currentCandidateData?.lastName}
                                                placeholder={""}
                                                handleChange={(event) => {
                                                    onValueChange("lastName", event?.target?.value);
                                                }}
                                                className=""
                                            />
                                        </td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>
                                            <span>Line 1</span>
                                        </td>
                                        <td className='px-6 py-0'>
                                            <TextField
                                                value={currentCandidateData?.line1}
                                                placeholder={""}
                                                handleChange={(event) => {
                                                    onValueChange("line1", event?.target?.value);
                                                }}
                                                className=""
                                            />
                                        </td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>
                                            <span>Line 2</span>
                                        </td>
                                        <td className='px-6 py-0'>
                                            <TextField
                                                value={currentCandidateData?.line2}
                                                placeholder={""}
                                                handleChange={(event) => {
                                                    onValueChange("line2", event?.target?.value);
                                                }}
                                                className=""
                                            />
                                        </td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>
                                            <span>City</span>
                                        </td>
                                        <td className='px-6 py-0'>
                                            <TextField
                                                value={currentCandidateData?.city}
                                                placeholder={""}
                                                handleChange={(event) => {
                                                    onValueChange("city", event?.target?.value);
                                                }}
                                                className=""
                                            />
                                        </td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>
                                            <span>State</span>
                                        </td>
                                        <td className='px-6 py-0'>
                                            <Select
                                                options={locationName}
                                                value={currentCandidateData?.state}
                                                getOptionLabel={(option) => option.label}
                                                getOptionValue={(option) => option.value}
                                                onChange={(e: any) => {
                                                    onValueChange("state", e);
                                                }}
                                                isSearchable={true}
                                            />
                                        </td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>
                                            <span>Zip code</span>
                                        </td>
                                        <td className='px-6 py-0'>
                                            <TextField
                                                value={currentCandidateData?.zipCode}
                                                placeholder={""}
                                                handleChange={(event) => {
                                                    onValueChange("zipCode", event?.target?.value);
                                                }}
                                                className=""
                                            />
                                        </td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>
                                            <span>Country</span>
                                        </td>
                                        <td className='px-6 py-0'>
                                            <TextField
                                                value={currentCandidateData?.country}
                                                placeholder={""}
                                                handleChange={(event) => {
                                                    onValueChange("country", event?.target?.value);
                                                }}
                                                className=""
                                            />
                                        </td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>
                                            <span>Candidate email address</span>
                                        </td>
                                        <td className='px-6 py-0'>
                                            <TextField
                                                value={currentCandidateData?.email}
                                                placeholder={""}
                                                handleChange={(event) => {
                                                    onValueChange("email", event?.target?.value);
                                                }}
                                                className=""
                                            />
                                        </td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>
                                            <span>Candidate contact no.</span>
                                        </td>
                                        <td className='px-6 py-0'>
                                            <TextField
                                                value={currentCandidateData?.contactNumber}
                                                placeholder={""}
                                                handleChange={(event) => {
                                                    onValueChange("contactNumber", event?.target?.value);
                                                }}
                                                className=""
                                            />
                                        </td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>
                                            <span>Work authorization</span>
                                        </td>
                                        <td className='px-6 py-0'>
                                            <Select
                                                // options={workAuthorization}
                                                options={result}
                                                value={currentCandidateData?.workAuthorization}
                                                getOptionLabel={(option) => option.label}
                                                getOptionValue={(option) => option.value}
                                                onChange={(e: any) => {
                                                    onValueChange("workAuthorization", e);
                                                }}
                                                isSearchable={true}
                                            />
                                        </td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>
                                            <span>Work authorization expiry date</span>
                                        </td>
                                        <td className='px-6 py-0'>
                                            <TextField
                                                value={currentCandidateData?.workAuthorizationExpiryDate}
                                                type="date"
                                                placeholder={""}
                                                handleChange={(event) => {
                                                    onValueChange("workAuthorizationExpiryDate", event?.target?.value);
                                                }}
                                                className=""
                                            />
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </>
                <Grid xs={12} md={12}>
                    <h2 style={{ marginTop: "40px" }}>Client details</h2>
                </Grid>
                <div className="flex gap-16 " style={{ margin: "auto", width: "100%" }}>
                    <div className="relative w-[100%] mt-10">
                        <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                            <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
                                <tr>
                                    <th scope="col" className="px-6 py-3">
                                        <span>Client name</span>
                                    </th>
                                    <th scope="col" className="px-6 py-0">
                                        <Select
                                            options={allClientName}
                                            value={currentClientData?.clientName}
                                            getOptionLabel={(option) => option.label}
                                            getOptionValue={(option) => option.value}
                                            onChange={(e: any) => {
                                                displayClientData(e.value);
                                                onClientValueChange("clientName", e);
                                                setClientName(e.value);
                                            }}
                                            isSearchable={true}

                                            styles={{
                                                control: (baseStyles, state) => ({
                                                    ...baseStyles,
                                                    backgroundColor: "rgb(249 250 251)"
                                                }),
                                            }}
                                        />
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>
                                        <span>Contract type</span>
                                    </td>
                                    <td className='px-6 py-0'>
                                        <Select
                                            options={result}
                                            value={currentClientData?.contractType}
                                            getOptionLabel={(option) => option.label}
                                            getOptionValue={(option) => option.value}
                                            onChange={(e: any) => {
                                                onClientValueChange("contractType", e);
                                                setContractType(e.value);
                                            }}
                                            isSearchable={true}
                                            styles={{
                                                control: (baseStyles, state) => ({
                                                    ...baseStyles,
                                                }),
                                            }}
                                        />
                                    </td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>End client name</td>
                                    <td className='px-6 py-4'>{currentClientData?.endClientName}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>MSP name</td>
                                    <td className='px-6 py-4'>{currentClientData?.mspName}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Email</td>
                                    <td className='px-6 py-4'>{currentClientData?.email}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Contact number</td>
                                    <td className='px-6 py-4'>{currentClientData?.contactNumber}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Fax number</td>
                                    <td className='px-6 py-4'>{currentClientData?.faxNumber}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Address</td>
                                    <td className='px-6 py-4'>{currentClientData?.line1} {currentClientData?.line2}, {currentClientData?.city}, {currentClientData?.state.label}, {currentClientData?.zipCode}, {currentClientData?.country}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <Grid xs={12} md={12}>
                    <h2 style={{ marginTop: "40px" }}>Vendor details</h2>
                </Grid>
                <div className="flex gap-16 " style={{ margin: "auto", width: "100%" }}>
                    <div className="relative overflow-x-auto w-[100%] mt-10">
                        <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                            <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
                                <tr>
                                    <th scope="col" className="px-6 py-3">Vendor Name</th>
                                    <th scope="col" className="px-6 py-3">
                                        <Select
                                            options={allVendorName}
                                            value={currentVendorData?.companyName}
                                            getOptionLabel={(option) => option.label}
                                            getOptionValue={(option) => option.value}
                                            onChange={(e: any) => {
                                                displayVendorData(e.value);
                                                onVendorValueChange("companyName", e);
                                                setCompanyName(e.value);
                                            }}
                                            isSearchable={true}
                                        />
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Vendor federal ID</td>
                                    <td className='px-6 py-4'>{currentVendorData?.federalID}</td>

                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Name of contact person</td>
                                    <td className='px-6 py-4'>{currentVendorData?.contactPerson}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Vendor company email</td>
                                    <td className='px-6 py-4'>{currentVendorData?.email}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Vendor company contact number</td>
                                    <td className='px-6 py-4'>{currentVendorData?.contactNumber}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Vendor fax number</td>
                                    <td className='px-6 py-4'>{currentVendorData?.faxNumber}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Name of sign authority</td>
                                    <td className='px-6 py-4'>{currentVendorData?.signAuthority}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Designation of sign authority</td>
                                    <td className='px-6 py-4'>{currentVendorData?.signAuthorityDesignation}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Vendor state of incorporation</td>
                                    <td className='px-6 py-4'>{currentVendorData?.stateOfIncorporation}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Line 1</td>
                                    <td className='px-6 py-4'>{currentVendorData?.line1}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Line 2</td>
                                    <td className='px-6 py-4'>{currentVendorData?.line2}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>City</td>
                                    <td className='px-6 py-4'>{currentVendorData?.city}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Zipcode</td>
                                    <td className='px-6 py-4'>{currentVendorData?.zipCode}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>State</td>
                                    <td className='px-6 py-4'>{currentVendorData?.state.value}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Country</td>
                                    <td className='px-6 py-4'>{currentVendorData?.country}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </>
            <>
                <Grid xs={12} md={12}>
                    <h2 style={{ marginTop: "40px" }}>Job details</h2>
                </Grid>
                <div className="flex gap-16 " style={{ margin: "auto", width: "100%" }}>
                    <div className="relative overflow-x-auto w-[100%] mt-10">
                        <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                            <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
                                <tr>
                                    <th scope="col" className="px-6 py-3">Job title/Position name</th>
                                    <th scope="col" className="px-6 py-0">
                                        <Select
                                            options={allJobName}
                                            value={currentJobData?.jobTitle}
                                            getOptionLabel={(option) => option.label}
                                            getOptionValue={(option) => option.value}
                                            onChange={(e: any) => {
                                                displayJobData(e.value);
                                                onJobValueChange("jobTitle", e);
                                                setJobTitle(e.value);
                                            }}
                                            isSearchable={true}
                                        />
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Working from</td>
                                    <td className='px-6 py-4'>
                                        <TextField
                                            value={currentJobData?.workingFrom}
                                            placeholder={""}
                                            handleChange={(event) => {
                                                onJobValueChange("workingFrom", event?.target?.value);
                                                setWorkingFrom(event?.target?.value);
                                            }}
                                            className="" />
                                    </td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Work type</td>
                                    <td className='px-6 py-4'>
                                        <Select
                                            options={WorkTypeList}
                                            value={currentJobData?.workType}
                                            getOptionLabel={(option) => option.label}
                                            getOptionValue={(option) => option.value}
                                            onChange={(e: any) => {
                                                onJobValueChange("workType", e);
                                                setWorkType(e.value);
                                            }}
                                            isSearchable={true}
                                        /></td>

                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Resume source</td>
                                    <td className='px-6 py-4'>
                                        <Select
                                            options={ResumeSourceList}
                                            value={currentJobData?.resumeSource}
                                            getOptionLabel={(option) => option.label}
                                            getOptionValue={(option) => option.value}
                                            onChange={(e: any) => {
                                                onJobValueChange("resumeSource", e);
                                                setResumeSource(e.value);
                                            }}
                                            isSearchable={true}
                                        /></td>

                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Skill set</td>
                                    <td className='px-6 py-4'>
                                        <TextField
                                            value={currentJobData?.skillSet}
                                            placeholder={""}
                                            handleChange={(event) => {
                                                onJobValueChange("skillSet", event?.target?.value);
                                                setSkillSet(event?.target?.value);
                                            }}
                                            className="" /></td>

                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Request ID</td>
                                    <td className='px-6 py-4'>{currentJobData?.requestID}</td>

                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Job diva ID</td>
                                    <td className='px-6 py-4'>{currentJobData?.jobDivaID}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Job type</td>
                                    <td className='px-6 py-4'>{currentJobData?.jobType.value}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Line of business</td>
                                    <td className='px-6 py-4'>{currentJobData?.lineOfBusiness.value}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Job description</td>
                                    <td className='px-6 py-4'>{currentJobData?.jobDescription}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div >
            </>
            <Fab size="small" color="primary" aria-label="add" onClick={() => {
                onSubmitClick()

            }

            }>
                <EastIcon />
            </Fab>
        </>
    )
}

export default BasicDetails; 
