import React from 'react';
import "./CandidateDetails.css"
import Grid from '@mui/material/Unstable_Grid2';
import { TextField } from '../../common/TextField/TextField';
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { RootState } from '../../redux/store';
import { setCandidateInputBoxValue } from '../../actions/candidate';
import { DropDown } from '../../common/DropDown/DropDown';
import { LocationName, WorkAuthorization } from '../../constants/candidateclientconstants';
import Select from 'react-select';

const CandidateDetails: React.FC = () => {
    const dispatch = useAppDispatch();
    const currentCandidateData = useAppSelector((state: RootState) => state.candidate.candidateData);
    let workAuthorizationData = useAppSelector((state: RootState) => state.workAuthorization.allWorkAuthorizationData);
    var result: any = [];
    if (workAuthorizationData != undefined) {
        workAuthorizationData.forEach((element: { workAuthorization: any; }) => {
            result.push({
                label: element.workAuthorization,
                value: element.workAuthorization
            });
        });
    }
    const locationName = LocationName;
    // const workAuthorization = WorkAuthorization;

    const onValueChange = (key: any, value: any) => {
        dispatch(setCandidateInputBoxValue(key, value));
    };

    return (
        <>
            Candidate details
            <div className="flex gap-16 " style={{ margin: "auto", width: "100%" }}>
                <div className="relative w-[100%] mt-10">
                    <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                        <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
                            <tr>
                                <th scope="col" className="px-6 py-3">
                                    {/* <span>Client name</span> */}
                                </th>
                                <th>

                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Candidate first name</span>
                                </td>
                                <td className='px-6 py-0'>
                                    <TextField
                                        value={currentCandidateData?.firstName}
                                        placeholder={""}
                                        handleChange={(event) => {
                                            onValueChange("firstName", event?.target?.value);
                                        }}
                                        className=""
                                    />
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Candidate middle name</span>
                                </td>
                                <td className='px-6 py-0'>
                                    <TextField
                                        value={currentCandidateData?.middleName}
                                        placeholder={""}
                                        handleChange={(event) => {
                                            onValueChange("middleName", event?.target?.value);
                                        }}
                                        className=""
                                    />
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Candidate last name</span>
                                </td>
                                <td className='px-6 py-0'>
                                    <TextField
                                        value={currentCandidateData?.lastName}
                                        placeholder={""}
                                        handleChange={(event) => {
                                            onValueChange("lastName", event?.target?.value);
                                        }}
                                        className=""
                                    />
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Line 1</span>
                                </td>
                                <td className='px-6 py-0'>
                                    <TextField
                                        value={currentCandidateData?.line1}
                                        placeholder={""}
                                        handleChange={(event) => {
                                            onValueChange("line1", event?.target?.value);
                                        }}
                                        className=""
                                    />
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Line 2</span>
                                </td>
                                <td className='px-6 py-0'>
                                    <TextField
                                        value={currentCandidateData?.line2}
                                        placeholder={""}
                                        handleChange={(event) => {
                                            onValueChange("line2", event?.target?.value);
                                        }}
                                        className=""
                                    />
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>City</span>
                                </td>
                                <td className='px-6 py-0'>
                                    <TextField
                                        value={currentCandidateData?.city}
                                        placeholder={""}
                                        handleChange={(event) => {
                                            onValueChange("city", event?.target?.value);
                                        }}
                                        className=""
                                    />
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>State</span>
                                </td>
                                <td className='px-6 py-0'>
                                    <Select
                                        options={locationName}
                                        value={currentCandidateData?.state}
                                        getOptionLabel={(option) => option.label}
                                        getOptionValue={(option) => option.value}
                                        onChange={(e: any) => {
                                            onValueChange("state", e);
                                        }}
                                        isSearchable={true}
                                    />
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Zip code</span>
                                </td>
                                <td className='px-6 py-0'>
                                    <TextField
                                        value={currentCandidateData?.zipCode}
                                        placeholder={""}
                                        handleChange={(event) => {
                                            onValueChange("zipCode", event?.target?.value);
                                        }}
                                        className=""
                                    />
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Country</span>
                                </td>
                                <td className='px-6 py-0'>
                                    <TextField
                                        value={currentCandidateData?.country}
                                        placeholder={""}
                                        handleChange={(event) => {
                                            onValueChange("country", event?.target?.value);
                                        }}
                                        className=""
                                    />
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Candidate email address</span>
                                </td>
                                <td className='px-6 py-0'>
                                    <TextField
                                        value={currentCandidateData?.email}
                                        placeholder={""}
                                        handleChange={(event) => {
                                            onValueChange("email", event?.target?.value);
                                        }}
                                        className=""
                                    />
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Candidate contact no.</span>
                                </td>
                                <td className='px-6 py-0'>
                                    <TextField
                                        value={currentCandidateData?.contactNumber}
                                        placeholder={""}
                                        handleChange={(event) => {
                                            onValueChange("contactNumber", event?.target?.value);
                                        }}
                                        className=""
                                    />
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Work authorization</span>
                                </td>
                                <td className='px-6 py-0'>
                                    <Select
                                        // options={workAuthorization}
                                        options={result}
                                        value={currentCandidateData?.workAuthorization}
                                        getOptionLabel={(option) => option.label}
                                        getOptionValue={(option) => option.value}
                                        onChange={(e: any) => {
                                            onValueChange("workAuthorization", e);
                                        }}
                                        isSearchable={true}
                                    />
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Work authorization expiry date</span>
                                </td>
                                <td className='px-6 py-0'>
                                    <TextField
                                        value={currentCandidateData?.workAuthorizationExpiryDate}
                                        placeholder={""}
                                        handleChange={(event) => {
                                            onValueChange("workAuthorizationExpiryDate", event?.target?.value);
                                        }}
                                        className=""
                                    />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </>
    )
}

export default CandidateDetails;