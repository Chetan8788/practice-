import AddCandidate from "./AddCandidate";

const AddCandidateScreen: React.FC = () => {

    return (
        <AddCandidate />
    )
}

export default AddCandidateScreen;