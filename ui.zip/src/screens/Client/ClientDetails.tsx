import React from "react";
import { RootState } from "../../redux/store";
import { useAppDispatch, useAppSelector } from "../../hooks/app";
import { setClientInputBoxValue, setClientValidation } from "../../actions/client";
import {
    ContractType,
    LocationName,
} from "../../constants/candidateclientconstants";
import Select from "react-select";
import Grid from "@mui/material/Unstable_Grid2";
import { yesNoList } from "../../constants/constants";
import { isTextValid } from "../../helpers/validate";

const ClientDetails: React.FC = () => {
    const dispatch = useAppDispatch();
    const currentClientData = useAppSelector(
        (state: RootState) => state.client.clientData
    );
    const validationClientData = useAppSelector(
        (state: RootState) => state.client.clientValidationData
    );
    console.log('validationClientData: ', validationClientData);
    let contractTypeData = useAppSelector(
        (state: RootState) => state.contractType.allContractTypeData
    );
    var result: any = [];
    if (contractTypeData != undefined) {
        contractTypeData.forEach((element: { contractType: any }) => {
            result.push({
                label: element.contractType,
                value: element.contractType,
            });
        });
    }
    const allClientData = useAppSelector(
        (state: RootState) => state.client.allClientData
    );
    let allClientName: object[] = [];
    if (allClientData.length !== 0) {
        allClientData.map((a: any) => {
            a?.addressId.map((b: any) => {
                let data = {
                    label: a?.clientId.clientName + " (" + b.city + "/" + b.state + ")",
                    value: {
                        clientId: a?.clientId.id,
                        clientName: a?.clientId.clientName,
                        endClientName: a?.clientId.endClientName,
                        MSPName: a?.clientId.mspName,
                        contactNumber: b.contactDetailId.contactNumber,
                        email: b.contactDetailId.email,
                        faxNumber: b.contactDetailId.faxNumber,
                        line1: b?.line1,
                        line2: b?.line2,
                        city: b?.city,
                        state: b?.state,
                        zipCode: b?.zipCode,
                        country: b?.country,
                    },
                };
                allClientName.push(data);
            });
        });
    }
    const locationName = LocationName;
    // const contractType = ContractType;

    const onClientValueChange = (key: any, value: any) => {
        dispatch(setClientInputBoxValue(key, value));
    };

    const onValidationChange = (key: any, value: any) => {
        dispatch(setClientValidation(key, value));
    };

    function displayClientData(value: any) {
        onClientValueChange("id", value.clientId);
        onClientValueChange("endClientName", value.endClientName);
        onClientValueChange("mspName", value.MSPName);
        onClientValueChange("contactNumber", value.contactNumber);
        onClientValueChange("email", value.email);
        onClientValueChange("faxNumber", value.faxNumber);
        onClientValueChange("line1", value.line1);
        onClientValueChange("line2", value.line2);
        onClientValueChange("city", value.city);
        onClientValueChange("state", { label: value.state, value: value.state });
        onClientValueChange("zipCode", value.zipCode);
        onClientValueChange("country", value.country);
    }

    return (
        <>
            <h1 className="mt-7"> Client Details</h1>
            <div className="flex gap-5 " style={{ margin: "auto", width: "100%" }}>
                <div className="relative w-[100%] mt-10 ">
                    <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-200 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" className="px-6 py-4">
                                    Initial details
                                </th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className="bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700">
                                <td className="px-6 py-4 font-semibold ">
                                    <span>Client name</span>
                                </td>
                                <td scope="col" className="px-6 py-0">
                                    <Select
                                        className='text-[13px] text-left'
                                        options={allClientName}
                                        value={currentClientData?.clientName}
                                        getOptionLabel={(option) => option.label}
                                        getOptionValue={(option) => option.value}
                                        onChange={(e: any) => {
                                            displayClientData(e.value);
                                            onClientValueChange("clientName", e);
                                            if (!isTextValid(e?.value?.clientName)) {
                                                onValidationChange("clientNameValid", "Client name is invalid");
                                            } else {
                                                onValidationChange("clientNameValid", " ");
                                            }
                                        }}
                                        isSearchable={true}
                                        styles={{
                                            control: (baseStyles, state) => ({
                                                ...baseStyles,
                                                backgroundColor: "rgb(249 250 251)",
                                            }),
                                        }}
                                    />
                                    <p className="" style={{ fontSize: "12px", color: "red" }}>{validationClientData?.clientNameValid}</p>
                                </td>
                            </tr>

                            <tr className="bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700">
                                <td className="px-6 py-4 font-semibold">
                                    <span>Contact Type</span>
                                </td>
                                <td className="px-6 py-0">
                                    <Select
                                        className='text-[13px] text-left'
                                        options={result}
                                        value={currentClientData?.contractType}
                                        getOptionLabel={(option) => option.label}
                                        getOptionValue={(option) => option.value}
                                        onChange={(e: any) => {
                                            onClientValueChange("contractType", e);
                                            if (!isTextValid(e?.value)) {
                                                onValidationChange("contractTypeValid", "Contract type is invalid");
                                            } else {
                                                onValidationChange("contractTypeValid", " ");
                                            }
                                        }}
                                        isSearchable={true}
                                        styles={{
                                            control: (baseStyles, state) => ({
                                                ...baseStyles,
                                            }),
                                        }}
                                    />
                                    <p className="" style={{ fontSize: "12px", color: "red" }}>{validationClientData?.contractTypeValid}</p>
                                </td>
                            </tr>
                            <tr className="bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700">
                                <td className="px-6 py-4 font-semibold">
                                    <span>End Client Name</span>
                                </td>
                                <td className="px-6 py-4">
                                    {currentClientData?.endClientName}
                                </td>
                            </tr>
                            <tr className="bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700">
                                <td className="px-6 py-4 font-semibold">
                                    <span>Msp Name</span>
                                </td>{" "}
                                <td className="px-6 py-4">{currentClientData?.mspName}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div className="relative w-[100%] mt-10 bg-[#f8f8f8dd]">
                    <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-200 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" className="px-6 py-4">
                                    Other details
                                </th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className="bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700">
                                <td className="px-6 py-4 font-semibold">
                                    <span>Email</span>
                                </td>
                                <td className="px-6 py-4">{currentClientData?.email}</td>
                            </tr>
                            <tr className="bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700">
                                <td className="px-6 py-4 font-semibold">
                                    <span>Contact Number</span>
                                </td>
                                <td className="px-6 py-4">
                                    {" "}
                                    {currentClientData?.contactNumber}
                                </td>
                            </tr>
                            <tr className="bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700">
                                <td className="px-6 py-4 font-semibold">
                                    <span>Fax No</span>
                                </td>{" "}
                                <td className="px-6 py-4">{currentClientData?.faxNumber}</td>
                            </tr>
                            <tr className="bg-[#f8f8f8dd] border-b dark:bg-gray-800 dark:border-gray-700">
                                <td className="px-6 py-4 font-semibold">
                                    <span>Address</span>
                                </td>
                                <td className="px-6 py-4">
                                    {currentClientData?.line1} {currentClientData?.line2},{" "}
                                    {currentClientData?.city}, {currentClientData?.state.label},{" "}
                                    {currentClientData?.zipCode}, {currentClientData?.country}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </>
    );
};

export default ClientDetails;
