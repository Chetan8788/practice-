
import React, { useState } from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { TextField } from '../../common/TextField/TextField';
import { editClientData, saveClientData, setClientInputBoxValue, updateOnlyClientData } from '../../actions/client';
import { ContractType, LocationName } from '../../constants/candidateclientconstants';
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { RootState } from '../../redux/store';
import { Box } from '@mui/material';
import { Button } from '../../common/Button/Button';
import { useNavigate } from 'react-router-dom';
import { addClientStateList } from '../../constants/constants';
import { isEmailValid, isTextValid } from '../../helpers/validate';
import { EMPTY_ADDRESS_DATA } from '../../utils/addressutil';
import Select from 'react-select';
import { FloatLabel } from '../../common/FloatLabel/FloatLabel';
import { editContactData } from '../../actions/contact';

interface Props {
    setShowModal: any,
    data: any
}

const EditClientDetails: React.FC<Props> = ({ setShowModal, data }) => {
    console.log('data: ', data);
    const dispatch = useAppDispatch();
    const currentClientData = useAppSelector((state: RootState) => state.client.clientData);
    const allClientData = useAppSelector((state: RootState) => state.client.allClientData);
    let allClientName: object[] = [];
    const locationName = LocationName;


    const [clientNameError, setClientNameError] = useState<any>();
    const [endClientNameError, setEndClientNameError] = useState<any>();
    const [mspNameError, setMspNameError] = useState<any>();
    const [line1Error, setLine1Error] = useState<any>();
    const [line2Error, setLine2Error] = useState<any>();
    const [cityError, setCityError] = useState<any>();
    const [stateError, setStateError] = useState<any>();
    const [zipCodeError, setZipCodeError] = useState<any>();
    const [countryError, setCountryError] = useState<any>();
    const [emailError, setEmailError] = useState<any>();
    const [contactError, setContactError] = useState<any>();
    const [faxError, setFaxError] = useState<any>();


    const onValueChange = (key: any, value: any) => {
        dispatch(setClientInputBoxValue(key, value));
    };

    const boxStyle = {
        alignItems: 'center',
        border: 'none', flexGrow: 1,
        marginTop: "3%", overflowY: "auto",
        overflowX: 'hidden',
        height: "70vh",
        paddingRight: "10px",
        paddingLeft: "10px"
    }

    const [clientName, setClientName] = useState(data?.clientId?.clientName);
    const [endClientName, setEndClientName] = useState(data?.clientId?.endClientName);
    const [mspName, setMspName] = useState(data?.clientId?.mspName);
    const [line1, setLine1] = useState(data?.addressId[0]?.line1);
    const [line2, setLine2] = useState(data?.addressId[0]?.line2);
    const [city, setCity] = useState(data?.addressId[0]?.city);
    const [state, setState] = useState(data?.addressId[0]?.state);
    const [zipCode, setZipCode] = useState(data?.addressId[0]?.zipCode);
    const [country, setCountry] = useState(data?.addressId[0]?.country);
    const [email, setEmail] = useState(data?.addressId[0]?.contactDetailId?.email);
    const [contact, setContact] = useState(data?.addressId[0]?.contactDetailId?.contactNumber);
    const [fax, setFax] = useState(data?.addressId[0]?.contactDetailId?.faxNumber);

    const [clientNameValid, setClientNameValid] = useState<boolean>();
    const [endClientNameValid, setEndClientNameValid] = useState<boolean>();
    const [mspNameValid, setMspNameValid] = useState<boolean>();
    const [line1Valid, setLine1Valid] = useState<boolean>();
    const [line2Valid, setLine2Valid] = useState<boolean>();
    const [cityValid, setCityValid] = useState<boolean>();
    const [stateValid, setStateValid] = useState<boolean>();
    const [zipCodeValid, setZipCodeValid] = useState<boolean>();
    const [countryValid, setCountryValid] = useState<boolean>();
    const [emailValid, setEmailValid] = useState<boolean>();
    const [contactValid, setContactValid] = useState<boolean>();
    const [faxValid, setFaxValid] = useState<boolean>();

    const onSubmitClick = () => {

        setClientNameValid(isTextValid(clientName));
        setEndClientNameValid(isTextValid(endClientName));
        setMspNameValid(isTextValid(mspName));
        setLine1Valid(isTextValid(line1));
        setLine2Valid(isTextValid(line2));
        setCityValid(isTextValid(city));
        setStateValid(isTextValid(state));
        setZipCodeValid(isTextValid(zipCode));
        setCountryValid(isTextValid(country));
        setEmailValid(isEmailValid(email));
        setContactValid(isTextValid(contact.toString()));
        setFaxValid(isTextValid(fax.toString()));

        // console.log('setShowModal: ', setShowModal);
        console.log('contact: ', contact);
        console.log('fax: ', fax);
        console.log('contactValid: ', contactValid);
        console.log('faxValid: ', faxValid);
        console.log('stateValid: ', stateValid);
        console.log('clientNameValid: ', clientNameValid);

        if (clientNameValid && endClientNameValid && mspNameValid && line1Valid && line2Valid && cityValid
            && stateValid && countryValid && emailValid && zipCodeValid && contactValid && faxValid) {

            dispatch(updateOnlyClientData(
                data?.id,
                clientName,
                endClientName,
                mspName
            ))
            dispatch(editClientData(
                data?.addressId[0]?.personId,
                line1,
                line2,
                city,
                state?.value,
                zipCode,
                country
            ));
            dispatch(editContactData(
                email,
                contact,
                fax,
                data?.addressId[0]?.id,
            ))
            setShowModal(false);
        } else {
            if (!clientNameValid) {
                setClientNameError("Client name is Invalid")
            }
            if (!endClientNameValid) {
                setEndClientNameError("End client name is Invalid")
            }
            if (!mspNameValid) {
                setMspNameError("Msp name is Invalid")
            }
            if (!line1Valid) {
                setLine1Error("Line 1 is Invalid")
            }
            if (!line2Valid) {
                setLine2Error("Line 2 is Invalid")
            }
            if (!cityValid) {
                setCityError("City is Invalid")
            }
            if (!stateValid) {
                setStateError("State is Invalid")
            }
            if (!zipCodeValid) {
                setZipCodeError("Zip code is Invalid");
            }
            if (!countryValid) {
                setCountryError("Country is Invalid");
            }
            if (!emailValid) {
                setEmailError("Email is Invalid");
            }
            if (!contactValid) {
                setContactError("Contact is Invalid");
            }
            if (!faxValid) {
                setFaxError("Fax no is Invalid");
            }
        }
    }

    return (
        <>
            {/* <Box sx={boxStyle}> */}
            {/* <h6>Client details</h6> */}
            <div className="pt-5 px-5">
                <Grid container spacing={2}>
                    <Grid xs={6} md={6}>
                        <FloatLabel
                            label='*Client name'
                            value={clientName}
                            placeholder={""}
                            handleChange={(event) => {
                                setClientName(event.target.value.replace(/[0-9]/gi, ""));
                                setClientNameValid(isTextValid(clientName));
                            }}
                            className=""
                        />
                        {!clientNameValid ? (
                            <p className="" style={{ fontSize: "12px", color: "red" }}>{clientNameError}</p>
                        ) : null}
                    </Grid>
                    <Grid xs={6} md={6}>
                        <FloatLabel
                            label='*End client name'
                            value={endClientName}
                            placeholder={""}
                            handleChange={(event) => {
                                setEndClientName(event.target.value.replace(/[0-9]/gi, ""));
                                setEndClientNameValid(isTextValid(endClientName));
                            }}
                            className=""
                        />
                        {!endClientNameValid ? (
                            <p className="" style={{ fontSize: "12px", color: "red" }}>{endClientNameError}</p>
                        ) : null}
                    </Grid>
                    <Grid xs={6} md={6}>
                        <FloatLabel
                            label='*MSP name'
                            value={mspName}
                            placeholder={""}
                            handleChange={(event) => {
                                setMspName(event.target.value.replace(/[0-9]/gi, ""));
                                setMspNameValid(isTextValid(mspName));
                            }}
                            className=""
                        />
                        {!mspNameValid ? (
                            <p className="" style={{ fontSize: "12px", color: "red" }}>{mspNameError}</p>
                        ) : null}
                    </Grid>
                    <Grid xs={6} md={6}>
                        <FloatLabel
                            label='*Email'
                            value={email}
                            placeholder={""}
                            handleChange={(event) => {
                                setEmail(event.target.value.replace(/\s/g, ""));
                                setEmailValid(isEmailValid(email));
                            }}
                            className=""
                        />
                        {!emailValid ? (
                            <p className="" style={{ fontSize: "12px", color: "red" }}>{emailError}</p>
                        ) : null}
                    </Grid>
                    <Grid xs={6} md={6}>
                        <FloatLabel
                            label='*Contact number'
                            value={contact}
                            placeholder={""}
                            handleChange={(event) => {
                                setContact(event.target.value.replace(/[^0-9]/gi, ""));
                                setContactValid(isTextValid(contact));
                            }}
                            className=""
                        />
                        {!contactValid ? (
                            <p className="" style={{ fontSize: "12px", color: "red" }}>{contactError}</p>
                        ) : null}
                    </Grid>
                    <Grid xs={6} md={6}>
                        <FloatLabel
                            label='*Fax number'
                            value={fax}
                            placeholder={""}
                            handleChange={(event) => {
                                setFax(event.target.value.replace(/[^0-9]/gi, ""));
                                setFaxValid(isTextValid(fax));
                            }}
                            className=""
                        />
                        {!faxValid ? (
                            <p className="" style={{ fontSize: "12px", color: "red" }}>{faxError}</p>
                        ) : null}
                    </Grid>
                    <Grid xs={6} md={6}>
                        <FloatLabel
                            label='*Address line 1'
                            value={line1}
                            placeholder={""}
                            handleChange={(event) => {
                                setLine1(event?.target?.value);
                                setLine1Valid(isTextValid(line1));
                            }}
                            className=""
                        />
                        {!line1Valid ? (
                            <p className="" style={{ fontSize: "12px", color: "red" }}>{line1Error}</p>
                        ) : null}
                    </Grid>
                    <Grid xs={6} md={6}>
                        <FloatLabel
                            label='*Address line 2'
                            value={line2}
                            placeholder={""}
                            handleChange={(event) => {
                                setLine2(event?.target?.value);
                                setLine2Valid(isTextValid(line2));
                            }}
                            className=""
                        />
                        {!line2Valid ? (
                            <p className="" style={{ fontSize: "12px", color: "red" }}>{line2Error}</p>
                        ) : null}
                    </Grid>
                    <Grid xs={6} md={6}>
                        <FloatLabel
                            label='*City'
                            value={city}
                            placeholder={""}
                            handleChange={(event) => {
                                setCity(event.target.value.replace(/[0-9]/gi, ""));
                                setCityValid(isTextValid(city));
                            }}
                            className=""
                        />
                        {!cityValid ? (
                            <p className="" style={{ fontSize: "12px", color: "red" }}>{cityError}</p>
                        ) : null}
                    </Grid>
                    <Grid xs={6} md={6}>
                        <Select
                            placeholder="Work state"
                            options={locationName}
                            value={state}
                            getOptionLabel={(option) => option.label}
                            getOptionValue={(option) => option.value}
                            onChange={(e: any) => {
                                setState(e)
                                setStateValid(isTextValid(state.value));
                            }}
                            isSearchable={true}
                        />
                        {!stateValid ? (
                            <p className="" style={{ fontSize: "12px", color: "red" }}>{stateError}</p>
                        ) : null}
                    </Grid>
                    <Grid xs={6} md={6}>
                        <FloatLabel
                            label='*Zip code'
                            value={zipCode}
                            placeholder={""}
                            handleChange={(event) => {
                                setZipCode(event.target.value.replace(/[^0-9]/gi, ""));
                                setZipCodeValid(isTextValid(zipCode));
                            }}
                            className=""
                        />
                        {!zipCodeValid ? (
                            <p className="" style={{ fontSize: "12px", color: "red" }}>{zipCodeError}</p>
                        ) : null}
                    </Grid>
                    <Grid xs={6} md={6}>
                        {/* <span>*Client country</span> */}
                        <FloatLabel
                            label='*Client country'
                            value={country}
                            placeholder={""}
                            handleChange={(event) => {
                                setCountry(event.target.value.replace(/[0-9]/gi, ""));
                                setCountryValid(isTextValid(country));
                            }}
                            className=""
                        />
                        {!countryValid ? (
                            <p className="" style={{ fontSize: "12px", color: "red" }}>{countryError}</p>
                        ) : null}
                    </Grid>
                </Grid>
                <Grid xs={12} md={12}>
                    <div className="rate-revision-btn-div">
                        <Button
                            className="submit-btn"
                            value="Update client"
                            handleClick={() => onSubmitClick()}
                        />
                    </div>
                </Grid>
            </div>
        </>
    )
}

export default EditClientDetails;