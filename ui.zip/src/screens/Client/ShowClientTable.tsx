import { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../hooks/app"
import { RootState } from "../../redux/store";
import Button from '@mui/material/Button';
import { Link } from "react-router-dom";
import { allClientData, deleteClientData } from "../../actions/client";
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import ShowClient from "./ShowIndividualClient";
import { Accordion, AccordionSummary, AccordionDetails } from "@mui/material";
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'

const ShowClientTable: React.FC = () => {
    const dispatch = useAppDispatch();
    const [open, setOpen] = useState(false);

    let clientData = useAppSelector((state: RootState) => state.client.allClientData);
    let clientDataRow = clientData;
    const [filteredData, setFilteredData] = useState(clientData);
    const [count, setCount] = useState(true);
    const [singleClientData, setSingleClientData] = useState({});
    const [expanded, setExpanded] = useState<string | false>(false);

    const handleChange =
        (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
            setExpanded(isExpanded ? panel : false);
        };

    useEffect(() => {
        if (count) {
            if (clientData?.length !== 0) {
                dispatch(allClientData());
                setFilteredData(clientData?.filter((cd: { clientId: any; }) =>
                    cd?.clientId.clientName?.toLowerCase().includes("")
                ));
                setCount(false);
            }
        }
    }, [clientData])

    const filterResult = (event: any) => {
        setFilteredData(clientDataRow);
        let value: string = event.target.value;

        if (clientData.length !== 0) {
            setFilteredData(clientData?.filter((cd: { clientId: any; }) =>
                cd?.clientId.clientName?.toLowerCase().includes(value.toLowerCase())
            ))
        }
    }

    const showClient = (data: any) => {
        setSingleClientData(data);
        setOpen(true);
    }

    function deleteClientAddress(personId: any): void {
        dispatch(deleteClientData(personId));
        setCount(true);
    }

    const boxStyle = {
        alignItems: 'center',
        border: 'none', flexGrow: 1,
        marginTop: "3%", overflowY: "auto",
        overflowX: 'hidden',
        height: "60vh",
        paddingRight: "10px",
        paddingLeft: "10px"
    }

    const button = {
        backgroundColor: "Green",
        border: "none",
        color: "white",
        padding: "15px 32px",
        textAlign: "center",
        textDecoration: "none",
        display: "inline - block",
        fontSize: "16px",
    }

    return (
        <>
            <div style={{ display: "flex" }}>
                <div style={{ borderRadius: "15px", marginBottom: "10px", width: "90%" }} className="py-3 px-4">
                    <div className="relative max-w">
                        <label htmlFor="hs-table-search" className="sr-only">Search</label>
                        <input style={{ border: '0.5px solid gray' }} type="text" name="hs-table-search" id="hs-table-search" className="ml-[-13px] p-2 pl-10 block w-[35%] border-gray-200 rounded-md text-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400" placeholder="Search for clients" onChange={(event) => filterResult(event)} />
                        <div className="absolute inset-y-0 left-0 flex items-center pointer-events-none pl-2">
                            <svg className="h-3.5 w-3.5 text-gray-400" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                            </svg>
                        </div>
                    </div>
                </div>
                <div style={{ width: "10%", maxHeight: "100%", justifyContent: "center", alignContent: "center" }}>
                    <Button variant="contained" component={Link} to={"/add-client"}>Add client</Button>
                </div>
            </div>
            <div className="flex flex-col" style={{ height: "70vh" }}>
                <div className="-m-1.5 overflow-x-auto">
                    <div className="p-1.5 min-w-full inline-block align-middle">
                        <div className="border rounded-lg divide-y divide-gray-200 dark:border-gray-700 dark:divide-gray-700">

                            <div className="overflow-hidden">
                                {
                                    (() => {
                                        if (filteredData && filteredData?.length !== 0) {
                                            return (
                                                filteredData.map((data: any, index: any) => (
                                                    <Accordion expanded={expanded === 'panel' + index} onChange={handleChange('panel' + index)}>
                                                        <AccordionSummary
                                                            expandIcon={<ExpandMoreIcon />}
                                                            aria-controls={"panel" + index + "bh-content"}
                                                            id={"panel" + index + "bh-header"}
                                                        >
                                                            {data?.clientId.clientName}
                                                        </AccordionSummary>
                                                        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                                            <thead className="bg-gray-50 dark:bg-gray-700">
                                                                <tr>
                                                                    {/* <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Client name</th> */}
                                                                    <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Address</th>
                                                                    <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">City</th>
                                                                    <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">State</th>
                                                                    <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                                                                {
                                                                    data.addressId?.map((data1: any, index1: any) => (
                                                                        <tr key={index} onClick={() => showClient({
                                                                            personId: data.clientId.personId,
                                                                            clientName: data.clientId.clientName,
                                                                            line1: data1.line1,
                                                                            line2: data1.line2,
                                                                            city: data1.city,
                                                                            state: data1.state,
                                                                            zipCode: data1.zipCode,
                                                                            country: data1.country
                                                                        })}>
                                                                            {/* <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{data?.clientId.clientName}</td> */}
                                                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200">{data1.line1 + " " + data1.line2}</td>
                                                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200">{data1.city}</td>
                                                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200">{data1.state}</td>
                                                                            < td className="px-6 py-4 whitespace-nowrap text-center text-sm font-medium" onClick={(e) => e.stopPropagation()}>
                                                                                <button className="text-blue-500 hover:text-blue-700" onClick={() => deleteClientAddress(data.clientId.personId)}>
                                                                                    <DeleteForeverIcon></DeleteForeverIcon>
                                                                                </button>
                                                                            </td>
                                                                        </tr>
                                                                    ))
                                                                }

                                                            </tbody>
                                                        </table>

                                                    </Accordion>
                                                ))
                                            )
                                        }
                                    })()
                                }
                            </div>
                        </div>
                    </div>
                </div >
            </div >
            <ShowClient open={open} setOpen={setOpen} data={singleClientData} showTableCount={setCount} />
        </>
    )
}

export default ShowClientTable;