import ClientDetails from "./ClientDetails";


const ClientScreen: React.FC = () => {

    return (
        <ClientDetails />
    )
}

export default ClientScreen;