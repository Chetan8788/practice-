import React from "react"
import ContentArea from "./contentarea";

const ContentAreaScreen: React.FC = () => {
    return (
        <>
            <ContentArea />
        </>
    )
}

export default ContentAreaScreen;