import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { TextField } from '../../common/TextField/TextField';
import { Button } from '../../common/Button/Button';
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { RootState } from '../../redux/store';
import { saveContractTypeData, setContractTypeInputBoxValue } from '../../actions/contractType';

const AddContractType: React.FC = () => {
    const dispatch = useAppDispatch();
    const contractType = useAppSelector((state: RootState) => state.contractType.contractTypeData);
    
    const onContractTypeValueChange = (key: any, value: any) => {
        dispatch(setContractTypeInputBoxValue(key, value));
    };

    function onSubmitClick() {
        dispatch(saveContractTypeData(contractType?.contractType))
    }

    return (
        <>
            <h2>Contract type</h2>
            <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                <tbody>
                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                        <td className='px-6 py-4'>
                            <span>Contract type</span>
                        </td>
                        <td className='px-6 py-4'>
                            <TextField
                                value={contractType?.contractType}
                                placeholder={""}
                                handleChange={(event) => {
                                    onContractTypeValueChange("contractType", event.target.value);
                                }}
                                className="" />
                        </td>
                    </tr>
                </tbody>
            </table>

            <Grid xs={12} md={12}>
                <div className="rate-revision-btn-div">
                    <Button
                        className="submit-btn"
                        value="Save & Submit"
                        handleClick={() => onSubmitClick()}
                    />
                </div>
            </Grid>
        </>
    )
}

export default AddContractType;