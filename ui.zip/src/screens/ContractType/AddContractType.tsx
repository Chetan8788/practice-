import React, { useEffect, useState } from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { TextField } from '../../common/TextField/TextField';
import { Button } from '../../common/Button/Button';
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { RootState } from '../../redux/store';
import { saveContractTypeData, setContractTypeInputBoxValue } from '../../actions/contractType';
import { isTextValid } from '../../helpers/validate';

const AddContractType: React.FC = () => {
    const dispatch = useAppDispatch();
    const contractType = useAppSelector((state: RootState) => state.contractType.contractTypeData);

    const onContractTypeValueChange = (key: any, value: any) => {
        dispatch(setContractTypeInputBoxValue(key, value));
    };

    const [contractTypeError, setContractTypeError] = useState<any>();

    const [contractTypeValid, setContractTypeValid] = useState<boolean>();

    useEffect(() => {
        setContractTypeValid(isTextValid(contractType?.contractType))
    }, [contractType])

    function onSubmitClick() {
        setContractTypeValid(isTextValid(contractType?.contractType))
        if (contractTypeValid) {
            dispatch(saveContractTypeData(contractType?.contractType))
        }
        else {
            if (!contractTypeValid) {
                setContractTypeError("Contract type is invalid");
            }
        }
    }

    return (
        <>
            <h2>Contract type</h2>
            <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                <tbody>
                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                        <td className='px-6 py-4'>
                            <span>Contract type</span>
                        </td>
                        <td className='px-6 py-4'>
                            {!contractTypeValid ? (
                                <p className="" style={{ fontSize: "12px", color: "red" }}>{contractTypeError}</p>
                            ) : null}
                            <TextField
                                value={contractType?.contractType}
                                placeholder={""}
                                handleChange={(event) => {
                                    onContractTypeValueChange("contractType", event.target.value);
                                }}
                                className="" />
                        </td>
                    </tr>
                </tbody>
            </table>

            <Grid xs={12} md={12}>
                <div className="rate-revision-btn-div">
                    <Button
                        className="submit-btn"
                        value="Save & Submit"
                        handleClick={() => onSubmitClick()}
                    />
                </div>
            </Grid>
        </>
    )
}

export default AddContractType;