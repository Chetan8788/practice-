import React from 'react';
import ShowContractTypeTable from './ShowContractTypeTable';

const ContractType: React.FC = () => {

    return (
        <>
            <ShowContractTypeTable />
        </>
    )
}

export default ContractType;