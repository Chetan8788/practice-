import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import EditIcon from '@mui/icons-material/Edit';
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { getImportantCandidateData } from '../../actions/candidate';
import { RootState } from '../../redux/store';
import ShowDocumentation from '../Documentation/ShowIndividualDocumentation';
import { Modal } from '../../common/Modal/Modal';
import ShowBackgroundCheck from '../BackgroundCheck/ShowIndividualBackgroundCheck';
import ShowRateRevision from '../RateRevision/ShowIndividualRateRevision';
import ShowStartEndOperations from '../StartEndOperations/ShowIndividualStartEndOperations';
import ShowCandidate from '../Candidate/ShowIndividualCandidate';
import { Accordion, AccordionSummary } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import ShowClient from '../Client/ShowIndividualClient';
import ShowCandidateClient from '../Client/ShowCandidateClient';
import ShowIndividualAddress from '../Address/ShowIndividualAddress';

export const AllData: React.FC = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const dispatch = useAppDispatch();
    let bgData = useAppSelector((state: RootState) => state?.backgroundCheck?.singleBackgroundCheckData);
    let docData = useAppSelector((state: RootState) => state?.documentation?.singleDocumentationData);
    let startEndData = useAppSelector((state: RootState) => state?.startEndOperations?.singleStartEndOperationData);
    let rateData = useAppSelector((state: RootState) => state?.rateRevision?.singleRateRevisionData);
    let candidateAddressData = useAppSelector((state: RootState) => state?.candidate?.singleCandidateData);
    console.log('candidateAddressData: ', candidateAddressData);
    let candidateData: any = candidateAddressData?.candidateId;
    let addressData: any[] = candidateAddressData?.addressId;
    console.log('addressData: ', addressData);
    const [int, setInt] = useState(1);
    const [singleVendorData, setSingleVendorData] = useState({});
    const [expanded, setExpanded] = useState<string | false>(false);
    const [showAddressModal, setShowAddressModal] = useState(false);

    const handleChange =
        (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
            setExpanded(isExpanded ? panel : false);
        };

    const showVendor = (data: any) => {
        // setSingleVendorData(data);
        setOpen(true);
        setShowAddressModal(true)
    }

    useEffect(() => {
        dispatch(getImportantCandidateData(candidateData?.id));
    }, [])

    let importantCandidateData: any = useAppSelector((state: RootState) => state.candidate.importantCandidateData);
    console.log('importantCandidateData: ', importantCandidateData);
    const [open, setOpen] = useState(false);
    const [count, setCount] = useState(true);

    const [showModal, setShowModal] = useState<boolean>(false);
    const handleCloseModal = () => {
        setShowModal(false);
    };

    const handleAddressCloseModal = () => {
        setShowAddressModal(false);
    };

    const editButton = () => {
        setOpen(true);
        setShowModal(true);
    }

    return (
        <>
            <div>
                <nav>
                    <ul className='flex m-auto w-[100%]'>
                        <li
                            className={int == 1 ? 'w-[25%]  bg-white text-black p-1 rounded-t-xl border-solid border-[1px] border-gray-400' :
                                'w-[25%] bg-[#1976D2] text-white p-1 rounded-t-xl'}
                            // className='bg-blue-400 text-white p-1 rounded-t-xl'
                            onClick={() => {
                                // navigate("/background-data")
                                setInt(1);
                            }
                            }
                        >Candidate details</li>
                        <li
                            className={int == 2 ? 'w-[25%]  bg-white text-black p-1 rounded-t-xl border-solid border-[1px] border-gray-400' :
                                'w-[25%] bg-[#1976D2] text-white p-1 rounded-t-xl'}
                            // className='bg-blue-400 text-white p-1 rounded-t-xl'
                            onClick={() => {
                                // navigate("/background-data")
                                setInt(2);
                            }
                            }
                        >Background Check Data</li>
                        <li
                            className={int == 3 ? 'w-[25%] bg-white text-black p-1 rounded-t-xl border-solid border-[1px] border-gray-400' :
                                'w-[25%] bg-[#1976D2] text-white p-1 rounded-t-xl'}
                            // className='bg-blue-400 text-white p-1 rounded-t-xl'
                            onClick={() => {
                                // navigate("/document-data")
                                setInt(3);
                            }
                            }>Documentation Data</li>
                        <li
                            className={int == 4 ? 'w-[25%] bg-white text-black p-1 rounded-t-xl border-solid border-[1px] border-gray-400' :
                                'w-[25%] bg-[#1976D2] text-white p-1 rounded-t-xl'}
                            // className='bg-blue-400 text-white p-1 rounded-t-xl'
                            onClick={() => {
                                // navigate("/start-end-data")
                                setInt(4);
                            }
                            }>Start End Operations Data</li>
                        <li
                            className={int == 5 ? 'w-[25%] bg-white text-black p-1 rounded-t-xl border-solid border-[1px] border-gray-400' :
                                'w-[25%] bg-[#1976D2] text-white p-1 rounded-t-xl'}
                            // className='bg-blue-400 text-white p-1 rounded-t-xl'
                            onClick={() => {
                                // navigate("/rate-data")
                                setInt(5);
                            }
                            }>Rate Revision Data</li>
                        <li
                            className={int == 6 ? 'w-[25%] bg-white text-black p-1 rounded-t-xl border-solid border-[1px] border-gray-400' :
                                'w-[25%] bg-[#1976D2] text-white p-1 rounded-t-xl'}
                            // className='bg-blue-400 text-white p-1 rounded-t-xl'
                            onClick={() => {
                                // navigate("/rate-data")
                                setInt(6);
                            }
                            }>Other Data</li>
                    </ul>
                </nav>
            </div>
            {int == 1 &&
                <>
                    <div id="no-scroll-div" className="relative w-[100%] mt-2 shadow-2xl h-[75vh] overflow-auto">
                        <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                            <tbody>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'><span>First name</span></td>
                                    <td className='px-6 py-0'>{candidateData?.firstName}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Middle name</td>
                                    <td className='px-6 py-4'>{candidateData?.middleName}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Last name</td>
                                    <td className='px-6 py-4'>{candidateData?.lastName}</td>
                                </tr>
                                {/* {renderTable} */}
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Work authorization</td>
                                    <td className='px-6 py-4'>{candidateData?.workAuthorizationId}</td>
                                </tr>
                                <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                    <td className='px-6 py-4'>Work authorization expiry date</td>
                                    <td className='px-6 py-4'>{candidateData?.workAuthorizationExpiryDate}</td>
                                </tr>
                            </tbody>
                        </table>
                        <>
                            {addressData?.map((data: any, index: any) => (
                                <Accordion expanded={expanded === 'panel' + index} onChange={handleChange('panel' + index)}>
                                    <AccordionSummary
                                        style={{ color: 'gray', fontSize: "15px", paddingLeft: '25px' }}
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls={"panel" + index + "bh-content"}
                                        id={"panel" + index + "bh-header"}
                                    >
                                        {"  Address " + (index + 1)}
                                    </AccordionSummary>
                                    <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                        <thead className="bg-gray-50 dark:bg-gray-700">
                                            <tr>
                                                {/* <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Client name</th> */}
                                                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Line 1</th>
                                                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Line 2</th>
                                                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">City</th>
                                                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">State</th>
                                                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Zip code</th>
                                                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Country</th>
                                                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Email</th>
                                                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Contact</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-gray-200 dark:divide-gray-700"
                                            style={{ color: 'gray', fontSize: "15px" }}
                                        >
                                            {/* { */}
                                            {/* // data.addressId?.map((data1: any, index1: any) => ( */}
                                            <tr key={index} onClick={() => showVendor({
                                                // personId: data.vendorId.personId,
                                                // companyName: data.vendorId.companyName,
                                                // line1: data1.line1,
                                                // line2: data1.line2,
                                                // city: data1.city,
                                                // state: data1.state,
                                                // zipCode: data1.zipCode,
                                                // country: data1.country
                                            })}>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{data?.line1}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200">{data?.line2}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200">{data?.city}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200">{data?.state}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{data?.zipCode}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200">{data?.country}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200">{data?.contactDetailId?.email}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200">{data?.contactDetailId?.contactNumber}</td>
                                                {/* < td className="px-6 py-4 whitespace-nowrap text-center text-sm font-medium" onClick={(e) => e.stopPropagation()}>
                                        <button className="text-blue-500 hover:text-blue-700" onClick={() => deleteAlert(data.vendorId.personId)}>
                                            <DeleteForeverIcon></DeleteForeverIcon>
                                        </button>
                                    </td> */}
                                            </tr>
                                            {/* // )
                                            )
                                        // } */}

                                        </tbody>
                                    </table>
                                    
                                    <Modal
                                        children={<ShowIndividualAddress data={data} />}
                                        modalStyle={{ marginTop: "50px", height: "78vh", overflow: "scroll", boxShadow: "initial" }}
                                        showModalHeader={true}
                                        modalHeader={"Update Data"}
                                        isFlexible={true}
                                        topRightCloseButtonID={"x-  "}
                                        showModal={showAddressModal}
                                        showBackButton={true}
                                        showBBPSLogo={true}
                                        handleBackClick={handleAddressCloseModal}
                                    ></Modal>
                                </Accordion>
                            ))
                            }
                        </>
                    </div>

                </>
            }
            {
                int == 2 &&
                <div id="no-scroll-div" className="relative w-[100%] mt-2  shadow-2xl h-[75vh] overflow-auto ">
                    <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                        <tbody>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Adjustment status</span>
                                </td>
                                <td className='px-6 py-0'>
                                    {bgData?.BGCAdjuStatus}
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Affidavite on</td>
                                <td className='px-6 py-4'>{bgData?.BGCAffidavitOn}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Affidavite status</td>
                                <td className='px-6 py-4'>{bgData?.BGCAffidavitStatus}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Primary charges</td>
                                <td className='px-6 py-4'>{bgData?.BGCChargesPrimary}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Completed on</td>
                                <td className='px-6 py-4'>{bgData?.BGCCompletedOn}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Initiated on</td>
                                <td className='px-6 py-4'>{bgData?.BGCInitiatedOn}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Invoice month</td>
                                <td className='px-6 py-4'>{bgData?.BGCInvoiceMonth}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Package 1</td>
                                <td className='px-6 py-4'>{bgData?.BGCPackage1}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Package 2</td>
                                <td className='px-6 py-4'>{bgData?.BGCPackage2}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Remarks</td>
                                <td className='px-6 py-4'>{bgData?.BGCRemark}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Report status</td>
                                <td className='px-6 py-4'>{bgData?.BGCReportStatus}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Status</td>
                                <td className='px-6 py-4'>{bgData?.BGCStatus}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Adjust supporting docs</td>
                                <td className='px-6 py-4'>{bgData?.adjuSupportingDocs}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Case Id 1</td>
                                <td className='px-6 py-4'>{bgData?.caseID1}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Created at</td>
                                <td className='px-6 py-4'>{bgData?.createdAt}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Date of adjudication</td>
                                <td className='px-6 py-4'>{bgData?.dateOfAdjudication}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Final Report</td>
                                <td className='px-6 py-4'>{bgData?.finalBGCReport}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Primary initiated through</td>
                                <td className='px-6 py-4'>{bgData?.primaryBGCInitiatedThru}</td>
                            </tr>
                            {bgData?.secondary ?
                                <>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>Case Id 2</td>
                                        <td className='px-6 py-4'>{bgData?.caseID2}</td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>Secondary charges</td>
                                        <td className='px-6 py-4'>{bgData?.secondaryBGCCharges}</td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>Secondary initiated on</td>
                                        <td className='px-6 py-4'>{bgData?.secondaryBGCInitiatedOn}</td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>Secondary initiated through</td>
                                        <td className='px-6 py-4'>{bgData?.secondaryBGCInitiatedThru}</td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>Secondary invoice month</td>
                                        <td className='px-6 py-4'>{bgData?.secondaryBGCInvoiceMonth}</td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>Secondary Package 1</td>
                                        <td className='px-6 py-4'>{bgData?.secondaryBGCPackage1}</td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>Secondary Package 2</td>
                                        <td className='px-6 py-4'>{bgData?.secondaryBGCPackage2}</td>
                                    </tr>
                                </>
                                : null}
                            {bgData?.tertiary ?
                                <>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>Case Id 3</td>
                                        <td className='px-6 py-4'>{bgData?.caseID3}</td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>Tertiary BGC Charges</td>
                                        <td className='px-6 py-4'>{bgData?.tertiaryBGCCharges}</td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>Tertiary BGC Initiated On</td>
                                        <td className='px-6 py-4'>{bgData?.tertiaryBGCInitiatedOn}</td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>Tertiary BGC Initiated Thru</td>
                                        <td className='px-6 py-4'>{bgData?.tertiaryBGCInitiatedThru}</td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>Tertiary BGC Invoice Month</td>
                                        <td className='px-6 py-4'>{bgData?.tertiaryBGCInvoiceMonth}</td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>Tertiary BGC Package 1</td>
                                        <td className='px-6 py-4'>{bgData?.tertiaryBGCPackage1}</td>
                                    </tr>
                                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                        <td className='px-6 py-4'>Tertiary BGC Package 2</td>
                                        <td className='px-6 py-4'>{bgData?.tertiaryBGCPackage2}</td>
                                    </tr>
                                </>
                                : null}
                        </tbody>
                    </table>
                </div>
            }
            {/* ------------------------------- */}
            {
                int == 3 &&
                <div id="no-scroll-div" className="relative w-[100%] mt-2 shadow-2xl h-[75vh]  overflow-auto">
                    <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                        <tbody>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>CIPCICICA or CIPCICU</span>
                                </td>
                                <td className='px-6 py-0'>
                                    {docData?.CIPCICICAOrCIPCICU}
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>E-verification Date</td>
                                <td className='px-6 py-4'>{docData?.E_verificationDate}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>E-verify</td>
                                <td className='px-6 py-4'>{docData?.E_verify}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>I9 form</td>
                                <td className='px-6 py-4'>{docData?.I9Form}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>MSA</td>
                                <td className='px-6 py-4'>{docData?.MSA}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>SOW</td>
                                <td className='px-6 py-4'>{docData?.SOW}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>SOW validity</td>
                                <td className='px-6 py-4'>{docData?.SOWValidity}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Task order expiry date</td>
                                <td className='px-6 py-4'>{docData?.TaskOrderExpiryDate}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Articles or certificate of incorporation</td>
                                <td className='px-6 py-4'>{docData?.articlesOrCertificateOFIncorporation}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Certificate of insurance or COI</td>
                                <td className='px-6 py-4'>{docData?.certificateOFInsuranceOrCOI}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Certificate of insurance</td>
                                <td className='px-6 py-4'>{docData?.certificationOfInsurance}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Client task order or sow</td>
                                <td className='px-6 py-4'>{docData?.clientTaskOrderOrSOW}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Client task order or sow st</td>
                                <td className='px-6 py-4'>{docData?.clientTaskOrderOrSOWst}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Client task order signing</td>
                                <td className='px-6 py-4'>{docData?.clientTaskOrderSigning}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Created at</td>
                                <td className='px-6 py-4'>{docData?.createdAt}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Direct deposit agreement</td>
                                <td className='px-6 py-4'>{docData?.directDepositAgreement}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Documentation completion date</td>
                                <td className='px-6 py-4'>{docData?.documentationCompletionDate}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Documentation remark</td>
                                <td className='px-6 py-4'>{docData?.documentationRemark}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Documentation status</td>
                                <td className='px-6 py-4'>{docData?.documentationStatus}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Emergency form</td>
                                <td className='px-6 py-4'>{docData?.emergencyForm}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Good standing document</td>
                                <td className='px-6 py-4'>{docData?.goodStandingDocument}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>List A document</td>
                                <td className='px-6 py-4'>{docData?.listADocument}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>List B document</td>
                                <td className='px-6 py-4'>{docData?.listBDocument}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>List C document</td>
                                <td className='px-6 py-4'>{docData?.listCDocument}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Vaccination status</td>
                                <td className='px-6 py-4'>{docData?.vaccinationStatus}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Void check or email content</td>
                                <td className='px-6 py-4'>{docData?.voidCheckOrEmailContent}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>W9 or W4</td>
                                <td className='px-6 py-4'>{docData?.w9Orw4}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Work authorization document</td>
                                <td className='px-6 py-4'>{docData?.workAuthorizationDocument}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            }

            {/* --------------------- */}
            {
                int == 4 &&
                <div id="no-scroll-div" className="relative w-[100%] mt-2 shadow-2xl h-[75vh] overflow-auto">
                    <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                        <tbody>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Associate director</span>
                                </td>
                                <td className='px-6 py-0'>
                                    {startEndData?.assoDirector}
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Center Head</td>
                                <td className='px-6 py-4'>{startEndData?.centerHead}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Created at</td>
                                <td className='px-6 py-4'>{startEndData?.createdAt}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>CRM</td>
                                <td className='px-6 py-4'>{startEndData?.crm}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>End date</td>
                                <td className='px-6 py-4'>{startEndData?.endDate}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>End reason</td>
                                <td className='px-6 py-4'>{startEndData?.endReason}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>End remarks</td>
                                <td className='px-6 py-4'>{startEndData?.endRemarks}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Exit clearance</td>
                                <td className='px-6 py-4'>{startEndData?.exitClearance}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>FF invoice status</td>
                                <td className='px-6 py-4'>{startEndData?.ffInvoiceStatus}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Full time salary offered</td>
                                <td className='px-6 py-4'>{startEndData?.fullTimeSalaryOffered}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Gross BR</td>
                                <td className='px-6 py-4'>{startEndData?.grossBr}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Health benefits cost</td>
                                <td className='px-6 py-4'>{startEndData?.hBenefitesCost}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Opted for health benefits</td>
                                <td className='px-6 py-4'>{startEndData?.hBenefitesOpted}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Job level</td>
                                <td className='px-6 py-4'>{startEndData?.jobLevel}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Joining status</td>
                                <td className='px-6 py-4'>{startEndData?.joiningStatus}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Joining status remarks</td>
                                <td className='px-6 py-4'>{startEndData?.joiningStatusRemark}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Joining type</td>
                                <td className='px-6 py-4'>{startEndData?.joiningType}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Margin</td>
                                <td className='px-6 py-4'>{startEndData?.margin}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>MSP fee</td>
                                <td className='px-6 py-4'>{startEndData?.mspFee}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>MSP Fee percentage</td>
                                <td className='px-6 py-4'>{startEndData?.mspFeePercentage}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Net bill rate</td>
                                <td className='px-6 py-4'>{startEndData?.netBillRate}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Net purchase</td>
                                <td className='px-6 py-4'>{startEndData?.netPurchase}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Onboarding coordinator</td>
                                <td className='px-6 py-4'>{startEndData?.onboCoordinator}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Onsite account director</td>
                                <td className='px-6 py-4'>{startEndData?.onsiteAccDirector}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Pay rate</td>
                                <td className='px-6 py-4'>{startEndData?.payRate}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Recruiter</td>
                                <td className='px-6 py-4'>{startEndData?.recruiter}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Referral fee</td>
                                <td className='px-6 py-4'>{startEndData?.refFee}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Senior manager</td>
                                <td className='px-6 py-4'>{startEndData?.seniorManager}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Tax OH</td>
                                <td className='px-6 py-4'>{startEndData?.taxOH}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Tax OH percentage</td>
                                <td className='px-6 py-4'>{startEndData?.taxOHPercentage}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Team lead</td>
                                <td className='px-6 py-4'>{startEndData?.teamLead}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Team manager</td>
                                <td className='px-6 py-4'>{startEndData?.teamManager}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            }
            {/* ---------------------------------------- */}
            {
                int == 5 &&
                <div id="no-scroll-div" className="relative w-[100%] mt-2 shadow-2xl h-[75vh] overflow-auto">
                    <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                        <tbody>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Created at</span>
                                </td>
                                <td className='px-6 py-0'>
                                    {rateData?.createdAt}
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Gross BR</td>
                                <td className='px-6 py-4'>{rateData?.grossBr}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Health benefits</td>
                                <td className='px-6 py-4'>{rateData?.healthB}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Margin</td>
                                <td className='px-6 py-4'>{rateData?.margin}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>MSP fee</td>
                                <td className='px-6 py-4'>{rateData?.mspFee}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>MSP fee percentage</td>
                                <td className='px-6 py-4'>{rateData?.mspFeePercentage}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Address</td>
                                <td className='px-6 py-4'>{rateData?.netBillRate}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Address</td>
                                <td className='px-6 py-4'>{rateData?.netPurchase}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Opted for health benefits</td>
                                <td className='px-6 py-4'>{rateData?.optedForHB}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Pay rate</td>
                                <td className='px-6 py-4'>{rateData?.payRate}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Rate revision reason</td>
                                <td className='px-6 py-4'>{rateData?.rateRevisionReason}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Referral fee</td>
                                <td className='px-6 py-4'>{rateData?.refFee}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Tax OH</td>
                                <td className='px-6 py-4'>{rateData?.taxOH}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Tax OH percentage</td>
                                <td className='px-6 py-4'>{rateData?.taxOHPercentage}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            }
            {
                int == 6 &&
                <div id="no-scroll-div" className="relative w-[100%] mt-2 shadow-2xl h-[75vh] overflow-auto">
                    <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                        <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
                            <tr>
                                <th scope="col" className="px-6 py-3">
                                    <span>Client Details</span>
                                </th>
                                <th>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Client name</span>
                                </td>
                                <td className='px-6 py-0' style={{ width: "50%" }}>
                                    {importantCandidateData?.clientData?.clientName}
                                </td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Contract type</span>
                                </td>
                                <td className='px-6 py-0' style={{ width: "50%" }}>
                                    {importantCandidateData?.clientData?.contractType}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                        <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
                            <tr>
                                <th scope="col" className="px-6 py-3">
                                    <span>Job Details</span>
                                </th>
                                <th>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Job title</span>
                                </td>
                                <td className='px-6 py-0' style={{ width: "50%" }}>
                                    {importantCandidateData?.jobData?.jobTitle}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                        <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
                            <tr>
                                <th scope="col" className="px-6 py-3">
                                    <span>Vendor Details</span>
                                </th>
                                <th>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>
                                    <span>Company name</span>
                                </td>
                                <td className='px-6 py-0' style={{ width: "50%" }}>
                                    {importantCandidateData?.vendorData?.companyName}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            }
            {/* if(int === 2){ */}
            <Modal
                children={
                    int == 1 ?
                        <ShowCandidate int={1} open={open} setOpen={setOpen} data={candidateAddressData} showTableCount={setCount} setShowModal={setShowModal} />
                        : int == 2 ?
                            <ShowBackgroundCheck int={2} open={open} setOpen={setOpen}
                                // data={location?.state} 
                                showTableCount={setCount} setShowModal={setShowModal} showModal={showModal} />
                            : int == 3 ?
                                <ShowDocumentation int={3} open={open} setOpen={setOpen} data={location?.state} showTableCount={setCount} setShowModal={setShowModal} />
                                : int == 4 ?
                                    <ShowStartEndOperations int={4} open={open} setOpen={setOpen} data={location?.state} showTableCount={setCount} setShowModal={setShowModal} />
                                    : int == 5 ? <ShowRateRevision int={4} open={open} setOpen={setOpen} data={location?.state} showTableCount={setCount} setShowModal={setShowModal} />
                                        : <ShowCandidateClient int={5} open={open} setOpen={setOpen} data={importantCandidateData?.clientData} showTableCount={setCount} setShowModal={setShowModal} />
                }
                modalStyle={{ marginTop: "50px", height: "78vh", overflow: "scroll", boxShadow: "initial" }}
                showModalHeader={true}
                modalHeader={"Update Data"}
                isFlexible={true}
                topRightCloseButtonID={"x-  "}
                showModal={showModal}
                showBackButton={true}
                showBBPSLogo={true}
                handleBackClick={handleCloseModal}
            ></Modal>
            <div style={{
                position: "relative",
            }}>
                <button style={{
                    position: "absolute",
                    backgroundColor: "#1976D2",
                    color: "white",
                    borderRadius: "50%",
                    paddingTop: "8px",
                    padding: "10px",
                    bottom: "-20px",
                    right: "0px",
                }}
                    onClick={() => {
                        editButton();
                    }}
                >
                    <EditIcon />
                </button>
            </div>
        </>
    );
};


