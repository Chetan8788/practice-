import React, { useEffect, useState } from "react"
import ContentAreaScreen from "../ContentArea";
import SideBarScreen from "../Sidebar";
import NavBarScreen from "../Navbar";
import MiniDrawer from "./Homepage";
import { useAppDispatch, useAppSelector } from "../../hooks/app";
import { RootState } from "../../redux/store";
import { allCandidateData, getCandidate, getImportantCandidateData } from "../../actions/candidate";
import { useNavigate } from "react-router-dom";
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import Button from '@mui/material/Button';
import { Link } from "react-router-dom";
import { getCandidateBackgroundCheck } from "../../actions/backgroundCheck";
import { getCandidateDocumentation } from "../../actions/documentation";
import { getCandidateStartEndOperations } from "../../actions/startendoperations";
import { getCandidateRateRevision } from "../../actions/raterevision";


const HomepageScreen: React.FC = () => {

    const navigate = useNavigate();
    const dispatch = useAppDispatch();



    useEffect(() => {
        dispatch(allCandidateData());
    }, []);

    let candidateData: any = useAppSelector((state: RootState) => state.candidate.getAllCandidates);
    let candidateDataRow = candidateData;
    console.log('candidateDataRow: ', candidateDataRow);
    const [open, setOpen] = useState(false);
    const [singleCandidateData, setSingleCandidateData] = useState({});
    const [filteredData, setFilteredData] = useState<any>();
    const [count, setCount] = useState(true);


    useEffect(() => {
        setFilteredData(candidateData);
        if (count) {
            if (candidateData?.length !== 0) {
                setFilteredData(candidateData?.filter((cd: { candidateId: any }) =>
                    cd?.candidateId?.firstName?.toLowerCase()?.includes("")
                ));
                setCount(false);
            }
        }
    }, [candidateData])

    const filterResult = (event: any) => {
        // debugger;
        setFilteredData(candidateDataRow);
        let value: string = event.target.value;

        if (candidateData?.length !== 0) {
            setFilteredData(candidateData?.filter((cd: { candidateId: any }) =>
                cd?.candidateId?.firstName?.toLowerCase()?.includes(value.toLowerCase())
            ))
        }
    }

    const showCandidate = (data: any) => {
        setSingleCandidateData(data);
        setOpen(true);
    }

    function deleteJob(id: any): void {
        // dispatch(deleteCandidateData(id));
        // setCount(true);
    }

    const boxStyle = {
        alignItems: 'center',
        border: 'none', flexGrow: 1,
        marginTop: "3%", overflowY: "auto",
        overflowX: 'hidden',
        height: "60vh",
        paddingRight: "10px",
        paddingLeft: "10px"
    }

    const button = {
        backgroundColor: "Green",
        border: "none",
        color: "white",
        padding: "15px 32px",
        textAlign: "center",
        textDecoration: "none",
        display: "inline - block",
        fontSize: "16px",
    }


    return (
        <>
            {/* <MiniDrawer /> */}
            {/* {candidateData?.map((ele: any, index: any) => (
                <div key={index} className="" style={{
                    margin: "auto", width: "100%", display: "flex",
                    justifyContent: "space-between", padding: "10px 25px 5px 10px", marginBottom: "10px",
                    boxShadow: "rgba(100, 100, 111, 0.2) 0px 7px 29px 0px"
                }}>
                    <div className="" style={{ width: "10%" }}>{ele?.candidateId?.firstName + " " + ele?.candidateId?.lastName}</div>
                    <div className="" style={{}}>{ele?.candidateId?.workType}</div>
                    <div className="" >
                        <button
                            style={{ backgroundColor: "green", padding: "5px", color: "white", borderRadius: "5px" }}
                            onClick={() => {
                                navigate("/all-data", {
                                    state: {
                                        bgCheck: ele?.candidateId?.backgroundCheckId,
                                        document: ele?.candidateId?.documentationId,
                                        rateRevision: ele?.candidateId?.rateRevisionId,
                                        startEndOperations: ele?.candidateId?.startEndOperationId,
                                    }
                                });
                            }}
                        >
                            Information
                        </button>
                    </div>
                </div>
            ))} */}


            <div style={{ display: "flex" }}>
                <div style={{ borderRadius: "15px", marginBottom: "10px", width: "90%" }} className="py-3 px-4">
                    <div className="relative max-w">
                        <label htmlFor="hs-table-search" className="sr-only">Search</label>
                        <input style={{ border: '0.5px solid gray' }} type="text" name="hs-table-search" id="hs-table-search" className="ml-[-13px] p-2 pl-10 block w-[35%] border-gray-200 rounded-md text-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400" placeholder="Search for candidates" onChange={(event) => filterResult(event)} />
                        <div className="absolute inset-y-0 left-0 flex items-center pointer-events-none pl-2">
                            <svg className="h-3.5 w-3.5 text-gray-400" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                            </svg>
                        </div>
                    </div>
                </div>
                {/* <div style={{ width: "10%", maxHeight: "100%", justifyContent: "center", alignContent: "center" }}>
                    <Button variant="contained" component={Link} to={"/add-job"}>Add job</Button>
                </div> */}
            </div>
            <div className="flex flex-col" style={{ height: "70vh" }}>
                <div className="-m-1.5 overflow-x-auto">
                    <div className="p-1.5 min-w-full inline-block align-middle">
                        <div className="border rounded-lg divide-y divide-gray-200 dark:border-gray-700 dark:divide-gray-700">

                            <div className="overflow-hidden">
                                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                    <thead className="bg-gray-50 dark:bg-gray-700">
                                        <tr>
                                            <th scope="col" className="px-6 py-3 text-center text-xs font-medium uppercase">Candidate Name</th>
                                            <th scope="col" className="px-6 py-3 text-center text-xs font-medium uppercase">Work Type</th>
                                            <th scope="col" className="px-6 py-3 text-center text-xs font-medium uppercase">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">

                                        {
                                            (() => {
                                                // if (filteredData?.length !== 0) {
                                                //     return (
                                                //         filteredData.map((data: any, index: any) => (
                                                //             <tr key={index} onClick={() => showJob({
                                                //                 id: data.id,
                                                //                 jobDescription: data.jobDescription,
                                                //                 jobDivaId: data.jobDivaID,
                                                //                 jobTitle: data.jobTitle,
                                                //                 jobType: data.jobType,
                                                //                 lineOfBusiness: data.lineOfBusiness,
                                                //                 requestId: data.requestID,
                                                //             })}>
                                                //                 <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{data.jobTitle}</td>
                                                //                 <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{data.jobDescription}</td>
                                                //                 <td className="px-6 py-4 whitespace-nowrap text-center text-sm font-medium" onClick={(e) => e.stopPropagation()}>
                                                //                     <button className="text-blue-500 hover:text-blue-700" onClick={() => deleteJob(data.id)}>
                                                //                         <DeleteForeverIcon></DeleteForeverIcon>
                                                //                     </button>
                                                //                 </td>
                                                //             </tr>
                                                //         ))
                                                //     )
                                                // } else
                                                if (candidateDataRow?.length !== 0 && filteredData?.length !== 0) {
                                                    return (
                                                        filteredData?.map((data: any, index: any) => (
                                                            <tr key={index} onClick={() => showCandidate({
                                                                id: data.id,
                                                                jobDescription: data.jobDescription,
                                                                jobDivaId: data.jobDivaID,
                                                                jobTitle: data.jobTitle,
                                                                jobType: data.jobType,
                                                                lineOfBusiness: data.lineOfBusiness,
                                                                requestId: data.requestID,
                                                            })}>
                                                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{data?.candidateId?.firstName + " " + data?.candidateId?.lastName}</td>
                                                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{data?.candidateId?.workType}</td>
                                                                <td className="px-6 py-4 whitespace-nowrap text-center text-sm font-medium" onClick={(e) => e.stopPropagation()}>
                                                                    <button className="text-blue-500 hover:text-blue-700"
                                                                        onClick={() => {
                                                                            // dispatch(getImportantCandidateData(data?.candidateId))
                                                                            dispatch(getCandidateBackgroundCheck(data?.candidateId.id));
                                                                            dispatch(getCandidateDocumentation(data?.candidateId.id));
                                                                            dispatch(getCandidateStartEndOperations(data?.candidateId.id));
                                                                            dispatch(getCandidateRateRevision(data?.candidateId.id));
                                                                            dispatch(getCandidate(data?.candidateId.id));
                                                                            navigate("/all-data", {
                                                                                state: {
                                                                                    candidateData: {
                                                                                        candidateData: data?.candidateId,
                                                                                        addressData: data?.addressId
                                                                                    },
                                                                                    bgCheck: data?.candidateId?.backgroundCheckId,
                                                                                    document: data?.candidateId?.documentationId,
                                                                                    rateRevision: data?.candidateId?.rateRevisionId,
                                                                                    startEndOperations: data?.candidateId?.startEndOperationId,
                                                                                }
                                                                            });
                                                                        }}
                                                                    >
                                                                        information
                                                                    </button>
                                                                </td>
                                                            </tr>
                                                        ))
                                                    )
                                                }
                                                // else {
                                                //     return (
                                                //         <>
                                                //         </>
                                                //     )
                                                // }
                                            })()
                                        }

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div >
            </div >
            {/* <ShowJob open={open} setOpen={setOpen} data={singleJobData} showTableCount={setCount} /> */}
        </>
    )
}

export default HomepageScreen;