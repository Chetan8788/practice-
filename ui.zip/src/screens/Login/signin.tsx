//Chetan Patil - [20-07-23] - Sign in page for users to sign in

import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../redux/store";
import { useAppDispatch } from "../../hooks/app";
import { useNavigate, useParams } from "react-router-dom";
import { signIn } from "../../actions/user";
import { isPasswordValid, isTextValid } from "../../helpers/validate";
import { UserRoles } from "../../constants/constants";
import { Button } from "../../common/Button/Button";
import { TextField } from "../../common/TextField/TextField";
import { Loading } from "../../common/Loading/Loading";
// import SignUpImage from "../../Assets/signupbg1.png";

interface Props {
  history?: History; //Optional history parameter which is passed by the Router
}
export const SignIn: React.FC<Props> = (props) => {
  //userName in the state and setUserName method for updating the token value
  const [userName, setUserName] = useState<string>("");
  //password variable in the state and setPassword method for updating the token value
  const [password, setPassword] = useState<string>("");
  //passwordError variable in the state and setPasswordError method for updating the token value
  const [passwordError, setPasswordError] = useState<string>("");
  //emailError variable in the state and setEmailError method for updating the token value
  const [userNameError, setUserNameError] = useState<string>("");
  //Get the state and the dispatch properties form the UserContext and rename them to userState and userDispatch resp.
  const dispatch = useAppDispatch();
  const user = useSelector((state: RootState) => state.user);
  // const loading = useSelector((state: RootState) => state?.app?.loading);
  const navigate = useNavigate();

  const { id } = useParams();
  //Get the state and the dispatch properties form the LoadingContext and rename them to loadingState and loadingDispatch resp.
  //handleClick method that is executed when the Sign In button is clicked
  const handleClick = () => {
    //check if UserName is valid
    const userNameValid = isTextValid(userName);
    //check if password is valid
    const passwordValid = isPasswordValid(password);
    //If valid, clear error states and execute the signIn action creator
    if (userNameValid && passwordValid) {
      setUserNameError("");
      setPasswordError("");
      dispatch(signIn(userName, password));
    }
    //if userName or password is invalid, set errors in the state
    else {
      if (!userNameValid) {
        setUserNameError("User Name cannot be empty");
      }
      if (!passwordValid) {
        setPasswordError("Password is invalid. Must be at least 6 characters");
      }
    }
  };

  useEffect(() => {
    if (
      user.userDetails
      // &&  !loading
    ) {
      if (user.userDetails.role === UserRoles.BRAVEN_TOOL_ADMIN) {
        navigate("/home-page", { replace: true });
      }
      //  else if (user.userDetails.role === UserRoles.USER) {
      //   navigate("/recruiter-dashboard", { replace: true });
      // } else if (user.userDetails.role === UserRoles.ADMIN) {
      //   navigate("/admin-dashboard", { replace: true });
      // } else if (user.userDetails.role === UserRoles.CANDIDATE) {
      //   if (id) {
      //     dispatch(setExamCode(id));
      //     navigate("/test-taker", { state: { id } });
      //   } else {
      //     navigate("/candidate-dashboard", { replace: true });
      //   }
      // }
    }
  }, [
    user.userDetails,
    //  loading
  ]);
  // const loadingState = useSelector((state: RootState) => state.loading);
  return (

    <body className="antialiased bg-gradient-to-br from-[#a7d3ff] to-white w-[100%]">
      <div className="container px-6 mx-auto">
        <div className="flex flex-col text-center md:text-left md:flex-row h-screen justify-evenly md:items-center">
          <div className="flex flex-col w-full">
            <div>
              <svg
                className="w-20 h-20 mx-auto md:float-left fill-stroke text-gray-800"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"
                ></path>
              </svg>
            </div>
            <h1 className="text-5xl text-gray-800 font-bold">Onboarding</h1>
            <p className="w-5/12 mx-auto md:mx-0 text-gray-500">
              Control and monitorize your website data from dashboard.
            </p>
          </div>
          <div className="w-full md:w-full lg:w-9/12 mx-auto md:mx-0">
            <div className="bg-white p-10 flex flex-col w-full shadow-xl rounded-xl">
              <h2 className="text-2xl font-bold text-gray-800 text-left mb-5">
                Sign In
              </h2>
              <form action="" className="w-full">
                <div id="input" className="flex flex-col w-full my-5">
                  <label className="text-gray-500 mb-2">
                    Username
                  </label>
                  <input
                    type="text"
                    id="username"
                    value={userName}
                    onChange={(e) => [
                      setUserName(e.target.value)
                    ]}
                    placeholder="Please insert your username"
                    className="appearance-none border-2 border-gray-100 rounded-lg px-4 py-3 placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-green-600 focus:shadow-lg"
                  />
                </div>
                <div id="input" className="flex flex-col w-full my-5">
                  <label className="text-gray-500 mb-2">
                    Password
                  </label>
                  <input
                    type="password"
                    id="password"
                    value={password}
                    onChange={(e) => [
                      setPassword(e.target.value)
                    ]}
                    placeholder="Please insert your password"
                    className="appearance-none border-2 border-gray-100 rounded-lg px-4 py-3 placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-green-600 focus:shadow-lg"
                  />
                </div>
                <div id="button" className="flex flex-col w-full my-5">
                  <button
                    type="button"
                    className="w-full py-4 bg-[#1976D2] rounded-lg text-green-100"
                    onClick={handleClick}
                  >
                    <div className="flex flex-row items-center justify-center">
                      <div className="mr-2">
                        <svg
                          className="w-6 h-6"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"
                          ></path>
                        </svg>
                      </div>
                      <div className="font-bold">Sign in</div>
                    </div>
                  </button>
                  <div className="flex justify-evenly mt-5">
                    <a
                      href="#"
                      className="w-full text-center font-medium text-gray-500"
                    >
                      Recover password!
                    </a>
                    <a
                      href="#"
                      className="w-full text-center font-medium text-gray-500"
                    >
                      Singup!
                    </a>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </body>
  );
};
