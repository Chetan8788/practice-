import React from "react"
import Miscellaneous from "./Miscellaneous";

const MiscellaneousScreen: React.FC = () => {
    return (
        <>
            <Miscellaneous />
        </>
    )
}

export default MiscellaneousScreen;