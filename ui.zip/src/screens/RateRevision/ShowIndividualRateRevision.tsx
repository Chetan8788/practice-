import * as React from 'react';
import Backdrop from '@mui/material/Backdrop';
import Box from '@mui/material/Box';
// import Modal from '@mui/material/Modal';
// import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { useSpring, animated } from '@react-spring/web';
import CloseIcon from '@mui/icons-material/Close';
import EditIcon from '@mui/icons-material/Edit';
import DoneIcon from '@mui/icons-material/Done';
import { TextField } from "../../common/TextField/TextField";
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { ArticlesOfIncorporationList, CertificateOfInsuranceList, CipcicaCipcicuList, ClientTaskOrderOrSOWList, ClientTaskOrderOrSOWStepList, ClientTaskOrderSigningList, DirectDepositeAgreementList, DocumentationStatusList, EVerifyList, EemergencyFormList, GoodStandingDocumentationList, I9FormList, ListADocumentsList, ListBDocumentsList, ListCDocumentsList, MSAList, SOWList, VaccinationStatusList, VoidCheckEmailList, W9W4List, WorkAuthorizeDocumentationList, yesNoList } from '../../constants/constants';
import Select from "react-select";
import { Modal } from '../../common/Modal/Modal';
import { DropDown } from '../../common/DropDown/DropDown';
import { DatePicker } from '../../common/DatePicker/DatePicker';
import moment from "moment";
import { Button } from '../../common/Button/Button';
import { editRaterevisionData } from '../../actions/raterevision';
import { RootState } from '../../redux/store';

interface FadeProps {
    children: React.ReactElement;
    in?: boolean;
    onClick?: any;
    onEnter?: (node: HTMLElement, isAppearing: boolean) => void;
    onExited?: (node: HTMLElement, isAppearing: boolean) => void;
    ownerState?: any;
}

const Fade = React.forwardRef<HTMLDivElement, FadeProps>(function Fade(props, ref) {
    const {
        children,
        in: open,
        onClick,
        onEnter,
        onExited,
        ownerState,
        ...other
    } = props;
    const style = useSpring({
        from: { opacity: 0 },
        to: { opacity: open ? 1 : 0 },
        onStart: () => {
            if (open && onEnter) {
                onEnter(null as any, true);
            }
        },
        onRest: () => {
            if (!open && onExited) {
                onExited(null as any, true);
            }
        },
    });

    return (
        <animated.div ref={ref} style={style} {...other}>
            {React.cloneElement(children, { onClick })}
        </animated.div>
    );
});

const style = {
    position: 'absolute' as 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '1px #000',
    boxShadow: 24,
    p: 4,
    borderRadius: "10px",
};

interface Props {
    open: any,
    setOpen: any,
    data: any,
    showTableCount: any,
    int: any,
    setShowModal: any,
}

const ShowRateRevision: React.FC<Props> = ({ open, setOpen, 
    // data, 
    showTableCount, int, setShowModal }) => {
    const dispatch = useAppDispatch();
    let data = useAppSelector((state: RootState) => state?.rateRevision?.singleRateRevisionData);
    const [disable, setDisable] = React.useState(true);
    const [count, setCount] = React.useState(0);

    const [grossBr, setGrossBr] = React.useState(data?.grossBr);

    const [healthB, setHealthB] = React.useState(data?.healthB);

    const [margin, setMargin] = React.useState(data?.margin);

    const [mspFee, setMspFee] = React.useState(data?.mspFee);

    const [mspFeePercentage, setMspFeePercentage] = React.useState(data?.mspFeePercentage);

    const [netBillRate, setNetBillRate] = React.useState(data?.netBillRate);

    const [netPurchase, setNetPurchase] = React.useState(data?.netPurchase);

    const [optedForHB, setOptedForHB] = React.useState({
        value: data?.optedForHB,
        label: data?.optedForHB
    });

    const [payRate, setPayRate] = React.useState(data?.payRate);

    const [rateRevisionReason, setRateRevisionReason] = React.useState(data?.rateRevisionReason);

    const [refFee, setRefFee] = React.useState(data?.refFee);

    const [taxOH, setTaxOH] = React.useState(data?.taxOH);

    const [taxOHPercentage, setTaxOHPercentage] = React.useState(data?.taxOHPercentage);


    React.useEffect(() => {
        setGrossBr(data?.grossBr);
        setHealthB(data?.healthB);
        setMargin(data?.margin);
        setMspFee(data?.mspFee);
        setMspFeePercentage(data?.mspFeePercentage)
        setNetBillRate(data?.netBillRate);
        setNetPurchase(data?.netPurchase);
        setOptedForHB({
            value: data?.optedForHB,
            label: data?.optedForHB
        });
        setPayRate(data?.payRate);
        setRateRevisionReason(data?.rateRevision);
        setRefFee(data?.refFee);
        setTaxOH(data?.taxOH);
        setTaxOHPercentage(data?.taxOHPercentage);
        setCount(1);

    }, [data])

    const updatingObject = {
        grossBr: grossBr,
        healthB: healthB,
        margin: margin,
        mspFee: mspFee,
        mspFeePercentage: mspFeePercentage,
        netBillRate: netBillRate,
        netPurchase: netPurchase,
        optedForHB: optedForHB.value,
        payRate: payRate,
        rateRevisionReason: rateRevisionReason,
        refFee: refFee,
        taxOH: taxOH,
        taxOHPercentage: taxOHPercentage,
        candidateId: data?.candidateId
    }

    function updateCandidateRateRevision() {
        dispatch(editRaterevisionData(
            updatingObject
        ));
        setShowModal(false);
    }

    return (
        <div>
            <div id="no-scroll-div" className="relative w-[100%] mt-2 shadow-2xl h-[75vh]  overflow-auto">
                <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                    <tbody>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>
                                <span>Gross BR</span>
                            </td>
                            <td className='px-6 py-0'>
                                <TextField
                                    value={grossBr}
                                    handleChange={(event) => {
                                        setGrossBr(event?.target?.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Health benefits</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={healthB}
                                    handleChange={(event) => {
                                        setHealthB(event?.target?.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Margin</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={margin}
                                    handleChange={(event) => {
                                        setMargin(event?.target?.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>MSP fee</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={mspFee}
                                    handleChange={(event) => {
                                        setMspFee(event?.target?.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>MSP fee percentage</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={mspFeePercentage}
                                    handleChange={(event) => {
                                        setMspFeePercentage(event?.target?.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Net bill rate</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={netBillRate}
                                    handleChange={(event) => {
                                        setNetBillRate(event?.target?.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Net purchase</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={netPurchase}
                                    handleChange={(event) => {
                                        setNetPurchase(event?.target?.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Opted for health benefits</td>
                            <td className='px-6 py-4'>
                                <Select
                                    value={optedForHB}
                                    options={yesNoList}
                                    onChange={(e: any) => (
                                        setOptedForHB(e)
                                    )}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Pay rate</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={payRate}
                                    handleChange={(event) => {
                                        setPayRate(event?.target?.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Rate revision reason</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={rateRevisionReason}
                                    handleChange={(event) => {
                                        setRateRevisionReason(event?.target?.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Ref fee</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={refFee}
                                    handleChange={(e: any) => {
                                        setRefFee(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Tax OH</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={taxOH}
                                    handleChange={(e: any) => {
                                        setTaxOH(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Tax OH percentage</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={taxOHPercentage}
                                    handleChange={(e: any) => {
                                        setTaxOHPercentage(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div className='m-auto w-[50%]'>
                    <Button
                        className='w-[50px] text-white'
                        value="update"
                        handleClick={() => {
                            updateCandidateRateRevision();
                        }}
                    />
                </div>
            </div>
        </div>
    );
}

export default ShowRateRevision;