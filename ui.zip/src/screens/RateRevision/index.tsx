import { RateRevision } from "./RateRevision";

const RateRevisionScreen: React.FC = () => {

    return (
        <RateRevision />
    )
}

export default RateRevisionScreen;