import React, { ChangeEvent, useState } from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { TextField } from '../../common/TextField/TextField';
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { RootState } from '../../redux/store';
import { setReferralInputBoxValue } from '../../actions/referral';
import { DropDown } from '../../common/DropDown/DropDown';
import { LocationName } from '../../constants/candidateclientconstants';
import Select from 'react-select';

const ReferralDetails: React.FC = () => {
    const dispatch = useAppDispatch();
    const currentReferralData = useAppSelector((state: RootState) => state.referral.referralData);
    const locationName = LocationName;

    const onValueChange = (key: any, value: any) => {
        dispatch(setReferralInputBoxValue(key, value));
    };

    return (
        <>
            <h2>Referral details</h2>
            <Grid container spacing={4}>
                <Grid xs={6} md={3}>
                    <span>Referral company name</span>
                    <TextField
                        value={currentReferralData?.companyName}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("companyName", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Referral federal ID</span>
                    <TextField
                        value={currentReferralData?.federalID}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("federalID", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Name of contact person</span>
                    <TextField
                        value={currentReferralData?.contactPerson}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("contactPerson", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Referral company email ID</span>
                    <TextField
                        value={currentReferralData?.companyEmailID}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("companyEmailID", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Referral company contact no.</span>
                    <TextField
                        value={currentReferralData?.contactNo}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("contactNo", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Referral fax no.</span>
                    <TextField
                        value={currentReferralData?.faxNo}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("faxNo", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Name of sign authority</span>
                    <TextField
                        value={currentReferralData?.signAuthority}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("signAuthority", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Designation of sign authority</span>
                    <TextField
                        value={currentReferralData?.signAuthorityDesignation}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("signAuthorityDesignation", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Referral state of incorporation</span>
                    <TextField
                        value={currentReferralData?.stateOfIncorporation}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("stateOfIncorporation", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Referral address line 1</span>
                    <TextField
                        value={currentReferralData?.line1}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("line1", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Referral address line 2</span>
                    <TextField
                        value={currentReferralData?.line2}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("line2", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Referral city</span>
                    <TextField
                        value={currentReferralData?.city}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("city", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Referral zip code</span>
                    <TextField
                        value={currentReferralData?.zipCode}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("zipCode", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Referral state</span>
                    <Select
                        options={locationName}
                        value={currentReferralData?.state}
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(e: any) => {
                            onValueChange("state", e);
                        }}
                        isSearchable={true}
                    />
                </Grid>
                <Grid xs={6} md={3}>
                    <span>Country</span>
                    <TextField
                        value={currentReferralData?.country}
                        placeholder={""}
                        handleChange={(event) => {
                            onValueChange("country", event?.target?.value);
                        }}
                        className=""
                    />
                </Grid>
            </Grid>
        </>
    )
}

export default ReferralDetails;