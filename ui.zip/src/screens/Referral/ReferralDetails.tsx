import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { TextField } from '../../common/TextField/TextField';
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { RootState } from '../../redux/store';
import { setReferralInputBoxValue } from '../../actions/referral';
import { LocationName } from '../../constants/candidateclientconstants';
import Select from 'react-select';

const ReferralDetails: React.FC = () => {
    const dispatch = useAppDispatch();
    const currentReferralData = useAppSelector((state: RootState) => state.referral.referralData);
    const allVendorData = useAppSelector((state: RootState) => state.vendor.allVendorData);
    let allVendorName: object[] = [];
    if (allVendorData.length !== 0) {
        allVendorData.map((
            a: any
        ) => {
            a?.addressId.map((b: any) => {
                let data = {
                    label: a.vendorId.companyName,
                    value: {
                        id: a.vendorId.id,
                        companyName: a.vendorId.companyName,
                        federalId: a.vendorId.federalId,
                        contactPerson: a.vendorId.contactPerson,
                        email: b.contactDetailId.email,
                        contactNumber: b.contactDetailId.contactNumber,
                        faxNumber: b.contactDetailId.faxNumber,
                        signAuthority: a.vendorId.signAuthority,
                        signAuthorityDesignation: a.vendorId.signAuthorityDesignation,
                        stateOfIncorporation: a.vendorId.stateOfIncorporation,
                        line1: b.line1,
                        line2: b.line2,
                        city: b.city,
                        zipCode: b.zipCode,
                        state: b.state,
                        country: b.country,
                    }
                }
                allVendorName.push(data);
            })
        });
    }
    const locationName = LocationName;



    const onReferralValueChange = (key: any, value: any) => {
        dispatch(setReferralInputBoxValue(key, value));
    };

    function displayVendorData(value: any) {
        onReferralValueChange("id", value.id);
        onReferralValueChange("federalID", value.federalId);
        onReferralValueChange("contactPerson", value.contactPerson);
        onReferralValueChange("email", value.email);
        onReferralValueChange("contactNumber", value.contactNumber);
        onReferralValueChange("faxNumber", value.contactNumber);
        onReferralValueChange("signAuthority", value.signAuthority);
        onReferralValueChange("signAuthorityDesignation", value.signAuthorityDesignation);
        onReferralValueChange("stateOfIncorporation", value.stateOfIncorporation);
        onReferralValueChange("line1", value.line1);
        onReferralValueChange("line2", value.line2);
        onReferralValueChange("city", value.city);
        onReferralValueChange("zipCode", value.zipCode);
        onReferralValueChange("state", { label: value.state, value: value.state });
        onReferralValueChange("country", value.country);
    }

    return (
        <>
            <Grid xs={12} md={12}>
                <h2 style={{ marginTop: "40px" }}>Referral details</h2>
            </Grid>
            <div className="flex gap-16 " style={{ margin: "auto", width: "100%" }}>
                <div className="relative overflow-x-auto w-[100%] mt-10">
                    <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                        <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
                            <tr>
                                <th scope="col" className="px-6 py-3">Referral details</th>
                                <th scope="col" className="px-6 py-3">
                                    <Select
                                        options={allVendorName}
                                        value={currentReferralData?.companyName}
                                        getOptionLabel={(option) => option.label}
                                        getOptionValue={(option) => option.value}
                                        onChange={(e: any) => {
                                            displayVendorData(e.value);
                                            console.log('e.value: ', e.value);
                                            onReferralValueChange("companyName", e);
                                        }}
                                        isSearchable={true}
                                    />
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Referral federal ID</td>
                                <td className='px-6 py-4'>{currentReferralData?.federalID}</td>

                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Name of contact person</td>
                                <td className='px-6 py-4'>{currentReferralData?.contactPerson}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Referral company email</td>
                                <td className='px-6 py-4'>{currentReferralData?.email}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Referral company contact number</td>
                                <td className='px-6 py-4'>{currentReferralData?.contactNumber}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Referral fax number</td>
                                <td className='px-6 py-4'>{currentReferralData?.faxNumber}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Name of sign authority</td>
                                <td className='px-6 py-4'>{currentReferralData?.signAuthority}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Designation of sign authority</td>
                                <td className='px-6 py-4'>{currentReferralData?.signAuthorityDesignation}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Referral state of incorporation</td>
                                <td className='px-6 py-4'>{currentReferralData?.stateOfIncorporation}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Line 1</td>
                                <td className='px-6 py-4'>{currentReferralData?.line1}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Line 2</td>
                                <td className='px-6 py-4'>{currentReferralData?.line2}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>City</td>
                                <td className='px-6 py-4'>{currentReferralData?.city}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Zipcode</td>
                                <td className='px-6 py-4'>{currentReferralData?.zipCode}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>State</td>
                                <td className='px-6 py-4'>{currentReferralData?.state.value}</td>
                            </tr>
                            <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                                <td className='px-6 py-4'>Country</td>
                                <td className='px-6 py-4'>{currentReferralData?.country}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </>
    )
}

export default ReferralDetails; 
