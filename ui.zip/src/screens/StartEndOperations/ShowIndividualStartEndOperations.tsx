import * as React from 'react';
import { useSpring, animated } from '@react-spring/web';
import { TextField } from "../../common/TextField/TextField";
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { EndReasonList, ExitClearanceList, FFInvoiceStatusList, JobLevelList, JoiningStatusList, JoiningTypeList, yesNoList } from '../../constants/constants';
import Select from "react-select";
import moment from "moment";
import { Button } from '../../common/Button/Button';
import { editCandidateStartEndOperationsData } from '../../actions/startendoperations';
import { RootState } from '../../redux/store';

interface FadeProps {
    children: React.ReactElement;
    in?: boolean;
    onClick?: any;
    onEnter?: (node: HTMLElement, isAppearing: boolean) => void;
    onExited?: (node: HTMLElement, isAppearing: boolean) => void;
    ownerState?: any;
}

const Fade = React.forwardRef<HTMLDivElement, FadeProps>(function Fade(props, ref) {
    const {
        children,
        in: open,
        onClick,
        onEnter,
        onExited,
        ownerState,
        ...other
    } = props;
    const style = useSpring({
        from: { opacity: 0 },
        to: { opacity: open ? 1 : 0 },
        onStart: () => {
            if (open && onEnter) {
                onEnter(null as any, true);
            }
        },
        onRest: () => {
            if (!open && onExited) {
                onExited(null as any, true);
            }
        },
    });

    return (
        <animated.div ref={ref} style={style} {...other}>
            {React.cloneElement(children, { onClick })}
        </animated.div>
    );
});

const style = {
    position: 'absolute' as 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '1px #000',
    boxShadow: 24,
    p: 4,
    borderRadius: "10px",
};

interface Props {
    open: any,
    setOpen: any,
    data: any,
    showTableCount: any,
    int: any,
    setShowModal: any,
}

const ShowStartEndOperations: React.FC<Props> = ({ open, setOpen, 
    // data, 
    showTableCount, int, setShowModal }) => {
    const dispatch = useAppDispatch();
    let data = useAppSelector((state: RootState) => state?.startEndOperations?.singleStartEndOperationData);
    const [disable, setDisable] = React.useState(true);


    const [joiningStatus, setJoiningStatus] = React.useState({
        value: data?.joiningStatus,
        label: data?.joiningStatus
    });

    const [joiningType, setJoiningType] = React.useState({
        value: data?.joiningType,
        label: data?.joiningType
    });

    const [joiningStatusRemark, setJoiningStatusRemark] = React.useState(data?.joiningStatusRemark);
    const [recruiter, setRecruiter] = React.useState(data?.recruiter);
    const [teamLead, setTeamLead] = React.useState(data?.teamLead);
    const [crm, setCrm] = React.useState(data?.crm);
    const [teamManager, setTeamManager] = React.useState(data?.teamManager);
    const [seniorManager, setSeniorManager] = React.useState(data?.seniorManager);
    const [assoDirector, setAssoDirector] = React.useState(data?.assoDirector);
    const [centerHead, setCenterHead] = React.useState(data?.centerHead);
    const [onsiteAccDirector, setOnsiteAccDirector] = React.useState(data?.onsiteAccDirector);
    const [onboCoordinator, setOnboCoordinator] = React.useState(data?.onboCoordinator);
    const [endDate, setEndDate] = React.useState(moment.utc(data?.endDate).format('YYYY-MM-DD'));
    const [exitClearance, setExitClearance] = React.useState({
        value: data?.exitClearance,
        label: data?.exitClearance
    });

    const [endReason, setEndReason] = React.useState({
        value: data?.endReason,
        label: data?.endReason
    });

    const [endRemarks, setEndRemarks] = React.useState(data?.endRemarks);
    const [grossBr, setGrossBr] = React.useState(data?.grossBr);
    const [mspFeePercentage, setMspFeePercentage] = React.useState(data?.mspFeePercentage);
    const [mspFee, setMspFee] = React.useState(data?.mspFee);
    const [payRate, setPayRate] = React.useState(data?.payRate);
    const [refFee, setRefFee] = React.useState(data?.refFee);
    const [taxOHPercentage, setTaxOHPercentage] = React.useState(data?.taxOHPercentage);
    const [taxOH, setTaxOH] = React.useState(data?.taxOH);

    const [hBenefitesOpted, setHBenefitesOpted] = React.useState({
        value: data?.hBenefitesOpted,
        label: data?.hBenefitesOpted
    });

    const [hBenefitesCost, setHBenefitesCost] = React.useState(data?.hBenefitesCost);
    const [netBillRate, setNetBillRate] = React.useState(data?.netBillRate);
    const [netPurchase, setNetPurchase] = React.useState(data?.netPurchase);
    const [margin, setMargin] = React.useState(data?.margin);
    const [fullTimeSalaryOffered, setFullTimeSalaryOffered] = React.useState(data?.fullTimeSalaryOffered);

    const [jobLevel, setJobLevel] = React.useState({
        value: data?.jobLevel,
        label: data?.jobLevel
    });
    const [ffInvoiceStatus, setFfInvoiceStatus] = React.useState({
        value: data?.ffInvoiceStatus,
        label: data?.ffInvoiceStatus
    });
    const [count, setCount] = React.useState(0);
    
    React.useEffect(() => {

        setJoiningStatus({
            value: data?.joiningStatus,
            label: data?.joiningStatus
        });
        setJoiningType({
            value: data?.joiningType,
            label: data?.joiningType
        });

        setJoiningStatusRemark(data?.joiningStatusRemark);
        setRecruiter(data?.recruiter);
        setTeamLead(data?.teamLead);
        setCrm(data?.crm);
        setTeamManager(data?.teamManager);
        setSeniorManager(data?.seniorManager);
        setAssoDirector(data?.assoDirector);
        setCenterHead(data?.centerHead);
        setOnsiteAccDirector(data?.onsiteAccDirector);
        setOnboCoordinator(data?.onboCoordinator);
        setEndDate(moment.utc(data?.endDate).format('YYYY-MM-DD'));

        setExitClearance({
            value: data?.exitClearance,
            label: data?.exitClearance
        });

        setEndReason({
            value: data?.endReason,
            label: data?.endReason
        });

        setEndRemarks(data?.endRemarks);
        setGrossBr(data?.grossBr);
        setMspFeePercentage(data?.mspFeePercentage);
        setMspFee(data?.mspFee);
        setPayRate(data?.payRate);
        setRefFee(data?.refFee);
        setTaxOHPercentage(data?.taxOHPercentage);
        setTaxOH(data?.taxOH);

        setHBenefitesOpted({
            value: data?.hBenefitesOpted,
            label: data?.hBenefitesOpted
        });

        setHBenefitesCost(data?.hBenefitesCost);
        setNetBillRate(data?.netBillRate);
        setNetPurchase(data?.netPurchase);
        setMargin(data?.margin);
        setFullTimeSalaryOffered(data?.fullTimeSalaryOffered);

        setJobLevel({
            value: data?.jobLevel,
            label: data?.jobLevel
        });
        setFfInvoiceStatus({
            value: data?.ffInvoiceStatus,
            label: data?.ffInvoiceStatus
        });
        setCount(1);
        // }
    }, [data])

    function updateCandidateStartEndOperations() {
        // console.log('voidCheckOrEmailContent: ', voidCheckOrEmailContent);
        dispatch(editCandidateStartEndOperationsData(
            joiningStatus,
            joiningType,
            joiningStatusRemark,
            recruiter,
            teamLead,
            crm,
            teamManager,
            seniorManager,
            assoDirector,
            centerHead,
            onsiteAccDirector,
            onboCoordinator,
            endDate,
            exitClearance,
            endReason,
            endRemarks,
            grossBr,
            mspFeePercentage,
            mspFee,
            payRate,
            refFee,
            taxOHPercentage,
            taxOH,
            hBenefitesOpted,
            hBenefitesCost,
            netBillRate,
            netPurchase,
            margin,
            fullTimeSalaryOffered,
            jobLevel,
            ffInvoiceStatus,
            data?.candidateId,));
        setShowModal(false);
    }

    return (
        <div>
            <div id="no-scroll-div" className="relative w-[100%] mt-2 shadow-2xl h-[75vh]  overflow-auto">
                <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                    {/* <thead className='text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400'>
                            <tr>
                                <th scope="col" className="px-6 py-3">
                                    <span>Documentation Data</span>
                                </th>
                                <th scope="col" className="px-6 py-0">
                                </th>
                            </tr>
                        </thead> */}
                    <tbody>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>
                                <span>Joining status</span>
                            </td>
                            <td className='px-6 py-0'>
                                <Select
                                    value={joiningStatus}
                                    // label={data?.document?.CIPCICICAOrCIPCICU}
                                    options={JoiningStatusList}
                                    onChange={(e: any) => (
                                        setJoiningStatus(e)
                                    )}
                                // showLabel={false}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Joining type</td>
                            <td className='px-6 py-4'>
                                <Select
                                    value={joiningType}
                                    // label={data?.document?.CIPCICICAOrCIPCICU}
                                    options={JoiningTypeList}
                                    onChange={(e: any) => (
                                        setJoiningType(e)
                                    )}
                                // showLabel={false}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Joining status remark</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={joiningStatusRemark}
                                    handleChange={(e: any) => {
                                        setJoiningStatusRemark(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Recruiter</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={recruiter}
                                    handleChange={(e: any) => {
                                        setRecruiter(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Team lead</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={teamLead}
                                    handleChange={(e: any) => {
                                        setTeamLead(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>crm</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={crm}
                                    handleChange={(e: any) => {
                                        setCrm(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Team manager</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={teamManager}
                                    handleChange={(e: any) => {
                                        setTeamManager(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Senior manager</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={seniorManager}
                                    handleChange={(e: any) => {
                                        setSeniorManager(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Associate director</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={assoDirector}
                                    handleChange={(e: any) => {
                                        setAssoDirector(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Center head</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={centerHead}
                                    handleChange={(e: any) => {
                                        setCenterHead(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Onsite account director</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={onsiteAccDirector}
                                    handleChange={(e: any) => {
                                        setOnsiteAccDirector(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Onboarding coordinator</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={onboCoordinator}
                                    handleChange={(e: any) => {
                                        setOnboCoordinator(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>End date</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={endDate}
                                    type="date"
                                    handleChange={(e: any) => {
                                        setEndDate(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Exit clearance</td>
                            <td className='px-6 py-4'>
                                <Select
                                    value={exitClearance}
                                    options={ExitClearanceList}
                                    onChange={(e: any) => (
                                        setExitClearance(e)
                                    )}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>End reason</td>
                            <td className='px-6 py-4'>
                                <Select
                                    value={endReason}
                                    options={EndReasonList}
                                    onChange={(e: any) => (
                                        setEndReason(e)
                                    )}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>End remarks</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={endRemarks}
                                    handleChange={(e: any) => {
                                        setEndRemarks(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Gross BR</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={grossBr}
                                    handleChange={(e: any) => {
                                        setGrossBr(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>MSP fee percentage</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={mspFeePercentage}
                                    handleChange={(e: any) => {
                                        setMspFeePercentage(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>MSP fee</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={mspFee}
                                    handleChange={(e: any) => {
                                        setMspFee(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Pay rate</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={payRate}
                                    handleChange={(e: any) => {
                                        setPayRate(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Ref Fee</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={refFee}
                                    handleChange={(e: any) => {
                                        setRefFee(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Tax OH percentage</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={taxOHPercentage}
                                    handleChange={(e: any) => {
                                        setTaxOHPercentage(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Tax OH</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={taxOH}
                                    handleChange={(e: any) => {
                                        setTaxOH(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        {/* 

                        setJobLevel({
                            value: data?.,
                        label: data?.jobLevel
        });
                        setFfInvoiceStatus({
                            value: data?.,
                        label: data?.ffInvoiceStatus
        }); */}
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Health benefits opted</td>
                            <td className='px-6 py-4'>
                                <Select
                                    value={hBenefitesOpted}
                                    options={yesNoList}
                                    onChange={(e: any) => (
                                        setHBenefitesOpted(e)
                                    )}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Health benefits cost</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={hBenefitesCost}
                                    handleChange={(e: any) => {
                                        setHBenefitesCost(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>netBillRate</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={netBillRate}
                                    handleChange={(e: any) => {
                                        setNetBillRate(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Net purchase</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={netPurchase}
                                    handleChange={(e: any) => {
                                        setNetPurchase(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Margin</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={margin}
                                    handleChange={(e: any) => {
                                        setMargin(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>Full time salary offered</td>
                            <td className='px-6 py-4'>
                                <TextField
                                    value={fullTimeSalaryOffered}
                                    handleChange={(e: any) => {
                                        setFullTimeSalaryOffered(e.target.value);
                                    }}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>jobLevel</td>
                            <td className='px-6 py-4'>
                                <Select
                                    value={jobLevel}
                                    options={JobLevelList}
                                    onChange={(e: any) => (
                                        setJobLevel(e)
                                    )}
                                />
                            </td>
                        </tr>
                        <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                            <td className='px-6 py-4'>FF invoice status</td>
                            <td className='px-6 py-4'>
                                <Select
                                    value={ffInvoiceStatus}
                                    options={FFInvoiceStatusList}
                                    onChange={(e: any) => (
                                        setFfInvoiceStatus(e)
                                    )}
                                />
                            </td>
                        </tr>
                    </tbody>

                </table>
                <div className='m-auto w-[50%]'>
                    <Button
                        className='w-[50px] text-white'
                        value="update"
                        handleClick={() => {
                            updateCandidateStartEndOperations()
                        }}
                    />
                </div>
            </div>
        </div>
    );
}

export default ShowStartEndOperations;