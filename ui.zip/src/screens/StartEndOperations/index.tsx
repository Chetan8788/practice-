import { StartEndOperations } from "./StartEndOperations";


const StartEndOperationsScreen: React.FC = () => {

    return (
        <StartEndOperations />
    )
}

export default StartEndOperationsScreen;