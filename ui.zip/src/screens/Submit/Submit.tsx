// chetan patil - [21/07/2023] - Rate revision page 
import "./Submit.css"
import { Button } from "../../common/Button/Button";
import { useAppDispatch, useAppSelector } from "../../hooks/app";
import { RootState } from "../../redux/store";
import { sendAllData } from "../../actions/all";
import { EMPTY_CANDIDATE_DATA } from "../../utils/candidateutil";
import { EMPTY_CLIENT_DATA } from "../../utils/clientutil";

export const Submit: React.FC = () => {
    const dispatch = useAppDispatch();
    const currentRateRevisionData = useAppSelector((state: RootState) => state?.rateRevision?.rateRevisionData);
    const currentJobData = useAppSelector((state: RootState) => state.job.jobData);
    const currentCandidateData = useAppSelector((state: RootState) => state.candidate.candidateData);
    const currentClientData = useAppSelector((state: RootState) => state.client.clientData);
    const currentVendorData = useAppSelector((state: RootState) => state.vendor.vendorData);
    const currentReferralData = useAppSelector((state: RootState) => state.referral.referralData);
    const currentBGCData = useAppSelector((state: RootState) => state?.backgroundCheck?.backgroundCheckData);
    const currentDocumentationData = useAppSelector((state: RootState) => state?.documentation?.documentationData);
    const currentStartEndOperationsData = useAppSelector((state: RootState) => state.startEndOperations.startEndOperationsData);
    console.log('currentReferralData: ', currentReferralData);

    function onSubmitClick() {
        const candidateDataToSend: typeof EMPTY_CANDIDATE_DATA = {
            firstName: currentCandidateData.firstName,
            middleName: currentCandidateData.middleName,
            lastName: currentCandidateData.lastName,
            line1: currentCandidateData.line1,
            line2: currentCandidateData.line2,
            city: currentCandidateData.city,
            state: currentCandidateData.state?.value,
            zipCode: currentCandidateData.zipCode,
            country: currentCandidateData.country,
            email: currentCandidateData.email,
            contactNumber: currentCandidateData.contactNumber,
            workAuthorization: currentCandidateData.workAuthorization?.value,
            workAuthorizationExpiryDate: currentCandidateData.workAuthorizationExpiryDate,
            // contractType: currentClientData.contractType.value,
            // workingFrom: currentJobData.workingFrom,
            // workType: currentJobData.workType.value,
            // skillSet: currentJobData.skillSet,
            // resumeSource: currentJobData.resumeSource.value,
        }
        const clientDataToSend = {
            id: currentClientData.id,
            // clientName: currentClientData.clientName.value.clientName,
            contractType: currentClientData.contractType?.value,
            // endClientName: currentClientData.endClientName,
            // mspName: currentClientData.mspName,
            // line1: currentClientData.line1,
            // line2: currentClientData.line2,
            // city: currentClientData.city,
            // state: currentClientData.state.value,
            // zipCode: currentClientData.zipCode,
            // country: currentClientData.country
        }
        const vendorDataToSent = {
            id: currentVendorData.id,
            // companyName: currentVendorData.companyName.value,
            // federalID: currentVendorData.federalID,
            // contactPerson: currentVendorData.contactPerson,
            // companyEmailID: currentVendorData.companyEmailID,
            // contactNo: currentVendorData.contactNo,
            // faxNo: currentVendorData.faxNo,
            // signAuthority: currentVendorData.signAuthority,
            // signAuthorityDesignation: currentVendorData.signAuthorityDesignation,
            // stateOfIncorporation: currentVendorData.stateOfIncorporation,
            // line1: currentVendorData.line1,
            // line2: currentVendorData.line2,
            // city: currentVendorData.city,
            // state: currentVendorData.state.value,
            // zipCode: currentVendorData.zipCode,
            // country: currentVendorData.country
        }
        const referralDataToSend = {
            id: currentReferralData.id
            // companyName: currentReferralData.companyName.value,
            // federalID: currentReferralData.federalID,
            // contactPerson: currentReferralData.contactPerson,
            // companyEmailID: currentReferralData.companyEmailID,
            // contactNo: currentReferralData.contactNo,
            // faxNo: currentReferralData.faxNo,
            // signAuthority: currentReferralData.signAuthority,
            // signAuthorityDesignation: currentReferralData.signAuthorityDesignation,
            // stateOfIncorporation: currentReferralData.stateOfIncorporation,
            // line1: currentReferralData.line1,
            // line2: currentReferralData.line2,
            // city: currentReferralData.city,
            // state: currentReferralData.state.value,
            // zipCode: currentReferralData.zipCode,
            // country: currentReferralData.country
        }
        const jobDataToSend = {
            id: currentJobData.id,
            // requestID: currentJobData.requestID,
            // jobDivaID: currentJobData.jobDivaID,
            // jobTitle: currentJobData.jobTitle,
            workingFrom: currentJobData.workingFrom,
            workType: currentJobData.workType?.value,
            // jobType: currentJobData.jobType.value,
            resumeSource: currentJobData.resumeSource?.value,
            // lineOfBusiness: currentJobData.lineOfBusiness.value,
            skillSet: currentJobData.skillSet,
            // jobDescription: currentJobData.jobDescription
        }
        const BGCDataToSend = {
            caseID1: currentBGCData.caseID1,
            BGCInitiatedOn: currentBGCData.BGCInitiatedOn,
            primaryBGCInitiatedThru: currentBGCData.primaryBGCInitiatedThru?.value,
            BGCPackage1: currentBGCData.BGCPackage1?.value,
            BGCPackage2: currentBGCData.BGCPackage2?.value,
            BGCInvoiceMonth: currentBGCData.BGCInvoiceMonth?.value,
            BGCChargesPrimary: currentBGCData.BGCChargesPrimary,
            secondary: currentBGCData.secondary,
            caseID2: currentBGCData.caseID2,
            secondaryBGCInitiatedOn: currentBGCData.secondaryBGCInitiatedOn,
            secondaryBGCInitiatedThru: currentBGCData.secondaryBGCInitiatedThru?.value,
            secondaryBGCPackage1: currentBGCData.secondaryBGCPackage1?.value,
            secondaryBGCPackage2: currentBGCData.secondaryBGCPackage2?.value,
            secondaryBGCInvoiceMonth: currentBGCData.secondaryBGCInvoiceMonth?.value,
            secondaryBGCCharges: currentBGCData.secondaryBGCCharges,
            tertiary: currentBGCData.tertiary,
            caseID3: currentBGCData.caseID3,
            tertiaryBGCInitiatedOn: currentBGCData.tertiaryBGCInitiatedOn,
            tertiaryBGCInitiatedThru: currentBGCData.tertiaryBGCInitiatedThru?.value,
            tertiaryBGCPackage1: currentBGCData.tertiaryBGCPackage1?.value,
            tertiaryBGCPackage2: currentBGCData.tertiaryBGCPackage2?.value,
            tertiaryBGCInvoiceMonth: currentBGCData.tertiaryBGCInvoiceMonth?.value,
            tertiaryBGCCharges: currentBGCData.tertiaryBGCCharges,
            BGCStatus: currentBGCData.BGCStatus?.value,
            BGCCompletedOn: currentBGCData.BGCCompletedOn,
            BGCAffidavitStatus: currentBGCData.BGCAffidavitStatus?.value,
            BGCAffidavitOn: currentBGCData.BGCAffidavitOn,
            BGCReportStatus: currentBGCData.BGCReportStatus?.value,
            BGCAdjuStatus: currentBGCData.BGCAdjuStatus?.value,
            adjuSupportingDocs: currentBGCData.adjuSupportingDocs,
            dateOfAdjudication: currentBGCData.dateOfAdjudication,
            finalBGCReport: currentBGCData.finalBGCReport?.value,
            BGCRemark: currentBGCData.BGCRemark
        }
        const documentationDataToSend = {
            articlesOrCertificateOFIncorporation: currentDocumentationData.articlesOrCertificateOFIncorporation?.value,
            w9Orw4: currentDocumentationData.w9Orw4?.value,
            directDepositAgreement: currentDocumentationData.directDepositAgreement?.value,
            voidCheckOrEmailContent: currentDocumentationData.voidCheckOrEmailContent?.value,
            CIPCICICAOrCIPCICU: currentDocumentationData.CIPCICICAOrCIPCICU?.value,
            goodStandingDocument: currentDocumentationData.goodStandingDocument?.value,
            workAuthorizationDocument: currentDocumentationData.workAuthorizationDocument?.value,
            I9Form: currentDocumentationData.I9Form?.value,
            listADocument: currentDocumentationData.listADocument?.value,
            listBDocument: currentDocumentationData.listBDocument?.value,
            listCDocument: currentDocumentationData.listCDocument?.value,
            E_verify: currentDocumentationData.E_verify?.value,
            E_verificationDate: currentDocumentationData.E_verificationDate,
            emergencyForm: currentDocumentationData.emergencyForm?.value,
            vaccinationStatus: currentDocumentationData.vaccinationStatus?.value,
            MSA: currentDocumentationData.MSA?.value,
            SOW: currentDocumentationData.SOW?.value,
            SOWValidity: currentDocumentationData.SOWValidity,
            certificateOFInsuranceOrCOI: currentDocumentationData.certificateOFInsuranceOrCOI?.value,
            certificationOfInsurance: currentDocumentationData.certificationOfInsurance,
            clientTaskOrderOrSOW: currentDocumentationData.clientTaskOrderOrSOW?.value,
            clientTaskOrderOrSOWst: currentDocumentationData.clientTaskOrderOrSOWst?.value,
            clientTaskOrderSigning: currentDocumentationData.clientTaskOrderSigning?.value,
            TaskOrderExpiryDate: currentDocumentationData.TaskOrderExpiryDate,
            documentationStatus: currentDocumentationData.documentationStatus?.value,
            documentationRemark: currentDocumentationData.documentationRemark,
            documentationCompletionDate: currentDocumentationData.documentationCompletionDate
        }
        const startEndOperationsDataToSend = {
            joiningStatus: currentStartEndOperationsData.joiningStatus?.value,
            joiningType: currentStartEndOperationsData.joiningType?.value,
            joiningStatusRemark: currentStartEndOperationsData.joiningStatusRemark,
            recruiter: currentStartEndOperationsData.recruiter,
            teamLead: currentStartEndOperationsData.teamLead,
            crm: currentStartEndOperationsData.crm,
            teamManager: currentStartEndOperationsData.teamManager,
            seniorManager: currentStartEndOperationsData.seniorManager,
            assoDirector: currentStartEndOperationsData.assoDirector,
            centerHead: currentStartEndOperationsData.centerHead,
            onsiteAccDirector: currentStartEndOperationsData.onsiteAccDirector,
            onboCoordinator: currentStartEndOperationsData.onboCoordinator,
            endDate: currentStartEndOperationsData.endDate,
            exitClearance: currentStartEndOperationsData.exitClearance.value,
            endReason: currentStartEndOperationsData.endReason.value,
            endRemarks: currentStartEndOperationsData.endRemarks,
            grossBr: currentStartEndOperationsData.grossBr,
            mspFeePercentage: currentStartEndOperationsData.mspFeePercentage,
            mspFee: currentStartEndOperationsData.mspFee,
            payRate: currentStartEndOperationsData.payRate,
            refFee: currentStartEndOperationsData.refFee,
            taxOHPercentage: currentStartEndOperationsData.taxOHPercentage,
            taxOH: currentStartEndOperationsData.taxOH,
            hBenefitesOpted: currentStartEndOperationsData.hBenefitesOpted.value,
            hBenefitesCost: currentStartEndOperationsData.hBenefitesCost,
            netBillRate: currentStartEndOperationsData.netBillRate,
            netPurchase: currentStartEndOperationsData.netPurchase,
            margin: currentStartEndOperationsData.margin,
            fullTimeSalaryOffered: currentStartEndOperationsData.fullTimeSalaryOffered,
            jobLevel: currentStartEndOperationsData.jobLevel?.value,
            ffInvoiceStatus: currentStartEndOperationsData.ffInvoiceStatus?.value
        }
        const rateRevisionDataToSend = {
            grossBr: currentRateRevisionData.grossBr,
            mspFeePercentage: currentRateRevisionData.mspFeePercentage,
            mspFee: currentRateRevisionData.mspFee,
            netBillRate: currentRateRevisionData.netBillRate,
            payRate: currentRateRevisionData.payRate,
            refFee: currentRateRevisionData.refFee,
            taxOHPercentage: currentRateRevisionData.taxOHPercentage,
            taxOH: currentRateRevisionData.taxOH,
            optedForHB: currentRateRevisionData.optedForHB?.value,
            healthB: currentRateRevisionData.healthB,
            netPurchase: currentRateRevisionData.netPurchase,
            margin: currentRateRevisionData.margin,
            rateRevisionReason: currentRateRevisionData.rateRevisionReason
        }

        dispatch(sendAllData(candidateDataToSend, clientDataToSend, vendorDataToSent, referralDataToSend, jobDataToSend,
            BGCDataToSend, documentationDataToSend, startEndOperationsDataToSend, rateRevisionDataToSend));
    }

    return (
        <>
            <div className="submit-btn">
                <Button
                    className="submit-btn"
                    value="Submit"
                    handleClick={() => onSubmitClick()}
                />
            </div>
        </>
    );
};
