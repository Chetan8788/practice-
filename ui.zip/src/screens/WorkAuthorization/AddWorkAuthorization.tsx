import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { TextField } from '../../common/TextField/TextField';
import { Button } from '../../common/Button/Button';
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { RootState } from '../../redux/store';
import { saveWorkAuthorizationData, setWorkAuthorizationInputBoxValue } from '../../actions/workAuthorization';

const AddWorkAuthorization: React.FC = () => {
    const dispatch = useAppDispatch();
    const workAuthorization = useAppSelector((state: RootState) => state.workAuthorization.workAuthorizationData);
    
    const onWorkAuthorizationValueChange = (key: any, value: any) => {
        dispatch(setWorkAuthorizationInputBoxValue(key, value));
    };

    function onSubmitClick() {
        dispatch(saveWorkAuthorizationData(workAuthorization?.workAuthorization))
    }

    return (
        <>
            <h2>Work authorization</h2>
            <table className='w-full text-sm text-left text-gray-500 dark:text-gray-400'>
                <tbody>
                    <tr className='bg-white border-b dark:bg-gray-800 dark:border-gray-700'>
                        <td className='px-6 py-4'>
                            <span>Work authorization type</span>
                        </td>
                        <td className='px-6 py-4'>
                            <TextField
                                value={workAuthorization?.workAuthorization}
                                placeholder={""}
                                handleChange={(event) => {
                                    onWorkAuthorizationValueChange("workAuthorization", event.target.value);
                                }}
                                className="" />
                        </td>
                    </tr>
                </tbody>
            </table>

            <Grid xs={12} md={12}>
                <div className="rate-revision-btn-div">
                    <Button
                        className="submit-btn"
                        value="Save & Submit"
                        handleClick={() => onSubmitClick()}
                    />
                </div>
            </Grid>
        </>
    )
}

export default AddWorkAuthorization;