import React, { useState } from "react";
import Grid from "@mui/material/Unstable_Grid2";
import { TextField } from "../../common/TextField/TextField";
import { Button } from "../../common/Button/Button";
import { useAppDispatch, useAppSelector } from "../../hooks/app";
import { RootState } from "../../redux/store";
import {
    editWorkAuthorizationData,
    saveWorkAuthorizationData,
    setWorkAuthorizationInputBoxValue,
} from "../../actions/workAuthorization";
import { isTextValid } from "../../helpers/validate";
import { FloatLabel } from "../../common/FloatLabel/FloatLabel";
interface Props {
    setShowModal: any;
    data: any;
}
const EditWorkAuthorization: React.FC<Props> = ({ setShowModal, data }) => {

    const dispatch = useAppDispatch();

    // const workAuthorization = useAppSelector(
    //     (state: RootState) => state.workAuthorization.workAuthorizationData
    // );

    const [workAuthorization, setWorkAuthorization] = useState(data?.workAuthorization);

    const [workAuthorizationError, setWorkAuthorizationError] = useState<any>();

    const [workAuthorizationValid, setWorkAuthorizationValid] =
        useState<boolean>();

    function onSubmitClick() {
        setWorkAuthorizationValid(
            isTextValid(workAuthorization)
        );
        if (workAuthorizationValid) {
            dispatch(editWorkAuthorizationData(
                data?.id,
                workAuthorization
            ));
            setShowModal(false);
        } else {
            if (!workAuthorizationValid) {
                setWorkAuthorizationError("Work authorization is should not be empty");
            }
        }
    }

    return (
        <>
            {/* <h2>Work authorization</h2> */}
            <div className="pt-5 px-5">
                <Grid container spacing={2}>
                    <Grid xs={12} md={12}>
                        <FloatLabel
                            label="*Work authorization type"
                            value={workAuthorization}
                            placeholder={""}
                            handleChange={(event) => {
                                setWorkAuthorization(event.target.value);
                                setWorkAuthorizationValid(isTextValid(event?.target?.value));
                                if (!workAuthorizationValid) {
                                    setWorkAuthorizationError("Work authorization is should not be empty");
                                }
                            }}
                            className=""
                        />
                        {!workAuthorizationValid ? (
                            <p className="" style={{ fontSize: "12px", color: "red", textAlign: "left" }}>
                                {workAuthorizationError}
                            </p>
                        ) : null}
                    </Grid>
                </Grid>
                <Grid xs={12} md={12}>
                    <div className="rate-revision-btn-div">
                        <Button
                            className="submit-btn"
                            value="Update WorkAuthorization"
                            handleClick={() => onSubmitClick()}
                        />
                    </div>
                </Grid>
            </div>
        </>
    );
};

export default EditWorkAuthorization;
