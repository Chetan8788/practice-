import React, { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '../../hooks/app';
import { RootState } from '../../redux/store';
import Button from '@mui/material/Button';
import { Link } from "react-router-dom";
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import ShowWorkAuthorization from './ShowIndividualWorkAuthorization';
import { deleteWorkAuthorizationData } from '../../actions/workAuthorization';

const ShowWorkAuthorizationTable: React.FC = () => {
    const dispatch = useAppDispatch();
    let workAuthorizationData = useAppSelector((state: RootState) => state.workAuthorization.allWorkAuthorizationData);
    let workAuthorizationDataRow = workAuthorizationData;
    const [open, setOpen] = useState(false);
    const [singleWorkAuthorizationData, setSingleWorkAuthorizationData] = useState({});
    const [filteredData, setFilteredData] = useState(workAuthorizationData);
    const [count, setCount] = useState(true);

    useEffect(() => {
        if (count) {
            if (workAuthorizationData.length !== 0) {
                setFilteredData(workAuthorizationData.filter((cd: { workAuthorization: string }) =>
                    cd.workAuthorization.toLowerCase().includes("")
                ));
                setCount(false);
            }
        }
    }, [workAuthorizationData])

    const filterResult = (event: any) => {
        setFilteredData(workAuthorizationDataRow);
        let value: string = event.target.value;

        if (workAuthorizationData.length !== 0) {
            setFilteredData(workAuthorizationData.filter((cd: { workAuthorization: string }) =>
                cd.workAuthorization.toLowerCase().includes(value.toLowerCase())
            ))
        }
    }

    const showWorkAuthorization = (data: any) => {
        setSingleWorkAuthorizationData(data);
        setOpen(true);
    }

    function deleteWorkAuthorization(id: any): void {
        dispatch(deleteWorkAuthorizationData(id));
        setCount(true);
    }

    function onSubmitClick() {
        throw new Error('Function not implemented.');
    }

    return (
        <>
            <div style={{ display: "flex" }}>
                <div style={{ borderRadius: "15px", marginBottom: "10px", width: "90%" }} className="py-3 px-4">
                    <div className="relative max-w">
                        <label htmlFor="hs-table-search" className="sr-only">Search</label>
                        <input style={{ border: '0.5px solid gray' }} type="text" name="hs-table-search" id="hs-table-search" className="ml-[-13px] p-2 pl-10 block w-[35%] border-gray-200 rounded-md text-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400" placeholder="Search for work authorizations" onChange={(event) => filterResult(event)} />
                        <div className="absolute inset-y-0 left-0 flex items-center pointer-events-none pl-2">
                            <svg className="h-3.5 w-3.5 text-gray-400" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                            </svg>
                        </div>
                    </div>
                </div>
                <div style={{ width: "10%", maxHeight: "100%", justifyContent: "center", alignContent: "center" }}>
                    <Button variant="contained" component={Link} to={"/add-work-authorization"}>Add work authorization</Button>
                </div>
            </div>
            <div className="flex flex-col" style={{ height: "70vh" }}>
                <div className="-m-1.5 overflow-x-auto">
                    <div className="p-1.5 min-w-full inline-block align-middle">
                        <div className="border rounded-lg divide-y divide-gray-200 dark:border-gray-700 dark:divide-gray-700">

                            <div className="overflow-hidden">
                                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                    <thead className="bg-gray-50 dark:bg-gray-700">
                                        <tr>
                                            <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Work authorization</th>
                                            <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                                        {
                                            (() => {
                                                if (workAuthorizationDataRow?.length !== 0 && filteredData?.length !== 0) {
                                                    return (
                                                        filteredData.map((data: any, index: any) => (
                                                            <tr key={index} onClick={() => showWorkAuthorization({
                                                                id: data.id,
                                                                workAuthorization: data.workAuthorization,
                                                            })}>
                                                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200">{data.workAuthorization}</td>
                                                                <td className="px-6 py-4 whitespace-nowrap text-center text-sm font-medium" onClick={(e) => e.stopPropagation()}>
                                                                    <button className="text-blue-500 hover:text-blue-700" onClick={() => deleteWorkAuthorization(data.id)}>
                                                                        <DeleteForeverIcon></DeleteForeverIcon>
                                                                    </button>
                                                                </td>
                                                            </tr>
                                                        ))
                                                    )
                                                }
                                            })()
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div >
            </div >
            <ShowWorkAuthorization open={open} setOpen={setOpen} data={singleWorkAuthorizationData} showTableCount={setCount} />
        </>
    )
}

export default ShowWorkAuthorizationTable;