import React from 'react';
import ShowWorkAuthorizationTable from './ShowWorkAuthorizationTable';

const WorkAuthorization: React.FC = () => {

    return (
        <>
            <ShowWorkAuthorizationTable />
        </>
    )
}

export default WorkAuthorization;