export const EMPTY_CANDIDATE_DATA = {
    firstName: "",
    middleName: "",
    lastName: "",
    line1: "",
    line2: "",
    city: "",
    state: "",
    zipCode: "",
    country: "",
    email: "",
    contactNumber: "",
    workAuthorization: "",
    workAuthorizationExpiryDate: ""
}