export const EMPTY_CANDIDATE_DATA = {
    firstName: "",
    middleName: "",
    lastName: "",
    line1: "",
    line2: "",
    city: "",
    state: "",
    zipCode: "",
    country: "",
    email: "",
    contactNumber: "",
    workAuthorization: "",
    workAuthorizationExpiryDate: ""
}

export const EMPTY_CANDIDATE_VALIDATION_DATA = {
  firstNameValid: "",
  middleNameValid: "",
  lastNameValid: "",
  line1Valid: "",
  line2Valid: "",
  cityValid: "",
  stateValid: "",
  zipCodeValid: "",
  countryValid: "",
  emailValid: "",
  contactNumberValid: "",
  workAuthorizationValid: "",
  workAuthorizationExpiryDateValid: "",
};
