export const EMPTY_CONTRACTTYPE_DATA = {
    id: "",
    contractType: "",
}