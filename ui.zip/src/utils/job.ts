export const EMPTY_JOB_DATA = {
    id: "",
    requestID: "",
    jobDivaID: "",
    jobTitle: "",
    workingFrom: "",
    workType: "",
    jobType: "",
    resumeSource: "",
    lineOfBusiness: "",
    skillSet: "",
    jobDescription: ""
}