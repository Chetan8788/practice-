// chetan patil - [27-07-2023] - Rate Revision Util Page

export const EMPTY_RATE_REVISION_DATA = {
  grossBr: "",
  mspFeePercentage: "",
  mspFee: "",
  netBillRate: "",
  payRate: "",
  refFee: "",
  taxOHPercentage: "",
  taxOH: "",
  optedForHB: "",
  healthB: "",
  netPurchase: "",
  margin: "",
  rateRevisionReason: ""
};

