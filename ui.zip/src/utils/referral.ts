export const EMPTY_REFERRAL_DATA = {
    id: "",
    companyName: "",
    federalID: "",
    contactPerson: "",
    email: "",
    contactNumber: "",
    faxNumber: "",
    signAuthority: "",
    signAuthorityDesignation: "",
    stateOfIncorporation: "",
    line1: "",
    line2: "",
    city: "",
    state: "",
    zipCode: "",
    country: ""
}