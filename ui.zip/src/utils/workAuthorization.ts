export const EMPTY_WORKAUTHORIZATION_DATA = {
    id: "",
    workAuthorization: "",
}